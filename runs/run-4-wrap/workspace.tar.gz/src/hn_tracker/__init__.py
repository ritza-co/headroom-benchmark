from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import typer
from sqlite_utils import Database

HN_BASE_URL = "https://hacker-news.firebaseio.com/v0"
DEFAULT_DB_PATH = Path("hn.db")

app = typer.Typer(help="Track Hacker News top stories in SQLite.")


def main() -> None:
    app()


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def ensure_schema(db: Database) -> None:
    db.conn.execute(
        """
        create table if not exists stories (
            fetched_at text not null,
            rank integer not null,
            id integer not null,
            title text not null,
            url text,
            score integer not null,
            by text not null,
            time integer not null,
            primary key (fetched_at, id)
        )
        """
    )
    db.conn.execute(
        "create index if not exists idx_stories_snapshot_rank on stories (fetched_at, rank)"
    )
    db.conn.commit()


def fetch_top_stories(limit: int = 10) -> list[dict[str, Any]]:
    with httpx.Client(base_url=HN_BASE_URL, timeout=10.0) as client:
        top_response = client.get("/topstories.json")
        top_response.raise_for_status()
        top_ids = top_response.json()[:limit]

        stories = []
        for rank, story_id in enumerate(top_ids, start=1):
            item_response = client.get(f"/item/{story_id}.json")
            item_response.raise_for_status()
            item = item_response.json()
            stories.append(
                {
                    "rank": rank,
                    "id": item["id"],
                    "title": item["title"],
                    "url": item.get("url"),
                    "score": item.get("score", 0),
                    "by": item["by"],
                    "time": item["time"],
                }
            )
    return stories


def store_snapshot(db_path: Path = DEFAULT_DB_PATH) -> tuple[str, int]:
    db = Database(db_path)
    ensure_schema(db)
    fetched_at = utc_now()
    rows = [{**story, "fetched_at": fetched_at} for story in fetch_top_stories()]
    db["stories"].insert_all(rows, pk=("fetched_at", "id"), replace=True)
    return fetched_at, len(rows)


def snapshots(db: Database, limit: int) -> list[str]:
    return [
        row["fetched_at"]
        for row in db.query(
            """
            select distinct fetched_at
            from stories
            order by fetched_at desc
            limit ?
            """,
            [limit],
        )
    ]


def rows_for_snapshot(db: Database, fetched_at: str) -> list[dict[str, Any]]:
    return list(
        db.query(
            """
            select rank, id, title, url, score, by, time, fetched_at
            from stories
            where fetched_at = ?
            order by rank
            """,
            [fetched_at],
        )
    )


def format_table(headers: list[str], rows: list[list[Any]]) -> str:
    all_rows = [[str(cell) if cell is not None else "" for cell in row] for row in rows]
    widths = [
        max(len(header), *(len(row[index]) for row in all_rows)) if all_rows else len(header)
        for index, header in enumerate(headers)
    ]
    lines = [
        "  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)),
        "  ".join("-" * width for width in widths),
    ]
    lines.extend(
        "  ".join(cell.ljust(widths[index]) for index, cell in enumerate(row))
        for row in all_rows
    )
    return "\n".join(lines)


@app.command()
def fetch(db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", hidden=True)) -> None:
    """Fetch the current top 10 Hacker News stories."""
    fetched_at, count = store_snapshot(db_path)
    typer.echo(f"Stored {count} stories at {fetched_at} in {db_path}")


@app.command("list")
def list_stories(db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", hidden=True)) -> None:
    """Print the most recent stored snapshot."""
    db = Database(db_path)
    ensure_schema(db)
    latest = snapshots(db, 1)
    if not latest:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        return

    rows = rows_for_snapshot(db, latest[0])
    typer.echo(f"Snapshot: {latest[0]}")
    typer.echo(
        format_table(
            ["Rank", "ID", "Score", "By", "Title", "URL"],
            [
                [row["rank"], row["id"], row["score"], row["by"], row["title"], row["url"]]
                for row in rows
            ],
        )
    )


def format_story(row: dict[str, Any]) -> str:
    return f"#{row['rank']} {row['title']} ({row['id']})"


@app.command()
def diff(db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", hidden=True)) -> None:
    """Compare the two most recent stored snapshots."""
    db = Database(db_path)
    ensure_schema(db)
    latest = snapshots(db, 2)
    if len(latest) < 2:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` again later.")
        return

    current = {row["id"]: row for row in rows_for_snapshot(db, latest[0])}
    previous = {row["id"]: row for row in rows_for_snapshot(db, latest[1])}

    entered = [current[story_id] for story_id in current.keys() - previous.keys()]
    left = [previous[story_id] for story_id in previous.keys() - current.keys()]
    changed = [
        (previous[story_id], current[story_id])
        for story_id in current.keys() & previous.keys()
        if previous[story_id]["rank"] != current[story_id]["rank"]
    ]

    typer.echo(f"Comparing {latest[1]} -> {latest[0]}")
    typer.echo("Entered:")
    typer.echo("\n".join(f"  + {format_story(row)}" for row in sorted(entered, key=lambda r: r["rank"])) or "  none")
    typer.echo("Left:")
    typer.echo("\n".join(f"  - {format_story(row)}" for row in sorted(left, key=lambda r: r["rank"])) or "  none")
    typer.echo("Rank changed:")
    if changed:
        for old, new in sorted(changed, key=lambda pair: pair[1]["rank"]):
            delta = new["rank"] - old["rank"]
            typer.echo(
                f"  * {new['title']} ({new['id']}): {old['rank']} -> {new['rank']} "
                f"(delta {delta:+d})"
            )
    else:
        typer.echo("  none")
