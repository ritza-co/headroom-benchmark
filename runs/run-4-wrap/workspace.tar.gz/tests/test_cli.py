from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from hn_tracker import app, ensure_schema
from sqlite_utils import Database

runner = CliRunner()


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


class FakeClient:
    def __init__(self, *args, **kwargs):
        self.items = {
            story_id: {
                "id": story_id,
                "title": f"Story {story_id}",
                "url": f"https://example.com/{story_id}",
                "score": story_id,
                "by": "alice",
                "time": 1_700_000_000 + story_id,
            }
            for story_id in range(1, 11)
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def get(self, path):
        if path == "/topstories.json":
            return FakeResponse(list(range(1, 11)))
        story_id = int(path.removeprefix("/item/").removesuffix(".json"))
        return FakeResponse(self.items[story_id])


def seed(db_path: Path, fetched_at: str, stories: list[tuple[int, int, str]]) -> None:
    db = Database(db_path)
    ensure_schema(db)
    db["stories"].insert_all(
        [
            {
                "fetched_at": fetched_at,
                "rank": rank,
                "id": story_id,
                "title": title,
                "url": None,
                "score": 100 - rank,
                "by": "tester",
                "time": 1_700_000_000,
            }
            for rank, story_id, title in stories
        ],
        pk=("fetched_at", "id"),
        replace=True,
    )


def test_fetch_with_mocked_hn_api(mocker, tmp_path):
    mocker.patch("hn_tracker.httpx.Client", FakeClient)
    db_path = tmp_path / "hn.db"

    result = runner.invoke(app, ["fetch", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Stored 10 stories" in result.output
    rows = list(Database(db_path).query("select * from stories order by rank"))
    assert len(rows) == 10
    assert rows[0]["id"] == 1
    assert rows[0]["title"] == "Story 1"
    assert rows[0]["rank"] == 1


def test_list_prints_latest_snapshot(tmp_path):
    db_path = tmp_path / "hn.db"
    seed(db_path, "2026-01-01T00:00:00+00:00", [(1, 1, "Old story")])
    seed(db_path, "2026-01-02T00:00:00+00:00", [(1, 2, "New story")])

    result = runner.invoke(app, ["list", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Snapshot: 2026-01-02T00:00:00+00:00" in result.output
    assert "New story" in result.output
    assert "Old story" not in result.output
    assert "Rank" in result.output


def test_diff_shows_entered_left_and_rank_changed(tmp_path):
    db_path = tmp_path / "hn.db"
    seed(
        db_path,
        "2026-01-01T00:00:00+00:00",
        [(1, 1, "Leaves"), (2, 2, "Moves up"), (3, 3, "Stays")],
    )
    seed(
        db_path,
        "2026-01-02T00:00:00+00:00",
        [(1, 2, "Moves up"), (2, 4, "Enters"), (3, 3, "Stays")],
    )

    result = runner.invoke(app, ["diff", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "+ #2 Enters (4)" in result.output
    assert "- #1 Leaves (1)" in result.output
    assert "Moves up (2): 2 -> 1 (delta -1)" in result.output
