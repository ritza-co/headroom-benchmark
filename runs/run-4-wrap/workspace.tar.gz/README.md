# hn-tracker

Small Python CLI for tracking the current Hacker News top 10 stories in a local
SQLite database.

## Install

```bash
uv sync
```

## Commands

Fetch the current top 10 into `./hn.db`:

```bash
uv run hn-tracker fetch
```

List the most recent saved snapshot:

```bash
uv run hn-tracker list
```

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```

The database stores story id, title, url, score, author, story time, rank, and
the snapshot `fetched_at` timestamp.
