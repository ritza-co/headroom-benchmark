from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import typer
from sqlite_utils import Database

app = typer.Typer(no_args_is_help=True)

HN_API = "https://hacker-news.firebaseio.com/v0"
DB_PATH = Path("hn.db")


def ensure_tables(db: Database) -> None:
    if "stories" not in db.table_names():
        db["stories"].create(
            {
                "id": int,
                "title": str,
                "url": str,
                "score": int,
                "by": str,
                "time": int,
                "fetched_at": str,
                "rank": int,
            }
        )
        db["stories"].create_index(["fetched_at"])


def fetch_story_snapshot(limit: int = 10) -> list[dict[str, Any]]:
    with httpx.Client(timeout=10.0) as client:
        response = client.get(f"{HN_API}/topstories.json")
        response.raise_for_status()
        story_ids = response.json()[:limit]

        stories = []
        for rank, story_id in enumerate(story_ids, start=1):
            item_response = client.get(f"{HN_API}/item/{story_id}.json")
            item_response.raise_for_status()
            item = item_response.json()
            stories.append(
                {
                    "id": item["id"],
                    "title": item.get("title", ""),
                    "url": item.get("url"),
                    "score": item.get("score", 0),
                    "by": item.get("by", ""),
                    "time": item.get("time", 0),
                    "rank": rank,
                }
            )
        return stories


def latest_snapshot(db: Database) -> list[dict[str, Any]]:
    ensure_tables(db)
    rows = list(
        db.query(
            """
            select *
            from stories
            where fetched_at = (select max(fetched_at) from stories)
            order by rank
            """
        )
    )
    return [dict(row) for row in rows]


def two_latest_snapshots(db: Database) -> tuple[list[dict[str, Any]], list[dict[str, Any]]] | None:
    ensure_tables(db)
    snapshots = [row["fetched_at"] for row in db.query("select distinct fetched_at from stories order by fetched_at desc limit 2")]
    if len(snapshots) < 2:
        return None

    current = [dict(row) for row in db.query("select * from stories where fetched_at = ? order by rank", [snapshots[0]])]
    previous = [dict(row) for row in db.query("select * from stories where fetched_at = ? order by rank", [snapshots[1]])]
    return current, previous


def print_story_table(rows: list[dict[str, Any]]) -> None:
    if not rows:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        return

    typer.echo(f"Snapshot: {rows[0]['fetched_at']}")
    typer.echo(f"{'Rank':>4}  {'Score':>5}  {'ID':>10}  {'By':<15}  Title")
    typer.echo("-" * 80)
    for row in rows:
        title = row["title"][:80]
        typer.echo(f"{row['rank']:>4}  {row['score']:>5}  {row['id']:>10}  {row['by']:<15.15}  {title}")


@app.command()
def fetch() -> None:
    """Fetch the current Hacker News top 10 into hn.db."""
    db = Database(DB_PATH)
    ensure_tables(db)

    fetched_at = datetime.now(UTC).isoformat(timespec="seconds")
    rows = [{**story, "fetched_at": fetched_at} for story in fetch_story_snapshot()]
    db["stories"].insert_all(rows)
    typer.echo(f"Stored {len(rows)} stories in {DB_PATH} at {fetched_at}")


@app.command("list")
def list_stories() -> None:
    """Print the most recent saved top 10 snapshot."""
    print_story_table(latest_snapshot(Database(DB_PATH)))


@app.command()
def diff() -> None:
    """Compare the two most recent snapshots."""
    snapshots = two_latest_snapshots(Database(DB_PATH))
    if snapshots is None:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(code=1)

    current, previous = snapshots
    current_by_id = {row["id"]: row for row in current}
    previous_by_id = {row["id"]: row for row in previous}

    entered = [row for row in current if row["id"] not in previous_by_id]
    left = [row for row in previous if row["id"] not in current_by_id]
    changed = [
        (current_by_id[story_id], previous_by_id[story_id]["rank"] - current_by_id[story_id]["rank"])
        for story_id in current_by_id.keys() & previous_by_id.keys()
        if current_by_id[story_id]["rank"] != previous_by_id[story_id]["rank"]
    ]

    typer.echo("Entered top 10:")
    for row in entered:
        typer.echo(f"  #{row['rank']} {row['title']} ({row['id']})")
    if not entered:
        typer.echo("  None")

    typer.echo("\nLeft top 10:")
    for row in left:
        typer.echo(f"  was #{row['rank']} {row['title']} ({row['id']})")
    if not left:
        typer.echo("  None")

    typer.echo("\nRank changed:")
    for row, delta in sorted(changed, key=lambda item: item[0]["rank"]):
        direction = "up" if delta > 0 else "down"
        typer.echo(f"  #{row['rank']} {row['title']} ({row['id']}): {direction} {abs(delta)}")
    if not changed:
        typer.echo("  None")


def main() -> None:
    app()
