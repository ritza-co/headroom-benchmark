# hn-tracker

Small Python CLI for saving and comparing Hacker News top 10 snapshots.

## Install

```bash
uv sync
```

Dependencies are managed by `uv` and pinned in `pyproject.toml`/`uv.lock`.

## Commands

Fetch the current Hacker News top 10 into `./hn.db`:

```bash
uv run hn-tracker fetch
```

List the most recent saved snapshot:

```bash
uv run hn-tracker list
```

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```
