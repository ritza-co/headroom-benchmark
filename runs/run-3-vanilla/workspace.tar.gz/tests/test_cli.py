from __future__ import annotations

from pathlib import Path

from sqlite_utils import Database
from typer.testing import CliRunner

from hn_tracker import app, ensure_tables

runner = CliRunner()


def story(story_id: int, rank: int, title: str, fetched_at: str) -> dict[str, object]:
    return {
        "id": story_id,
        "title": title,
        "url": f"https://example.com/{story_id}",
        "score": 100 - rank,
        "by": f"user{story_id}",
        "time": 1_700_000_000 + story_id,
        "rank": rank,
        "fetched_at": fetched_at,
    }


def seed(db_path: Path, rows: list[dict[str, object]]) -> None:
    db = Database(db_path)
    ensure_tables(db)
    db["stories"].insert_all(rows)


def test_fetch_stores_mocked_top_10(tmp_path, monkeypatch, mocker):
    monkeypatch.chdir(tmp_path)
    mocker.patch(
        "hn_tracker.fetch_story_snapshot",
        return_value=[
            {
                "id": story_id,
                "title": f"Story {story_id}",
                "url": None,
                "score": story_id,
                "by": "alice",
                "time": 1_700_000_000,
                "rank": rank,
            }
            for rank, story_id in enumerate(range(101, 111), start=1)
        ],
    )

    result = runner.invoke(app, ["fetch"])

    assert result.exit_code == 0
    rows = list(Database("hn.db")["stories"].rows)
    assert len(rows) == 10
    assert rows[0]["id"] == 101
    assert rows[0]["rank"] == 1
    assert rows[0]["fetched_at"]


def test_list_prints_latest_snapshot(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    seed(
        tmp_path / "hn.db",
        [
            story(1, 1, "Old story", "2026-01-01T00:00:00+00:00"),
            story(2, 1, "Newest first", "2026-01-02T00:00:00+00:00"),
            story(3, 2, "Newest second", "2026-01-02T00:00:00+00:00"),
        ],
    )

    result = runner.invoke(app, ["list"])

    assert result.exit_code == 0
    assert "Snapshot: 2026-01-02T00:00:00+00:00" in result.output
    assert "Newest first" in result.output
    assert "Newest second" in result.output
    assert "Old story" not in result.output


def test_diff_prints_entered_left_and_rank_changed(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    seed(
        tmp_path / "hn.db",
        [
            story(1, 1, "Moved down", "2026-01-01T00:00:00+00:00"),
            story(2, 2, "Moved up", "2026-01-01T00:00:00+00:00"),
            story(3, 3, "Left story", "2026-01-01T00:00:00+00:00"),
            story(2, 1, "Moved up", "2026-01-02T00:00:00+00:00"),
            story(1, 2, "Moved down", "2026-01-02T00:00:00+00:00"),
            story(4, 3, "Entered story", "2026-01-02T00:00:00+00:00"),
        ],
    )

    result = runner.invoke(app, ["diff"])

    assert result.exit_code == 0
    assert "Entered top 10:" in result.output
    assert "#3 Entered story (4)" in result.output
    assert "Left top 10:" in result.output
    assert "was #3 Left story (3)" in result.output
    assert "Rank changed:" in result.output
    assert "#1 Moved up (2): up 1" in result.output
    assert "#2 Moved down (1): down 1" in result.output
