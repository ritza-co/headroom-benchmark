from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from hn_tracker import app, open_db, store_snapshot

runner = CliRunner()


def seed(db_path: Path, fetched_at: str, rows: list[dict[str, object]]) -> None:
    store_snapshot(open_db(db_path), rows, fetched_at)


def story(story_id: int, rank: int, title: str) -> dict[str, object]:
    return {
        "rank": rank,
        "id": story_id,
        "title": title,
        "url": None,
        "score": 100 - rank,
        "by": f"user{story_id}",
        "time": 1_700_000_000 + rank,
    }


def test_fetch_stores_mocked_top_stories(tmp_path: Path, mocker) -> None:
    db_path = tmp_path / "hn.db"
    stories = [story(story_id, rank, f"Story {rank}") for rank, story_id in enumerate(range(101, 111), 1)]
    mocker.patch("hn_tracker.utc_now", return_value="2026-06-04T10:00:00+00:00")
    mocker.patch("hn_tracker.fetch_top_stories", return_value=stories)

    result = runner.invoke(app, ["fetch", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Stored 10 stories" in result.output
    rows = list(open_db(db_path).query("select * from stories order by rank"))
    assert len(rows) == 10
    assert rows[0]["id"] == 101
    assert rows[0]["fetched_at"] == "2026-06-04T10:00:00+00:00"


def test_list_prints_latest_seeded_snapshot(tmp_path: Path) -> None:
    db_path = tmp_path / "hn.db"
    seed(db_path, "2026-06-04T09:00:00+00:00", [story(1, 1, "Old story")])
    seed(db_path, "2026-06-04T10:00:00+00:00", [story(2, 1, "Latest story")])

    result = runner.invoke(app, ["list", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Snapshot: 2026-06-04T10:00:00+00:00" in result.output
    assert "Latest story" in result.output
    assert "Old story" not in result.output


def test_diff_prints_entered_left_and_rank_changed(tmp_path: Path) -> None:
    db_path = tmp_path / "hn.db"
    seed(
        db_path,
        "2026-06-04T09:00:00+00:00",
        [story(1, 1, "Alpha"), story(2, 2, "Bravo"), story(3, 3, "Charlie")],
    )
    seed(
        db_path,
        "2026-06-04T10:00:00+00:00",
        [story(4, 1, "Delta"), story(1, 2, "Alpha"), story(2, 3, "Bravo")],
    )

    result = runner.invoke(app, ["diff", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Entered:" in result.output
    assert "#1 Delta (4)" in result.output
    assert "Left:" in result.output
    assert "#3 Charlie (3)" in result.output
    assert "Rank changed:" in result.output
    assert "#2 Alpha (1): -1" in result.output
    assert "#3 Bravo (2): -1" in result.output
