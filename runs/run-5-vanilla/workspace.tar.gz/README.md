# hn-tracker

Small CLI for storing and comparing Hacker News top 10 snapshots.

## Install

```bash
uv sync
```

## Commands

Fetch the current top 10 from the Hacker News Firebase API into `./hn.db`:

```bash
uv run hn-tracker fetch
```

Print the most recent stored snapshot:

```bash
uv run hn-tracker list
```

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```

Each command accepts `--db PATH` to use a different SQLite database.
