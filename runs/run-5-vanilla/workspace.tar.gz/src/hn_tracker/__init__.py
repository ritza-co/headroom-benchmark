from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import typer
from sqlite_utils import Database

HN_API = "https://hacker-news.firebaseio.com/v0"
DEFAULT_DB_PATH = Path("hn.db")

app = typer.Typer(help="Track Hacker News top 10 snapshots.")


def main() -> None:
    app()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def open_db(path: Path = DEFAULT_DB_PATH) -> Database:
    db = Database(path)
    db["snapshots"].create(
        {"fetched_at": str},
        pk="fetched_at",
        if_not_exists=True,
    )
    db["stories"].create(
        {
            "fetched_at": str,
            "rank": int,
            "id": int,
            "title": str,
            "url": str,
            "score": int,
            "by": str,
            "time": int,
        },
        pk=("fetched_at", "id"),
        foreign_keys=(("fetched_at", "snapshots", "fetched_at"),),
        if_not_exists=True,
    )
    return db


def fetch_top_stories(limit: int = 10) -> list[dict[str, Any]]:
    with httpx.Client(timeout=10.0) as client:
        top_ids_response = client.get(f"{HN_API}/topstories.json")
        top_ids_response.raise_for_status()
        top_ids = top_ids_response.json()[:limit]

        stories = []
        for rank, story_id in enumerate(top_ids, start=1):
            story_response = client.get(f"{HN_API}/item/{story_id}.json")
            story_response.raise_for_status()
            story = story_response.json()
            stories.append(
                {
                    "rank": rank,
                    "id": story["id"],
                    "title": story.get("title", ""),
                    "url": story.get("url"),
                    "score": story.get("score", 0),
                    "by": story.get("by", ""),
                    "time": story.get("time", 0),
                }
            )
    return stories


def store_snapshot(db: Database, stories: list[dict[str, Any]], fetched_at: str) -> None:
    db["snapshots"].insert({"fetched_at": fetched_at}, pk="fetched_at", replace=True)
    db["stories"].insert_all(
        [{**story, "fetched_at": fetched_at} for story in stories],
        pk=("fetched_at", "id"),
        replace=True,
    )


def latest_snapshot_times(db: Database, limit: int) -> list[str]:
    rows = db.query(
        "select fetched_at from snapshots order by fetched_at desc limit ?",
        [limit],
    )
    return [row["fetched_at"] for row in rows]


def stories_for_snapshot(db: Database, fetched_at: str) -> list[dict[str, Any]]:
    return list(
        db.query(
            """
            select rank, id, title, url, score, by, time, fetched_at
            from stories
            where fetched_at = ?
            order by rank
            """,
            [fetched_at],
        )
    )


def print_table(stories: list[dict[str, Any]]) -> None:
    headers = ("Rank", "ID", "Score", "By", "Title")
    rows = [
        (
            str(story["rank"]),
            str(story["id"]),
            str(story["score"]),
            story["by"],
            story["title"],
        )
        for story in stories
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        for index in range(len(headers))
    ]
    typer.echo("  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)))
    typer.echo("  ".join("-" * width for width in widths))
    for row in rows:
        typer.echo("  ".join(value.ljust(widths[index]) for index, value in enumerate(row)))


@app.command()
def fetch(db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path.")) -> None:
    """Fetch and store the current Hacker News top 10."""
    fetched_at = utc_now()
    stories = fetch_top_stories()
    store_snapshot(open_db(db_path), stories, fetched_at)
    typer.echo(f"Stored {len(stories)} stories at {fetched_at}")


@app.command("list")
def list_stories(
    db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Print the most recent stored top 10 snapshot."""
    db = open_db(db_path)
    times = latest_snapshot_times(db, 1)
    if not times:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        raise typer.Exit(code=1)

    stories = stories_for_snapshot(db, times[0])
    typer.echo(f"Snapshot: {times[0]}")
    print_table(stories)


@app.command()
def diff(db_path: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path.")) -> None:
    """Compare the two most recent top 10 snapshots."""
    db = open_db(db_path)
    times = latest_snapshot_times(db, 2)
    if len(times) < 2:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(code=1)

    current_time, previous_time = times
    current = {story["id"]: story for story in stories_for_snapshot(db, current_time)}
    previous = {story["id"]: story for story in stories_for_snapshot(db, previous_time)}

    entered = [story for story_id, story in current.items() if story_id not in previous]
    left = [story for story_id, story in previous.items() if story_id not in current]
    changed = [
        (current[story_id], previous[story_id]["rank"] - current[story_id]["rank"])
        for story_id in current.keys() & previous.keys()
        if current[story_id]["rank"] != previous[story_id]["rank"]
    ]

    typer.echo(f"Comparing {previous_time} -> {current_time}")
    typer.echo("Entered:")
    for story in sorted(entered, key=lambda item: item["rank"]):
        typer.echo(f"  #{story['rank']} {story['title']} ({story['id']})")
    if not entered:
        typer.echo("  None")

    typer.echo("Left:")
    for story in sorted(left, key=lambda item: item["rank"]):
        typer.echo(f"  #{story['rank']} {story['title']} ({story['id']})")
    if not left:
        typer.echo("  None")

    typer.echo("Rank changed:")
    for story, delta in sorted(changed, key=lambda item: item[0]["rank"]):
        sign = "+" if delta > 0 else ""
        typer.echo(f"  #{story['rank']} {story['title']} ({story['id']}): {sign}{delta}")
    if not changed:
        typer.echo("  None")
