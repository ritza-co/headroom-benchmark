# hn-tracker

`hn-tracker` is a Python command line app for tracking Hacker News top stories over time.

It fetches the public Hacker News Firebase API, stores immutable snapshots in SQLite, and lets you list, diff, search, export, and watch story movement from the terminal.

The project is managed with `uv`.

## Quick Install

Install `uv` first if you do not already have it.

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Clone or enter this project directory.

```bash
uv sync
```

Run the CLI from the project environment.

```bash
uv run hn-tracker --help
```

The default database is `./hn.db`.

## Dependency Pins

Runtime dependencies are pinned in `pyproject.toml`.

Development dependencies are pinned in the `dev` dependency group.

The pins were checked against PyPI before creating this project.

## Commands

There are eight primary subcommands.

Each command has tests under `tests/`.

### fetch

Fetch the current top Hacker News stories.

```bash
uv run hn-tracker fetch
```

Fetch a smaller sample.

```bash
uv run hn-tracker fetch --limit 10
```

Example output:

```text
Saved snapshot 1 with 10 stories at 2026-06-04T15:00:00+00:00
```

The command stores rows in `story_snapshots`.

Each row includes id, title, url, score, by, time, descendants, type, and fetched_at.

Story detail requests are made concurrently with `httpx.AsyncClient`.

### list

Print the latest snapshot as a Rich table.

```bash
uv run hn-tracker list
```

Print a specific snapshot.

```bash
uv run hn-tracker list --snapshot 3
```

Example output:

```text
              Hacker News Snapshot 3
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━┳━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━┓
┃ Rank ┃ ID       ┃ Score ┃ By   ┃ Comments ┃ Title        ┃ URL ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━╇━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━┩
│ 1    │ 12345678 │ 421   │ user │ 99       │ Example post │ ... │
└──────┴──────────┴───────┴──────┴──────────┴──────────────┴─────┘
```

Use `LATEST` or a numeric snapshot id.

### diff

Compare two snapshots.

```bash
uv run hn-tracker diff
```

By default it compares the two most recent snapshots.

Specify exact snapshots when needed.

```bash
uv run hn-tracker diff --from 2 --to 5
```

Example output:

```text
              Snapshot Diff 2 -> 5
┏━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━┳━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Change  ┃ ID       ┃ Rank   ┃ Delta ┃ Title        ┃
┡━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━╇━━━━━━━╇━━━━━━━━━━━━━━┩
│ entered │ 22222222 │ 4      │       │ New story    │
│ left    │ 11111111 │ 12     │       │ Old story    │
│ rank    │ 33333333 │ 9 -> 2 │ +7    │ Rising story │
└─────────┴──────────┴────────┴───────┴──────────────┘
```

Positive delta means the story moved upward toward rank 1.

### story

Fetch one live story and its first five top-level comments.

```bash
uv run hn-tracker story 12345678
```

Example output:

```text
             Story 12345678
┏━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ Field       ┃ Value              ┃
┡━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ title       │ Example story      │
│ url         │ https://example... │
│ score       │ 421                │
│ by          │ user               │
│ descendants │ 99                 │
└─────────────┴────────────────────┘
```

Comments are rendered with Rich panels.

This command uses the live HN item API.

It does not require a local snapshot.

### search

Search saved story titles with SQLite FTS5.

```bash
uv run hn-tracker search rust
```

Example output:

```text
          Search: rust
┏━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃ ID       ┃ Snapshots ┃ Title                ┃
┡━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ 12345678 │ 2         │ Rust compiler update │
└──────────┴───────────┴──────────────────────┘
```

The `Snapshots` column counts how many saved snapshots include that story.

Search only includes stories already fetched into `hn.db`.

### stats

Print database-level tracking statistics.

```bash
uv run hn-tracker stats
```

Example output:

```text
        HN Tracker Stats
┏━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric             ┃ Value                 ┃
┡━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━┩
│ Snapshots          │ 4                     │
│ Unique stories     │ 82                    │
│ Oldest fetched_at  │ 2026-06-04T14:00:00Z │
│ Newest fetched_at  │ 2026-06-04T15:00:00Z │
│ Author: alice      │ 7                     │
└────────────────────┴───────────────────────┘
```

Top authors are ranked by appearances in saved snapshot rows.

### export

Export the latest snapshot to stdout.

```bash
uv run hn-tracker export json
```

```bash
uv run hn-tracker export csv
```

```bash
uv run hn-tracker export markdown
```

Example JSON:

```json
[
  {
    "snapshot_id": 1,
    "rank": 1,
    "id": 12345678,
    "title": "Example story"
  }
]
```

Example CSV:

```csv
snapshot_id,rank,id,title,url,score,by,time,descendants,type,fetched_at
1,1,12345678,Example story,https://example.com,421,user,1700000000,99,story,2026-06-04T15:00:00+00:00
```

Example Markdown:

```markdown
| snapshot_id | rank | id | title |
| --- | --- | --- | --- |
| 1 | 1 | 12345678 | Example story |
```

### watch

Fetch repeatedly until Ctrl-C.

```bash
uv run hn-tracker watch
```

Use a shorter interval while developing.

```bash
uv run hn-tracker watch --interval 15
```

Example output:

```text
snapshot=1 stories=30
snapshot=2 entered=3 left=3 rank_changed=21
snapshot=3 entered=1 left=1 rank_changed=17
```

The command always fetches 30 stories.

The interval defaults to 60 seconds.

## Architecture

The CLI entrypoint is `hn_tracker.cli:app`.

Typer owns command parsing.

Rich owns human-readable terminal output.

Structlog writes structured INFO logs to stderr.

The Hacker News API client lives in `hn_tracker.hn`.

The database layer lives in `hn_tracker.db`.

The database file is relative to the current working directory.

This makes it easy to keep separate tracking databases per project or shell session.

The schema has a `snapshots` table.

The schema has a `story_snapshots` table.

The schema has a `story_titles_fts` FTS5 virtual table.

Snapshots are immutable.

Repeated story ids are expected across snapshots.

The FTS index stores one title per story id.

Diffs compare rank positions in two snapshots.

Exports read the latest snapshot only.

## Hacker News API

Top stories come from:

```text
https://hacker-news.firebaseio.com/v0/topstories.json
```

Items come from:

```text
https://hacker-news.firebaseio.com/v0/item/<id>.json
```

`fetch` downloads the topstory id list first.

It then requests item metadata concurrently.

Only items with type `story` are stored.

## Development

Install dependencies.

```bash
uv sync
```

Run tests.

```bash
uv run pytest -v
```

Run the CLI.

```bash
uv run hn-tracker --help
```

Inspect the database with SQLite.

```bash
sqlite3 hn.db '.tables'
```

You can also use `sqlite-utils` during development.

```bash
uv run sqlite-utils tables hn.db
```

Run a live fetch.

```bash
uv run hn-tracker fetch --limit 30
```

List the latest snapshot.

```bash
uv run hn-tracker list
```

Search saved titles.

```bash
uv run hn-tracker search python
```

## Testing Notes

Tests isolate the database by changing into pytest temp directories.

Network calls are mocked for command tests.

The concurrency test replaces `httpx.AsyncClient` with a fake async client.

It asserts that more than one item request is in flight.

The export tests parse JSON and CSV output.

The diff test checks entered, left, and rank-changed stories.

The FTS test checks search across multiple snapshots.

## Docker

Build the image.

```bash
docker build -t hn-tracker .
```

Run the CLI.

```bash
docker run --rm hn-tracker --help
```

Persist `hn.db` by mounting a directory.

```bash
docker run --rm -v "$PWD:/data" -w /data hn-tracker fetch --limit 30
```

## CI

The GitHub Actions workflow installs `uv`.

It installs Python 3.12.

It runs:

```bash
uv sync --frozen
uv run pytest -v
uv run hn-tracker --help
```

## Data Model

`snapshots.id` is the snapshot identifier.

`snapshots.fetched_at` is the UTC fetch timestamp.

`story_snapshots.snapshot_id` links rows to a snapshot.

`story_snapshots.rank` is the position in the fetched topstory list.

`story_snapshots.id` is the Hacker News item id.

`story_snapshots.title` is the story title at fetch time.

`story_snapshots.url` is nullable.

`story_snapshots.score` is the score at fetch time.

`story_snapshots.by` is the author username.

`story_snapshots.time` is the HN Unix timestamp.

`story_snapshots.descendants` is the HN comment count.

`story_snapshots.type` is usually `story`.

`story_snapshots.fetched_at` duplicates the snapshot timestamp for row-level exports.

## Roadmap

Add configurable database paths.

Add scheduled GitHub Actions snapshot capture.

Add a trend command for score and rank history.

Add author-specific filtering.

Add domain-specific filtering.

Add export of all snapshots.

Add comment search.

Add terminal sparklines for rank movement.

Add optional JSON logging.

Add retries and backoff around transient API failures.
