# Changelog

## 0.1.0 - 2026-06-04

- Added `hn-tracker fetch` for concurrent Hacker News top-story fetching through `httpx`.
- Added SQLite persistence at `./hn.db` with snapshot metadata and story rows.
- Added SQLite FTS5 indexing for saved story title search.
- Added `hn-tracker list` with Rich table output for saved snapshots.
- Added `hn-tracker diff` for entered, left, and rank-changed story comparisons.
- Added `hn-tracker story` for live story metadata and first five top-level comments.
- Added `hn-tracker search` for full-text title lookup across stored snapshots.
- Added `hn-tracker stats` for snapshot, story, author, and timestamp statistics.
- Added `hn-tracker export` for JSON, CSV, and Markdown latest-snapshot export.
- Added `hn-tracker watch` for repeated fetches and one-line change summaries.
- Added pytest coverage for all subcommands, FTS, diff, export formats, and concurrency.
- Added Docker and GitHub Actions CI support.
