from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlite_utils import Database


DB_PATH = Path("hn.db")


@dataclass(frozen=True)
class SnapshotRef:
    id: int
    fetched_at: str


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize(path: Path = DB_PATH) -> None:
    db = Database(path)
    db["snapshots"].create(
        {
            "id": int,
            "fetched_at": str,
            "limit": int,
        },
        pk="id",
        if_not_exists=True,
    )
    db["story_snapshots"].create(
        {
            "snapshot_id": int,
            "rank": int,
            "id": int,
            "title": str,
            "url": str,
            "score": int,
            "by": str,
            "time": int,
            "descendants": int,
            "type": str,
            "fetched_at": str,
        },
        pk=("snapshot_id", "id"),
        if_not_exists=True,
        foreign_keys=(("snapshot_id", "snapshots", "id"),),
    )
    conn = db.conn
    conn.execute(
        "CREATE VIRTUAL TABLE IF NOT EXISTS story_titles_fts "
        "USING fts5(id UNINDEXED, title)"
    )
    conn.commit()


def save_snapshot(stories: list[dict[str, Any]], limit: int, path: Path = DB_PATH) -> SnapshotRef:
    initialize(path)
    fetched_at = utc_now()
    with connect(path) as conn:
        cur = conn.execute(
            'INSERT INTO snapshots(fetched_at, "limit") VALUES (?, ?)',
            (fetched_at, limit),
        )
        snapshot_id = int(cur.lastrowid)
        for rank, story in enumerate(stories, start=1):
            row = normalize_story(story, fetched_at)
            conn.execute(
                """
                INSERT INTO story_snapshots(
                    snapshot_id, rank, id, title, url, score, by, time,
                    descendants, type, fetched_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    snapshot_id,
                    rank,
                    row["id"],
                    row["title"],
                    row["url"],
                    row["score"],
                    row["by"],
                    row["time"],
                    row["descendants"],
                    row["type"],
                    row["fetched_at"],
                ),
            )
            existing = conn.execute(
                "SELECT 1 FROM story_titles_fts WHERE id = ? LIMIT 1",
                (str(row["id"]),),
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE story_titles_fts SET title = ? WHERE id = ?",
                    (row["title"], str(row["id"])),
                )
            else:
                conn.execute(
                    "INSERT INTO story_titles_fts(id, title) VALUES (?, ?)",
                    (str(row["id"]), row["title"]),
                )
        conn.commit()
    return SnapshotRef(snapshot_id, fetched_at)


def normalize_story(story: dict[str, Any], fetched_at: str) -> dict[str, Any]:
    return {
        "id": int(story["id"]),
        "title": story.get("title") or "",
        "url": story.get("url"),
        "score": int(story.get("score") or 0),
        "by": story.get("by") or "",
        "time": int(story.get("time") or 0),
        "descendants": int(story.get("descendants") or 0),
        "type": story.get("type") or "",
        "fetched_at": fetched_at,
    }


def snapshot_ids(path: Path = DB_PATH) -> list[int]:
    initialize(path)
    with connect(path) as conn:
        return [row["id"] for row in conn.execute("SELECT id FROM snapshots ORDER BY id")]


def resolve_snapshot(snapshot: str, path: Path = DB_PATH) -> int:
    ids = snapshot_ids(path)
    if not ids:
        raise ValueError("No snapshots found. Run `hn-tracker fetch` first.")
    if snapshot.upper() == "LATEST":
        return ids[-1]
    snapshot_id = int(snapshot)
    if snapshot_id not in ids:
        raise ValueError(f"Snapshot {snapshot_id} does not exist.")
    return snapshot_id


def latest_two_snapshot_ids(path: Path = DB_PATH) -> tuple[int, int]:
    ids = snapshot_ids(path)
    if len(ids) < 2:
        raise ValueError("At least two snapshots are required.")
    return ids[-2], ids[-1]


def get_snapshot(snapshot_id: int, path: Path = DB_PATH) -> list[sqlite3.Row]:
    initialize(path)
    with connect(path) as conn:
        return list(
            conn.execute(
                "SELECT * FROM story_snapshots WHERE snapshot_id = ? ORDER BY rank",
                (snapshot_id,),
            )
        )


def stats(path: Path = DB_PATH) -> dict[str, Any]:
    initialize(path)
    with connect(path) as conn:
        authors = list(
            conn.execute(
                """
                SELECT by AS author, COUNT(*) AS appearances
                FROM story_snapshots
                WHERE by != ''
                GROUP BY by
                ORDER BY appearances DESC, author ASC
                LIMIT 5
                """
            )
        )
        return {
            "snapshots": conn.execute("SELECT COUNT(*) FROM snapshots").fetchone()[0],
            "unique_stories": conn.execute(
                "SELECT COUNT(DISTINCT id) FROM story_snapshots"
            ).fetchone()[0],
            "authors": authors,
            "oldest": conn.execute("SELECT MIN(fetched_at) FROM snapshots").fetchone()[0],
            "newest": conn.execute("SELECT MAX(fetched_at) FROM snapshots").fetchone()[0],
        }


def search_titles(query: str, path: Path = DB_PATH) -> list[sqlite3.Row]:
    initialize(path)
    with connect(path) as conn:
        return list(
            conn.execute(
                """
                SELECT f.id, f.title, COUNT(DISTINCT s.snapshot_id) AS snapshots
                FROM story_titles_fts f
                JOIN story_snapshots s ON s.id = CAST(f.id AS INTEGER)
                WHERE story_titles_fts MATCH ?
                GROUP BY f.id, f.title
                ORDER BY snapshots DESC, f.title ASC
                """,
                (query,),
            )
        )
