from __future__ import annotations

import asyncio
from typing import Any

import httpx


BASE_URL = "https://hacker-news.firebaseio.com/v0"


async def fetch_top_stories(limit: int) -> list[dict[str, Any]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(f"{BASE_URL}/topstories.json")
        response.raise_for_status()
        ids = response.json()[:limit]
        tasks = [fetch_item(client, item_id) for item_id in ids]
        items = await asyncio.gather(*tasks)
    return [item for item in items if item]


async def fetch_item(client: httpx.AsyncClient, item_id: int) -> dict[str, Any]:
    response = await client.get(f"{BASE_URL}/item/{item_id}.json")
    response.raise_for_status()
    return response.json() or {}


async def fetch_story_with_comments(story_id: int, comment_limit: int = 5) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        story = await fetch_item(client, story_id)
        kid_ids = story.get("kids", [])[:comment_limit]
        comments = await asyncio.gather(*(fetch_item(client, kid_id) for kid_id in kid_ids))
    return story, [comment for comment in comments if comment and not comment.get("deleted")]
