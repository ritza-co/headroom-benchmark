from __future__ import annotations

import asyncio
import csv
import io
import json
import logging
import sys
import time
from pathlib import Path
from typing import Annotated

import structlog
import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from hn_tracker import db
from hn_tracker.hn import fetch_story_with_comments, fetch_top_stories


structlog.configure(
    logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
    wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.add_log_level,
        structlog.processors.KeyValueRenderer(),
    ],
)

log = structlog.get_logger()
app = typer.Typer(help="Track Hacker News top stories over time.")
console = Console()
err_console = Console(stderr=True)


def _db_path() -> Path:
    return db.DB_PATH


@app.command()
def fetch(limit: Annotated[int, typer.Option("--limit", min=1)] = 30) -> None:
    """Fetch and save the current top Hacker News stories."""
    log.info("fetch.start", limit=limit)
    stories = asyncio.run(fetch_top_stories(limit))
    snapshot = db.save_snapshot(stories, limit=limit, path=_db_path())
    log.info("fetch.done", snapshot=snapshot.id, stories=len(stories))
    console.print(f"Saved snapshot {snapshot.id} with {len(stories)} stories at {snapshot.fetched_at}")


@app.command("list")
def list_cmd(snapshot: Annotated[str, typer.Option("--snapshot")] = "LATEST") -> None:
    """Print a saved snapshot."""
    try:
        snapshot_id = db.resolve_snapshot(snapshot, _db_path())
        rows = db.get_snapshot(snapshot_id, _db_path())
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    table = Table(title=f"Hacker News Snapshot {snapshot_id}")
    for column in ("Rank", "ID", "Score", "By", "Comments", "Title", "URL"):
        table.add_column(column)
    for row in rows:
        table.add_row(
            str(row["rank"]),
            str(row["id"]),
            str(row["score"]),
            row["by"],
            str(row["descendants"]),
            row["title"],
            row["url"] or "",
        )
    console.print(table)


def diff_snapshots(from_id: int, to_id: int) -> dict[str, list[dict[str, object]]]:
    before = {row["id"]: row for row in db.get_snapshot(from_id, _db_path())}
    after = {row["id"]: row for row in db.get_snapshot(to_id, _db_path())}
    entered = [
        {"id": row["id"], "rank": row["rank"], "title": row["title"]}
        for story_id, row in after.items()
        if story_id not in before
    ]
    left = [
        {"id": row["id"], "rank": row["rank"], "title": row["title"]}
        for story_id, row in before.items()
        if story_id not in after
    ]
    changed = []
    for story_id in sorted(before.keys() & after.keys()):
        old_rank = before[story_id]["rank"]
        new_rank = after[story_id]["rank"]
        if old_rank != new_rank:
            changed.append(
                {
                    "id": story_id,
                    "from": old_rank,
                    "to": new_rank,
                    "delta": old_rank - new_rank,
                    "title": after[story_id]["title"],
                }
            )
    return {"entered": entered, "left": left, "changed": changed}


@app.command()
def diff(
    from_snapshot: Annotated[int | None, typer.Option("--from")] = None,
    to_snapshot: Annotated[int | None, typer.Option("--to")] = None,
) -> None:
    """Compare two saved snapshots."""
    try:
        if from_snapshot is None or to_snapshot is None:
            from_snapshot, to_snapshot = db.latest_two_snapshot_ids(_db_path())
        result = diff_snapshots(from_snapshot, to_snapshot)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    table = Table(title=f"Snapshot Diff {from_snapshot} -> {to_snapshot}")
    table.add_column("Change")
    table.add_column("ID")
    table.add_column("Rank")
    table.add_column("Delta")
    table.add_column("Title")
    for row in result["entered"]:
        table.add_row("entered", str(row["id"]), str(row["rank"]), "", str(row["title"]))
    for row in result["left"]:
        table.add_row("left", str(row["id"]), str(row["rank"]), "", str(row["title"]))
    for row in result["changed"]:
        table.add_row(
            "rank",
            str(row["id"]),
            f"{row['from']} -> {row['to']}",
            f"{row['delta']:+}",
            str(row["title"]),
        )
    console.print(table)


@app.command()
def story(id: int) -> None:
    """Fetch one story and its first five top-level comments."""
    story_data, comments = asyncio.run(fetch_story_with_comments(id, 5))
    if not story_data:
        raise typer.BadParameter(f"Story {id} was not found.")
    table = Table(title=f"Story {id}")
    table.add_column("Field")
    table.add_column("Value")
    for key in ("title", "url", "score", "by", "time", "descendants", "type"):
        table.add_row(key, str(story_data.get(key, "")))
    console.print(table)
    for comment in comments:
        text = (comment.get("text") or "").replace("<p>", "\n").replace("</p>", "")
        console.print(Panel(Markdown(text), title=f"Comment by {comment.get('by', '')}"))


@app.command()
def search(query: str) -> None:
    """Search saved story titles."""
    rows = db.search_titles(query, _db_path())
    table = Table(title=f"Search: {query}")
    table.add_column("ID")
    table.add_column("Snapshots")
    table.add_column("Title")
    for row in rows:
        table.add_row(str(row["id"]), str(row["snapshots"]), row["title"])
    console.print(table)


@app.command()
def stats() -> None:
    """Print database statistics."""
    data = db.stats(_db_path())
    table = Table(title="HN Tracker Stats")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Snapshots", str(data["snapshots"]))
    table.add_row("Unique stories", str(data["unique_stories"]))
    table.add_row("Oldest fetched_at", str(data["oldest"] or ""))
    table.add_row("Newest fetched_at", str(data["newest"] or ""))
    for author in data["authors"]:
        table.add_row(f"Author: {author['author']}", str(author["appearances"]))
    console.print(table)


def latest_snapshot_rows() -> list[dict[str, object]]:
    snapshot_id = db.resolve_snapshot("LATEST", _db_path())
    return [dict(row) for row in db.get_snapshot(snapshot_id, _db_path())]


@app.command()
def export(format: str) -> None:
    """Export the latest snapshot as json, csv, or markdown."""
    rows = latest_snapshot_rows()
    if format == "json":
        typer.echo(json.dumps(rows, indent=2))
    elif format == "csv":
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()) if rows else [])
        writer.writeheader()
        writer.writerows(rows)
        typer.echo(output.getvalue(), nl=False)
    elif format == "markdown":
        headers = list(rows[0].keys()) if rows else ["snapshot_id", "rank", "id", "title"]
        typer.echo("| " + " | ".join(headers) + " |")
        typer.echo("| " + " | ".join("---" for _ in headers) + " |")
        for row in rows:
            typer.echo("| " + " | ".join(str(row.get(header) or "").replace("|", "\\|") for header in headers) + " |")
    else:
        raise typer.BadParameter("format must be json, csv, or markdown")


@app.command()
def watch(interval: Annotated[int, typer.Option("--interval", min=1)] = 60) -> None:
    """Fetch repeatedly until interrupted."""
    previous: int | None = None
    try:
        while True:
            stories = asyncio.run(fetch_top_stories(30))
            snapshot = db.save_snapshot(stories, limit=30, path=_db_path())
            if previous is None:
                console.print(f"snapshot={snapshot.id} stories={len(stories)}")
            else:
                result = diff_snapshots(previous, snapshot.id)
                console.print(
                    f"snapshot={snapshot.id} entered={len(result['entered'])} "
                    f"left={len(result['left'])} rank_changed={len(result['changed'])}"
                )
            previous = snapshot.id
            time.sleep(interval)
    except KeyboardInterrupt:
        err_console.print("Stopped.")


def main() -> None:
    app()
