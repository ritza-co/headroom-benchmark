def main() -> None:
    print("Hello from hn-tracker!")
__version__ = "0.1.0"
