from typer.testing import CliRunner

from hn_tracker.cli import app


def test_help_lists_all_subcommands():
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    for command in ("fetch", "list", "diff", "story", "search", "stats", "export", "watch"):
        assert command in result.stdout
