from __future__ import annotations

import asyncio
import csv
import io
import json

import pytest
from typer.testing import CliRunner

from hn_tracker import db
from hn_tracker.cli import app
from hn_tracker.hn import fetch_top_stories


runner = CliRunner()


def story_row(story_id: int, title: str, rank_score: int = 100, by: str = "alice") -> dict[str, object]:
    return {
        "id": story_id,
        "title": title,
        "url": f"https://example.com/{story_id}",
        "score": rank_score,
        "by": by,
        "time": 1_700_000_000 + story_id,
        "descendants": story_id % 10,
        "type": "story",
    }


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    db.initialize()
    return tmp_path / "hn.db"


def test_fetch_command_saves_snapshot(temp_db, mocker):
    mocker.patch(
        "hn_tracker.cli.fetch_top_stories",
        return_value=[story_row(1, "Python release"), story_row(2, "Rust news")],
    )
    result = runner.invoke(app, ["fetch", "--limit", "2"])
    assert result.exit_code == 0
    assert "Saved snapshot 1 with 2 stories" in result.stdout
    assert len(db.get_snapshot(1)) == 2


def test_list_command_prints_latest_snapshot(temp_db):
    db.save_snapshot([story_row(1, "Python release")], 1)
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "Hacker News Snapshot 1" in result.stdout
    assert "Python release" in result.stdout


def test_diff_command_identifies_entered_left_and_rank_changed(temp_db):
    db.save_snapshot(
        [story_row(1, "One"), story_row(2, "Two"), story_row(3, "Three")],
        3,
    )
    db.save_snapshot(
        [story_row(2, "Two"), story_row(4, "Four"), story_row(1, "One")],
        3,
    )
    result = runner.invoke(app, ["diff", "--from", "1", "--to", "2"])
    assert result.exit_code == 0
    assert "entered" in result.stdout
    assert "left" in result.stdout
    assert "rank" in result.stdout
    assert "Four" in result.stdout
    assert "Three" in result.stdout
    assert "1 -> 3" in result.stdout


def test_story_command_fetches_metadata_and_comments(mocker):
    mocker.patch(
        "hn_tracker.cli.fetch_story_with_comments",
        return_value=(
            {"id": 42, "title": "A story", "score": 10, "by": "pg", "time": 1, "descendants": 2, "type": "story"},
            [{"id": 43, "by": "alice", "text": "Nice work"}],
        ),
    )
    result = runner.invoke(app, ["story", "42"])
    assert result.exit_code == 0
    assert "A story" in result.stdout
    assert "Nice work" in result.stdout


def test_search_command_finds_saved_title(temp_db):
    db.save_snapshot([story_row(1, "Rust database engine")], 1)
    result = runner.invoke(app, ["search", "rust"])
    assert result.exit_code == 0
    assert "Rust database engine" in result.stdout


def test_fts5_search_returns_results_across_multiple_snapshots(temp_db):
    db.save_snapshot([story_row(1, "Rust database engine"), story_row(2, "Python web")], 2)
    db.save_snapshot([story_row(1, "Rust database engine"), story_row(3, "Rust kernel")], 2)
    rows = db.search_titles("rust")
    found = {row["title"]: row["snapshots"] for row in rows}
    assert found["Rust database engine"] == 2
    assert found["Rust kernel"] == 1


def test_stats_command_prints_database_stats(temp_db):
    db.save_snapshot([story_row(1, "One", by="alice"), story_row(2, "Two", by="bob")], 2)
    db.save_snapshot([story_row(3, "Three", by="alice")], 1)
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "Snapshots" in result.stdout
    assert "Unique stories" in result.stdout
    assert "Author: alice" in result.stdout


def test_export_json_and_csv_are_valid(temp_db):
    db.save_snapshot([story_row(1, "One")], 1)
    json_result = runner.invoke(app, ["export", "json"])
    assert json_result.exit_code == 0
    payload = json.loads(json_result.stdout)
    assert payload[0]["title"] == "One"

    csv_result = runner.invoke(app, ["export", "csv"])
    assert csv_result.exit_code == 0
    rows = list(csv.DictReader(io.StringIO(csv_result.stdout)))
    assert rows[0]["title"] == "One"


def test_export_markdown_command(temp_db):
    db.save_snapshot([story_row(1, "One")], 1)
    result = runner.invoke(app, ["export", "markdown"])
    assert result.exit_code == 0
    assert "| snapshot_id |" in result.stdout
    assert "One" in result.stdout


def test_watch_command_prints_summary_and_stops(temp_db, mocker):
    mocker.patch(
        "hn_tracker.cli.fetch_top_stories",
        side_effect=[
            [story_row(1, "One")],
            [story_row(2, "Two"), story_row(1, "One")],
        ],
    )
    mocker.patch("time.sleep", side_effect=[None, KeyboardInterrupt])
    result = runner.invoke(app, ["watch", "--interval", "1"])
    assert result.exit_code == 0
    assert "snapshot=1 stories=1" in result.stdout
    assert "snapshot=2 entered=1 left=0 rank_changed=1" in result.stdout


@pytest.mark.asyncio
async def test_fetch_uses_concurrent_item_requests(monkeypatch):
    state = {"in_flight": 0, "max_in_flight": 0}

    class FakeResponse:
        def __init__(self, payload):
            self._payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self._payload

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def get(self, url):
            if url.endswith("/topstories.json"):
                return FakeResponse([1, 2, 3, 4])
            state["in_flight"] += 1
            state["max_in_flight"] = max(state["max_in_flight"], state["in_flight"])
            await asyncio.sleep(0.01)
            item_id = int(url.rsplit("/", 1)[1].split(".")[0])
            state["in_flight"] -= 1
            return FakeResponse(story_row(item_id, f"Story {item_id}"))

    monkeypatch.setattr("hn_tracker.hn.httpx.AsyncClient", FakeAsyncClient)
    stories = await fetch_top_stories(4)
    assert len(stories) == 4
    assert state["max_in_flight"] > 1
