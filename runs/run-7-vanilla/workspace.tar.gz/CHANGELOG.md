# Changelog

## 0.1.0 - 2026-06-04

- Added `fetch` to store concurrent Hacker News top-story snapshots in SQLite.
- Added `list` to render saved snapshots as Rich tables.
- Added `diff` to compare entered, left, and rank-changed stories.
- Added `story` to fetch live metadata and the first five top-level comments.
- Added `search` backed by SQLite FTS5 title indexing.
- Added `stats` for snapshot, story, author, and timestamp database metrics.
- Added `export` for JSON, CSV, and Markdown latest-snapshot output.
- Added `watch` for repeated fetches with one-line change summaries.
- Added Dockerfile, GitHub Actions CI, pytest coverage, and uv-managed packaging.
