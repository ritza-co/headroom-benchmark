from __future__ import annotations

import asyncio
from typing import Any

import httpx

BASE_URL = "https://hacker-news.firebaseio.com/v0"


async def fetch_json(client: httpx.AsyncClient, path: str) -> Any:
    response = await client.get(f"{BASE_URL}/{path}.json")
    response.raise_for_status()
    return response.json()


async def fetch_top_stories(limit: int) -> list[dict[str, Any]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        ids = await fetch_json(client, "topstories")
        selected = ids[:limit]
        items = await asyncio.gather(*(fetch_json(client, f"item/{item_id}") for item_id in selected))
    return [item for item in items if item]


async def fetch_story_with_comments(story_id: int, comment_limit: int = 5) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        story = await fetch_json(client, f"item/{story_id}")
        if not story:
            raise ValueError(f"Story {story_id} was not found")
        kids = story.get("kids", [])[:comment_limit]
        comments = await asyncio.gather(*(fetch_json(client, f"item/{kid}") for kid in kids))
    return story, [comment for comment in comments if comment and not comment.get("deleted") and not comment.get("dead")]
