from __future__ import annotations

import csv
import io
import json
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable

from sqlite_utils import Database

DB_PATH = Path("hn.db")


@dataclass(frozen=True)
class SnapshotSummary:
    snapshot_id: int
    fetched_at: str
    story_count: int


def now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(path: Path = DB_PATH) -> None:
    db = Database(path)
    db["snapshots"].create(
        {"id": int, "fetched_at": str},
        pk="id",
        if_not_exists=True,
    )
    db["story_snapshots"].create(
        {
            "snapshot_id": int,
            "rank": int,
            "id": int,
            "title": str,
            "url": str,
            "score": int,
            "by": str,
            "time": int,
            "descendants": int,
            "type": str,
            "fetched_at": str,
        },
        pk=("snapshot_id", "id"),
        if_not_exists=True,
    )
    db.conn.execute(
        "CREATE VIRTUAL TABLE IF NOT EXISTS story_fts USING fts5("
        "title, story_id UNINDEXED, snapshot_id UNINDEXED, story_rank UNINDEXED, fetched_at UNINDEXED)"
    )
    db.conn.commit()


def save_snapshot(stories: Iterable[dict[str, Any]], path: Path = DB_PATH, fetched_at: str | None = None) -> SnapshotSummary:
    init_db(path)
    fetched_at = fetched_at or now_iso()
    with connect(path) as conn:
        cur = conn.execute("INSERT INTO snapshots(fetched_at) VALUES (?)", (fetched_at,))
        snapshot_id = int(cur.lastrowid)
        rows = []
        fts_rows = []
        for rank, story in enumerate(stories, start=1):
            row = {
                "snapshot_id": snapshot_id,
                "rank": rank,
                "id": int(story["id"]),
                "title": story.get("title") or "",
                "url": story.get("url"),
                "score": story.get("score") or 0,
                "by": story.get("by") or "",
                "time": story.get("time") or 0,
                "descendants": story.get("descendants") or 0,
                "type": story.get("type") or "",
                "fetched_at": fetched_at,
            }
            rows.append(row)
            fts_rows.append((row["title"], row["id"], snapshot_id, rank, fetched_at))
        conn.executemany(
            """
            INSERT INTO story_snapshots(
                snapshot_id, rank, id, title, url, score, by, time, descendants, type, fetched_at
            ) VALUES (
                :snapshot_id, :rank, :id, :title, :url, :score, :by, :time, :descendants, :type, :fetched_at
            )
            """,
            rows,
        )
        conn.executemany(
            "INSERT INTO story_fts(title, story_id, snapshot_id, story_rank, fetched_at) VALUES (?, ?, ?, ?, ?)",
            fts_rows,
        )
    return SnapshotSummary(snapshot_id=snapshot_id, fetched_at=fetched_at, story_count=len(rows))


def snapshot_ids(path: Path = DB_PATH) -> list[int]:
    init_db(path)
    with connect(path) as conn:
        return [row["id"] for row in conn.execute("SELECT id FROM snapshots ORDER BY id")]


def resolve_snapshot(selector: str | int | None, path: Path = DB_PATH, *, latest_offset: int = 0) -> int | None:
    ids = snapshot_ids(path)
    if not ids:
        return None
    if selector is None or str(selector).upper() == "LATEST":
        index = -1 - latest_offset
        if abs(index) > len(ids):
            return None
        return ids[index]
    snap_id = int(selector)
    return snap_id if snap_id in ids else None


def get_snapshot(snapshot_id: int, path: Path = DB_PATH) -> list[sqlite3.Row]:
    init_db(path)
    with connect(path) as conn:
        return list(conn.execute("SELECT * FROM story_snapshots WHERE snapshot_id = ? ORDER BY rank", (snapshot_id,)))


def diff_snapshots(from_id: int, to_id: int, path: Path = DB_PATH) -> dict[str, list[dict[str, Any]]]:
    before = {row["id"]: row for row in get_snapshot(from_id, path)}
    after = {row["id"]: row for row in get_snapshot(to_id, path)}
    entered = [dict(after[item_id]) for item_id in after.keys() - before.keys()]
    left = [dict(before[item_id]) for item_id in before.keys() - after.keys()]
    changed = []
    for item_id in before.keys() & after.keys():
        old_rank = before[item_id]["rank"]
        new_rank = after[item_id]["rank"]
        if old_rank != new_rank:
            row = dict(after[item_id])
            row["from_rank"] = old_rank
            row["to_rank"] = new_rank
            row["delta"] = old_rank - new_rank
            changed.append(row)
    return {
        "entered": sorted(entered, key=lambda row: row["rank"]),
        "left": sorted(left, key=lambda row: row["rank"]),
        "changed": sorted(changed, key=lambda row: row["to_rank"]),
    }


def search_titles(query: str, path: Path = DB_PATH) -> list[sqlite3.Row]:
    init_db(path)
    with connect(path) as conn:
        return list(
            conn.execute(
                """
                SELECT story_id AS id, title, snapshot_id, story_rank AS rank, fetched_at
                FROM story_fts
                WHERE story_fts MATCH ?
                ORDER BY snapshot_id DESC, rank ASC
                """,
                (query,),
            )
        )


def stats(path: Path = DB_PATH) -> dict[str, Any]:
    init_db(path)
    with connect(path) as conn:
        author_rows = conn.execute(
            """
            SELECT by AS author, COUNT(*) AS count
            FROM story_snapshots
            WHERE by != ''
            GROUP BY by
            ORDER BY count DESC, author ASC
            LIMIT 5
            """
        ).fetchall()
        row = conn.execute(
            """
            SELECT
              (SELECT COUNT(*) FROM snapshots) AS snapshots_count,
              COUNT(DISTINCT id) AS unique_stories,
              MIN(fetched_at) AS oldest_fetched_at,
              MAX(fetched_at) AS newest_fetched_at
            FROM story_snapshots
            """
        ).fetchone()
    return {
        "snapshots_count": row["snapshots_count"],
        "unique_stories": row["unique_stories"],
        "top_authors": [dict(author) for author in author_rows],
        "oldest_fetched_at": row["oldest_fetched_at"],
        "newest_fetched_at": row["newest_fetched_at"],
    }


def export_snapshot(fmt: str, path: Path = DB_PATH) -> str:
    snapshot_id = resolve_snapshot("LATEST", path)
    if snapshot_id is None:
        return "[]\n" if fmt == "json" else ""
    rows = [dict(row) for row in get_snapshot(snapshot_id, path)]
    if fmt == "json":
        return json.dumps(rows, indent=2) + "\n"
    if fmt == "csv":
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()) if rows else [])
        if rows:
            writer.writeheader()
            writer.writerows(rows)
        return output.getvalue()
    if fmt == "markdown":
        headers = ["rank", "id", "title", "score", "by", "url"]
        lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
        for row in rows:
            values = [str(row[key] or "").replace("|", "\\|") for key in headers]
            lines.append("| " + " | ".join(values) + " |")
        return "\n".join(lines) + "\n"
    raise ValueError(f"Unsupported export format: {fmt}")
