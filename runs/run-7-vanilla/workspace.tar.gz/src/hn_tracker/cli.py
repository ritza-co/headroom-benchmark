from __future__ import annotations

import asyncio
import html
import sys
import time
from typing import Annotated

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hn_tracker import db, hn

app = typer.Typer(no_args_is_help=True, help="Track Hacker News top stories over time.")
console = Console()
err_console = Console(stderr=True)
log = structlog.get_logger()


def configure_logging() -> None:
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.KeyValueRenderer(key_order=["timestamp", "level", "event"]),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(20),
        cache_logger_on_first_use=True,
    )


def story_table(rows, title: str) -> Table:
    table = Table(title=title)
    for column in ["Rank", "ID", "Score", "By", "Comments", "Title", "URL"]:
        table.add_column(column, overflow="fold" if column in {"Title", "URL"} else "ellipsis")
    for row in rows:
        table.add_row(
            str(row["rank"]),
            str(row["id"]),
            str(row["score"]),
            row["by"] or "",
            str(row["descendants"]),
            row["title"] or "",
            row["url"] or "",
        )
    return table


@app.callback()
def main() -> None:
    configure_logging()


@app.command()
def fetch(limit: Annotated[int, typer.Option("--limit", min=1, help="Number of top stories to fetch.")] = 30) -> None:
    """Fetch the current top stories and store them as a new snapshot."""
    stories = asyncio.run(hn.fetch_top_stories(limit))
    summary = db.save_snapshot(stories)
    log.info("fetch_complete", snapshot_id=summary.snapshot_id, story_count=summary.story_count)
    console.print(f"Fetched {summary.story_count} stories into snapshot {summary.snapshot_id} at {summary.fetched_at}.")


@app.command("list")
def list_snapshot(snapshot: Annotated[str, typer.Option("--snapshot", help="LATEST or a snapshot id.")] = "LATEST") -> None:
    """Print a saved snapshot."""
    snapshot_id = db.resolve_snapshot(snapshot)
    if snapshot_id is None:
        raise typer.Exit("No matching snapshot found.")
    rows = db.get_snapshot(snapshot_id)
    console.print(story_table(rows, f"Snapshot {snapshot_id}"))


@app.command()
def diff(
    from_snapshot: Annotated[int | None, typer.Option("--from", help="Older snapshot id.")] = None,
    to_snapshot: Annotated[int | None, typer.Option("--to", help="Newer snapshot id.")] = None,
) -> None:
    """Compare two snapshots."""
    from_id = from_snapshot if from_snapshot is not None else db.resolve_snapshot(None, latest_offset=1)
    to_id = to_snapshot if to_snapshot is not None else db.resolve_snapshot(None)
    if from_id is None or to_id is None:
        raise typer.Exit("At least two snapshots are required.")
    result = db.diff_snapshots(from_id, to_id)
    console.print(f"Diff snapshot {from_id} -> {to_id}")
    for label, rows in [("Entered", result["entered"]), ("Left", result["left"]), ("Rank changed", result["changed"])]:
        table = Table(title=label)
        columns = ["Rank", "ID", "Delta", "Title"] if label == "Rank changed" else ["Rank", "ID", "Title"]
        for column in columns:
            table.add_column(column)
        for row in rows:
            if label == "Rank changed":
                table.add_row(f"{row['from_rank']} -> {row['to_rank']}", str(row["id"]), f"{row['delta']:+}", row["title"])
            else:
                table.add_row(str(row["rank"]), str(row["id"]), row["title"])
        console.print(table)


@app.command()
def story(id: int) -> None:
    """Fetch and print one live story with its first five top-level comments."""
    item, comments = asyncio.run(hn.fetch_story_with_comments(id))
    meta = Table.grid(padding=(0, 1))
    meta.add_column(style="bold")
    meta.add_column()
    for key in ["id", "title", "url", "score", "by", "time", "descendants", "type"]:
        meta.add_row(key, str(item.get(key, "")))
    console.print(Panel(meta, title="Story"))
    table = Table(title="Top-level comments")
    table.add_column("ID")
    table.add_column("By")
    table.add_column("Text", overflow="fold")
    for comment in comments:
        table.add_row(str(comment.get("id", "")), comment.get("by", ""), html.unescape(comment.get("text", "")))
    console.print(table)


@app.command()
def search(query: str) -> None:
    """Search saved story titles."""
    rows = db.search_titles(query)
    table = Table(title=f"Search: {query}")
    for column in ["Snapshot", "Rank", "ID", "Title", "Fetched At"]:
        table.add_column(column)
    for row in rows:
        table.add_row(str(row["snapshot_id"]), str(row["rank"]), str(row["id"]), row["title"], row["fetched_at"])
    console.print(table)


@app.command()
def stats() -> None:
    """Print database statistics."""
    data = db.stats()
    table = Table(title="HN Tracker Stats")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Snapshots", str(data["snapshots_count"]))
    table.add_row("Unique stories", str(data["unique_stories"]))
    table.add_row("Oldest fetched_at", str(data["oldest_fetched_at"] or ""))
    table.add_row("Newest fetched_at", str(data["newest_fetched_at"] or ""))
    console.print(table)
    authors = Table(title="Top authors")
    authors.add_column("Author")
    authors.add_column("Rows")
    for author in data["top_authors"]:
        authors.add_row(author["author"], str(author["count"]))
    console.print(authors)


@app.command()
def export(format: Annotated[str, typer.Argument(help="json, csv, or markdown")]) -> None:
    """Export the latest snapshot to stdout."""
    fmt = format.lower()
    if fmt not in {"json", "csv", "markdown"}:
        raise typer.BadParameter("format must be json, csv, or markdown")
    sys.stdout.write(db.export_snapshot(fmt))


@app.command()
def watch(interval: Annotated[int, typer.Option("--interval", min=1, help="Seconds between fetches.")] = 60) -> None:
    """Fetch repeatedly until Ctrl-C."""
    previous = db.resolve_snapshot(None)
    try:
        while True:
            stories = asyncio.run(hn.fetch_top_stories(30))
            summary = db.save_snapshot(stories)
            if previous is None:
                console.print(f"snapshot={summary.snapshot_id} stories={summary.story_count} initial=true")
            else:
                result = db.diff_snapshots(previous, summary.snapshot_id)
                console.print(
                    f"snapshot={summary.snapshot_id} stories={summary.story_count} "
                    f"entered={len(result['entered'])} left={len(result['left'])} rank_changed={len(result['changed'])}"
                )
            log.info("watch_fetch_complete", snapshot_id=summary.snapshot_id, story_count=summary.story_count)
            previous = summary.snapshot_id
            time.sleep(interval)
    except KeyboardInterrupt:
        err_console.print("Stopped.")
