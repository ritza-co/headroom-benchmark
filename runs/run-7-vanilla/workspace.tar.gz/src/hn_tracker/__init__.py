"""Hacker News snapshot tracker."""

from hn_tracker.cli import app

__all__ = ["app"]


def main() -> None:
    app()
