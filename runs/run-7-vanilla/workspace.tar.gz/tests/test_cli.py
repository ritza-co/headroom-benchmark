from __future__ import annotations

import asyncio
import csv
import io
import json
from typing import Any

from typer.testing import CliRunner

from hn_tracker import db, hn
from hn_tracker.cli import app

runner = CliRunner()


def make_story(story_id: int, rank_title: str | None = None, by: str = "alice") -> dict[str, Any]:
    return {
        "id": story_id,
        "title": rank_title or f"Story {story_id}",
        "url": f"https://example.com/{story_id}",
        "score": story_id,
        "by": by,
        "time": 1_700_000_000 + story_id,
        "descendants": story_id % 10,
        "type": "story",
    }


def save_pair() -> tuple[int, int]:
    first = db.save_snapshot(
        [make_story(1, "Alpha Rust", "alice"), make_story(2, "Beta Python", "bob"), make_story(3, "Gamma", "alice")],
        fetched_at="2026-01-01T00:00:00+00:00",
    ).snapshot_id
    second = db.save_snapshot(
        [make_story(4, "Delta", "carol"), make_story(2, "Beta Python", "bob"), make_story(1, "Alpha Rust", "alice")],
        fetched_at="2026-01-01T00:01:00+00:00",
    ).snapshot_id
    return first, second


def test_fetch_command_stores_snapshot(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    async def fake_fetch(limit: int):
        return [make_story(i) for i in range(1, limit + 1)]

    monkeypatch.setattr("hn_tracker.cli.hn.fetch_top_stories", fake_fetch)
    result = runner.invoke(app, ["fetch", "--limit", "3"])
    assert result.exit_code == 0
    assert "Fetched 3 stories into snapshot 1" in result.stdout
    assert len(db.get_snapshot(1)) == 3


def test_list_command_prints_latest_snapshot(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    save_pair()
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "Snapshot 2" in result.stdout
    assert "Delta" in result.stdout


def test_diff_command_identifies_entered_left_and_rank_changed(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    first, second = save_pair()
    result = db.diff_snapshots(first, second)
    assert [row["id"] for row in result["entered"]] == [4]
    assert [row["id"] for row in result["left"]] == [3]
    changed = {row["id"]: row["delta"] for row in result["changed"]}
    assert changed == {1: -2, 2: 0} or changed == {1: -2}
    cli = runner.invoke(app, ["diff", "--from", str(first), "--to", str(second)])
    assert cli.exit_code == 0
    assert "Entered" in cli.stdout
    assert "Delta" in cli.stdout
    assert "1 -> 3" in cli.stdout


def test_story_command_prints_metadata_and_comments(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    async def fake_story(story_id: int, comment_limit: int = 5):
        return make_story(story_id, "One Story"), [
            {"id": 10, "by": "reader", "text": "first &amp; useful"},
            {"id": 11, "by": "reader2", "text": "second"},
        ]

    monkeypatch.setattr("hn_tracker.cli.hn.fetch_story_with_comments", fake_story)
    result = runner.invoke(app, ["story", "123"])
    assert result.exit_code == 0
    assert "One Story" in result.stdout
    assert "first & useful" in result.stdout


def test_search_command_and_fts_across_multiple_snapshots(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    save_pair()
    rows = db.search_titles("Rust")
    assert [row["id"] for row in rows] == [1, 1]
    result = runner.invoke(app, ["search", "Rust"])
    assert result.exit_code == 0
    assert "Alpha Rust" in result.stdout


def test_stats_command(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    save_pair()
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "Snapshots" in result.stdout
    assert "Unique stories" in result.stdout
    assert "alice" in result.stdout


def test_export_json_and_csv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    save_pair()
    json_result = runner.invoke(app, ["export", "json"])
    assert json_result.exit_code == 0
    parsed = json.loads(json_result.stdout)
    assert parsed[0]["id"] == 4

    csv_result = runner.invoke(app, ["export", "csv"])
    assert csv_result.exit_code == 0
    rows = list(csv.DictReader(io.StringIO(csv_result.stdout)))
    assert rows[0]["id"] == "4"


def test_export_markdown_command(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    save_pair()
    result = runner.invoke(app, ["export", "markdown"])
    assert result.exit_code == 0
    assert "| rank | id | title |" in result.stdout


def test_watch_command_fetches_and_prints_summary(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    calls = {"sleep": 0}

    async def fake_fetch(limit: int):
        return [make_story(1, "Stable"), make_story(2, "Next")]

    def fake_sleep(interval: int):
        calls["sleep"] += 1
        raise KeyboardInterrupt

    monkeypatch.setattr("hn_tracker.cli.hn.fetch_top_stories", fake_fetch)
    monkeypatch.setattr("hn_tracker.cli.time.sleep", fake_sleep)
    result = runner.invoke(app, ["watch", "--interval", "1"])
    assert result.exit_code == 0
    assert "snapshot=1" in result.stdout
    assert calls["sleep"] == 1


def test_fetch_top_stories_uses_concurrent_item_requests(monkeypatch):
    in_flight = {"count": 0, "max": 0}

    class FakeResponse:
        def __init__(self, payload):
            self.payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self.payload

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def get(self, url: str):
            if url.endswith("/topstories.json"):
                return FakeResponse([1, 2, 3, 4])
            in_flight["count"] += 1
            in_flight["max"] = max(in_flight["max"], in_flight["count"])
            await asyncio.sleep(0.01)
            story_id = int(url.split("/item/")[1].split(".")[0])
            in_flight["count"] -= 1
            return FakeResponse(make_story(story_id))

    monkeypatch.setattr(hn.httpx, "AsyncClient", FakeAsyncClient)
    stories = asyncio.run(hn.fetch_top_stories(4))
    assert [story["id"] for story in stories] == [1, 2, 3, 4]
    assert in_flight["max"] > 1
