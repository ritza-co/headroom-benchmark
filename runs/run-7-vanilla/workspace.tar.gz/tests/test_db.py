from __future__ import annotations

from hn_tracker import db


def test_resolve_snapshot_by_latest_and_id(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    first = db.save_snapshot([{"id": 1, "title": "One", "type": "story"}]).snapshot_id
    second = db.save_snapshot([{"id": 2, "title": "Two", "type": "story"}]).snapshot_id
    assert db.resolve_snapshot("LATEST") == second
    assert db.resolve_snapshot(first) == first
    assert db.resolve_snapshot(None, latest_offset=1) == first
