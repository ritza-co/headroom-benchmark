# hn-tracker

`hn-tracker` is a Python CLI for tracking Hacker News top stories over time.

It fetches snapshots from the public Hacker News Firebase API.

It stores those snapshots in a local SQLite database named `hn.db`.

It uses concurrent `httpx` requests for story detail fetches.

It renders human-facing output with `rich`.

It exposes full-text search through SQLite FTS5.

It is packaged and run with `uv`.

The default database location is the current working directory.

That means every folder can have its own independent `hn.db`.

The project is intentionally small enough to read but complete enough to use.

## Install

Install `uv` first if it is not already present.

The official project workflow is based on `uv init`, `uv add`, `uv sync`, and `uv run`.

Clone or enter this repository.

Run:

```bash
uv sync
```

Smoke test the CLI:

```bash
uv run hn-tracker --help
```

Fetch your first snapshot:

```bash
uv run hn-tracker fetch --limit 30
```

List it:

```bash
uv run hn-tracker list
```

The CLI writes structured INFO logs to stderr.

Command data intended for piping is written to stdout.

## Subcommands

There are eight main subcommands.

Each command is covered by tests.

### fetch

Fetch the current top Hacker News stories.

Default limit is 30.

The command creates `hn.db` if it does not exist.

Example:

```bash
uv run hn-tracker fetch --limit 5
```

Example output:

```text
Fetched 5 stories into snapshot 1 at 2026-06-04T14:00:00+00:00.
```

Stored columns include `id`, `title`, `url`, `score`, `by`, `time`, `descendants`, `type`, and `fetched_at`.

The implementation also stores `snapshot_id` and `rank` so snapshots can be compared later.

Story metadata requests are run concurrently after loading the `topstories` id list.

### list

Render a saved snapshot as a Rich table.

Default snapshot is `LATEST`.

Example:

```bash
uv run hn-tracker list
```

Example output:

```text
                              Snapshot 3
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━┳━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━┓
┃ Rank ┃ ID       ┃ Score ┃ By     ┃ Comments ┃ Title        ┃ URL    ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━╇━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━┩
│ 1    │ 12345678 │ 512   │ user42 │ 120      │ Example item │ https… │
└──────┴──────────┴───────┴────────┴──────────┴──────────────┴────────┘
```

To list a specific snapshot:

```bash
uv run hn-tracker list --snapshot 2
```

### diff

Compare two snapshots.

By default it compares the two most recent snapshots.

Example:

```bash
uv run hn-tracker diff
```

Example output:

```text
Diff snapshot 2 -> 3
Entered
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━┓
┃ Rank ┃ ID       ┃ Title      ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━┩
│ 4    │ 98765432 │ New story  │
└──────┴──────────┴────────────┘
```

Use explicit snapshot ids:

```bash
uv run hn-tracker diff --from 1 --to 3
```

The diff reports stories that entered, stories that left, and stories with changed rank.

Rank delta is positive when the story moved up.

Rank delta is negative when the story moved down.

### story

Fetch one live Hacker News item by id.

It displays metadata and the first five top-level comments.

Example:

```bash
uv run hn-tracker story 8863
```

Example output:

```text
╭──────────── Story ────────────╮
│ id          8863              │
│ title       My YC app         │
│ score       111               │
│ by          pg                │
╰───────────────────────────────╯
```

Comments are fetched from the HN item API.

HTML entities in comment text are unescaped for readability.

### search

Search saved story titles.

Search is powered by SQLite FTS5.

Example:

```bash
uv run hn-tracker search rust
```

Example output:

```text
                    Search: rust
┏━━━━━━━━━━┳━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ Snapshot ┃ Rank ┃ ID       ┃ Title          ┃ Fetched At         ┃
┡━━━━━━━━━━╇━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ 3        │ 7    │ 11111111 │ Rust compiler… │ 2026-06-04T14:00… │
└──────────┴──────┴──────────┴────────────────┴────────────────────┘
```

The same story can appear multiple times if it matched in multiple snapshots.

That is intentional because the tool tracks observations over time.

### stats

Show database statistics.

Example:

```bash
uv run hn-tracker stats
```

Example output:

```text
HN Tracker Stats
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric            ┃ Value                     ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Snapshots         │ 4                         │
│ Unique stories    │ 87                        │
│ Oldest fetched_at │ 2026-06-04T12:00:00+00:00 │
│ Newest fetched_at │ 2026-06-04T15:00:00+00:00 │
└───────────────────┴───────────────────────────┘
```

It also prints the top five most frequent authors in stored rows.

Author frequency is row frequency, not unique-story frequency.

### export

Export the latest snapshot to stdout.

Supported formats are `json`, `csv`, and `markdown`.

Example:

```bash
uv run hn-tracker export json
```

Example JSON output:

```json
[
  {
    "snapshot_id": 3,
    "rank": 1,
    "id": 12345678,
    "title": "Example item"
  }
]
```

Example CSV command:

```bash
uv run hn-tracker export csv > latest.csv
```

Example Markdown command:

```bash
uv run hn-tracker export markdown
```

Markdown output is suitable for pasting into issues, pull requests, and notes.

### watch

Repeatedly fetch snapshots until Ctrl-C.

Default interval is 60 seconds.

Example:

```bash
uv run hn-tracker watch --interval 120
```

Example output:

```text
snapshot=5 stories=30 entered=6 left=6 rank_changed=18
```

The first iteration prints `initial=true` if no previous snapshot exists.

Later iterations compare the new snapshot with the previous snapshot.

## Architecture

The package lives under `src/hn_tracker`.

`hn_tracker.cli` owns the Typer command definitions.

`hn_tracker.hn` owns Hacker News HTTP access.

`hn_tracker.db` owns SQLite schema, persistence, FTS5 search, exports, stats, and diff logic.

The database has a `snapshots` table.

The database has a `story_snapshots` table.

The database has a `story_fts` virtual table using FTS5.

`story_snapshots` keeps one row per observed story per snapshot.

This preserves rank history without overwriting old observations.

Snapshot ids are monotonically increasing SQLite row ids.

The public HN API endpoint used for top stories is `/v0/topstories.json`.

The item endpoint is `/v0/item/<id>.json`.

The fetch path first retrieves ids, then concurrently retrieves item metadata.

The CLI pretty-prints tables, but export formats are plain stdout.

Structured logs are configured with `structlog`.

Logs go to stderr so exported JSON and CSV remain parseable.

## Development

Create or refresh the environment:

```bash
uv sync
```

Run tests:

```bash
uv run pytest -v
```

Run the CLI:

```bash
uv run hn-tracker --help
```

Run a single test:

```bash
uv run pytest -v tests/test_cli.py::test_fetch_command_stores_snapshot
```

Inspect the database with sqlite-utils:

```bash
uv run sqlite-utils tables hn.db
```

Show rows:

```bash
uv run sqlite-utils rows hn.db story_snapshots --limit 5
```

The test suite uses temporary directories for database isolation.

Network calls are mocked in unit tests.

The final manual verification can run against the live Hacker News API.

## Docker

Build the image:

```bash
docker build -t hn-tracker .
```

Run help:

```bash
docker run --rm hn-tracker --help
```

Persist the database:

```bash
docker run --rm -v "$PWD:/data" -w /data hn-tracker fetch --limit 30
```

The image is based on `python:3.12-slim`.

It installs the project through `uv`.

The entrypoint is `hn-tracker`.

## CI

GitHub Actions lives at `.github/workflows/ci.yml`.

CI installs `uv`.

CI installs Python 3.12.

CI runs `uv sync --frozen`.

CI runs `uv run pytest -v`.

CI runs `uv run hn-tracker --help` as a smoke test.

## Data Notes

Hacker News stories may have no URL.

Discussion posts often have a null URL.

Deleted or dead comments are omitted from `story` output.

Scores and comment counts are point-in-time observations.

The API can change between fetches.

Repeated snapshots are expected to contain duplicate story ids.

FTS search is over saved titles, not live Hacker News.

Exports always use the latest saved snapshot.

## Roadmap

Add configurable database path.

Add Algolia-backed historical search as an optional live mode.

Add comment search for fetched stories.

Add trend charts for score and rank over time.

Add `prune` for old snapshots.

Add `serve` for a local read-only web dashboard.

Add OPML or RSS-style feeds for entered stories.

Add per-author history views.

Add JSON Lines export for streaming analysis.

Add shell completion documentation.

Add packaging publish workflow.
