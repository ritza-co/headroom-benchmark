# Changelog

## 0.1.0 - 2026-06-04

- Added `fetch` to collect Hacker News top stories concurrently from the Firebase API into SQLite.
- Added snapshot storage with story ranks and saved metadata.
- Added `list` with Rich table rendering.
- Added `diff` for entered, left, and rank-changed stories.
- Added `story` for live metadata and first five top-level comments.
- Added SQLite FTS5 title search.
- Added database statistics.
- Added JSON, CSV, and Markdown export.
- Added `watch` mode for recurring fetches and change summaries.
- Added Dockerfile, GitHub Actions CI, and pytest coverage for all subcommands.
