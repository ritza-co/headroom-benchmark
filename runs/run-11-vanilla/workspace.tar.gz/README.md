# hn-tracker

`hn-tracker` is a Python CLI for tracking Hacker News top stories over time.

It fetches story snapshots from the public Hacker News Firebase API, stores them
in a local SQLite database, and gives you commands for listing, diffing,
searching, exporting, and watching story movement.

The default database path is `./hn.db`.

## Install

Install `uv` first if you do not already have it:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Clone or enter the project directory:

```bash
cd hn-tracker
```

Install the project dependencies:

```bash
uv sync
```

Run the CLI:

```bash
uv run hn-tracker --help
```

Install into an isolated tool environment:

```bash
uv tool install .
```

Then run:

```bash
hn-tracker --help
```

## Database

The database file is created on first use.

```bash
uv run hn-tracker fetch
```

The schema contains `snapshots`, `stories`, `snapshot_stories`, and an FTS5
table named `story_titles_fts`.

`snapshots` records when each fetch happened.

`stories` stores the most recent metadata saved for each Hacker News item id.

`snapshot_stories` records rank within each snapshot.

`story_titles_fts` powers title search.

## Command: fetch

Fetch the current top 30 Hacker News stories:

```bash
uv run hn-tracker fetch
```

Example output:

```text
Saved snapshot 1 with 30 stories.
```

Fetch a smaller snapshot:

```bash
uv run hn-tracker fetch --limit 10
```

`fetch` requests the top story ids, then fetches story metadata concurrently with
`httpx.AsyncClient`.

## Command: list

List the latest snapshot:

```bash
uv run hn-tracker list
```

Example output:

```text
                         Snapshot LATEST
┏━━━━━━┳━━━━━━━┳━━━━━━━┳━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━┓
┃ rank ┃ id    ┃ score ┃ by   ┃ descendants ┃ title      ┃ url ┃
┡━━━━━━╇━━━━━━━╇━━━━━━━╇━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━┩
│ 1    │ 12345 │ 420   │ user │ 88          │ Story text │ ... │
└──────┴───────┴───────┴──────┴─────────────┴────────────┴─────┘
```

List a specific snapshot id:

```bash
uv run hn-tracker list --snapshot 2
```

## Command: diff

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```

Example output:

```text
Diff 1 -> 2
        Entered
┏━━━━━━┳━━━━┳━━━━━━━┓
┃ rank ┃ id ┃ title ┃
└──────┴────┴───────┘
```

Compare explicit snapshot ids:

```bash
uv run hn-tracker diff --from 1 --to 3
```

The diff reports stories that entered, stories that left, and stories whose rank
changed.

A positive rank delta means the story moved up toward rank 1.

A negative rank delta means the story moved down.

## Command: story

Fetch one story live from the Hacker News item API:

```bash
uv run hn-tracker story 8863
```

Example output:

```text
        Story 8863
┏━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ field       ┃ value        ┃
┡━━━━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ title       │ My YC app... │
│ score       │ 111          │
└─────────────┴──────────────┘
```

The command also prints the first five top-level comments when available.

Comment HTML entities are decoded before display.

## Command: search

Search saved story titles:

```bash
uv run hn-tracker search rust
```

Example output:

```text
            Search: rust
┏━━━━┳━━━━━━━┳━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ id ┃ score ┃ by   ┃ title              ┃
┡━━━━╇━━━━━━━╇━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ 1  │ 50    │ jane │ Rust in production │
└────┴───────┴──────┴────────────────────┘
```

Search uses SQLite FTS5 over every title saved across all snapshots.

## Command: stats

Print database statistics:

```bash
uv run hn-tracker stats
```

Example output:

```text
          HN Tracker Stats
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ metric            ┃ value        ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ snapshots         │ 3            │
│ unique stories    │ 74           │
│ oldest fetched_at │ 2026-06-04...│
│ newest fetched_at │ 2026-06-04...│
└───────────────────┴──────────────┘
```

The top authors row shows the five authors with the most unique tracked stories.

## Command: export

Export the latest snapshot as JSON:

```bash
uv run hn-tracker export json
```

Export as CSV:

```bash
uv run hn-tracker export csv
```

Export as Markdown:

```bash
uv run hn-tracker export markdown
```

Example JSON output:

```json
[
  {
    "rank": 1,
    "id": 12345,
    "title": "Example story"
  }
]
```

Example CSV output:

```csv
rank,id,title,url,score,by,time,descendants,type,fetched_at
1,12345,Example story,https://example.com,10,user,1700000000,2,story,2026-06-04T12:00:00+00:00
```

Example Markdown output:

```markdown
| rank | id | title | url | score | by | time | descendants | type | fetched_at |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
```

## Command: watch

Fetch repeatedly until interrupted:

```bash
uv run hn-tracker watch
```

Use a custom interval:

```bash
uv run hn-tracker watch --interval 120
```

Example output:

```text
snapshot=4 stories=30 entered=3 left=3 rank_changed=22
```

Stop with `Ctrl-C`.

## Architecture

The package lives under `src/hn_tracker`.

`api.py` contains the async Hacker News API client.

`db.py` contains schema creation, snapshot persistence, diffing, FTS search,
statistics, and export formatting.

`cli.py` contains the Typer command definitions and Rich rendering.

The CLI configures `structlog` for INFO-level JSON logs to stderr.

Command output is written to stdout so it can be piped into tools.

Live API calls are isolated from database code to keep tests deterministic.

The database layer uses `sqlite-utils` while still using direct SQL for joins,
FTS5, and reporting queries.

## Development

Install dependencies:

```bash
uv sync
```

Run tests:

```bash
uv run pytest -v
```

Run a single test:

```bash
uv run pytest -v tests/test_cli.py::test_fetch_command_saves_snapshot
```

Run the CLI from source:

```bash
uv run hn-tracker fetch --limit 5
```

Inspect the SQLite database:

```bash
uv run sqlite-utils tables hn.db
```

Show rows:

```bash
uv run sqlite-utils rows hn.db stories
```

Remove local data:

```bash
rm -f hn.db
```

## Docker

Build the image:

```bash
docker build -t hn-tracker .
```

Run help:

```bash
docker run --rm hn-tracker --help
```

Persist the database in the current directory:

```bash
docker run --rm -v "$PWD:/data" -w /data hn-tracker fetch
```

## Continuous Integration

The GitHub Actions workflow installs uv, installs Python 3.12, syncs
dependencies, runs `pytest -v`, and runs `hn-tracker --help`.

The workflow file is `.github/workflows/ci.yml`.

## Data Notes

Hacker News item fields are not guaranteed to be present.

`url` can be null for text posts.

`descendants` can be absent on some items.

Deleted comments are skipped in the `story` command.

The local database stores snapshot history, but story metadata is upserted by id.

Ranks remain historical because `snapshot_stories` stores rank per snapshot.

## Roadmap

- Add configurable database path.
- Add Algolia-backed historical search as an optional command.
- Add trend charts for score changes.
- Add author detail pages.
- Add comment tree depth controls.
- Add terminal notifications for new high-scoring stories.
- Add a `prune` command for old snapshots.
- Add shell completion documentation.
- Add machine-readable diff output.
- Add configurable logging format.
