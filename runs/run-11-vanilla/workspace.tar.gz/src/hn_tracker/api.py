from __future__ import annotations

from typing import Any

import httpx

BASE_URL = "https://hacker-news.firebaseio.com/v0"


async def fetch_top_stories(limit: int) -> list[dict[str, Any]]:
    async with httpx.AsyncClient(base_url=BASE_URL, timeout=20.0) as client:
        response = await client.get("/topstories.json")
        response.raise_for_status()
        ids = response.json()[:limit]
        responses = await _gather_items(client, ids)
    return [item for item in responses if item and item.get("type") == "story"]


async def fetch_story_with_comments(story_id: int, comment_limit: int = 5) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    async with httpx.AsyncClient(base_url=BASE_URL, timeout=20.0) as client:
        story = await _fetch_item(client, story_id)
        kids = (story or {}).get("kids", [])[:comment_limit]
        comments = await _gather_items(client, kids)
    return story or {}, [comment for comment in comments if comment and not comment.get("deleted")]


async def _gather_items(client: httpx.AsyncClient, ids: list[int]) -> list[dict[str, Any] | None]:
    import asyncio

    return await asyncio.gather(*[_fetch_item(client, item_id) for item_id in ids])


async def _fetch_item(client: httpx.AsyncClient, item_id: int) -> dict[str, Any] | None:
    response = await client.get(f"/item/{item_id}.json")
    response.raise_for_status()
    return response.json()
