from __future__ import annotations

import asyncio
import html
import logging
import sys
import time as time_module
from typing import Literal

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hn_tracker import api
from hn_tracker.db import DB_PATH, HNDatabase

app = typer.Typer(no_args_is_help=True, help="Track Hacker News top stories over time.")
console = Console()
err_console = Console(stderr=True)


def configure_logging() -> None:
    logging.basicConfig(format="%(message)s", stream=sys.stderr, level=logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


log = structlog.get_logger()


@app.callback()
def main() -> None:
    configure_logging()


@app.command()
def fetch(limit: int = typer.Option(30, min=1, max=500, help="Number of current top stories to fetch.")) -> None:
    """Fetch current top stories and save a new snapshot."""
    snapshot_id, count = fetch_once(limit)
    console.print(f"Saved snapshot {snapshot_id} with {count} stories.")


def fetch_once(limit: int = 30, db: HNDatabase | None = None) -> tuple[int, int]:
    database = db or HNDatabase(DB_PATH)
    stories = asyncio.run(api.fetch_top_stories(limit))
    snapshot_id = database.save_snapshot(stories)
    log.info("fetch_complete", snapshot_id=snapshot_id, stories=len(stories), limit=limit)
    return snapshot_id, len(stories)


@app.command("list")
def list_snapshot(snapshot: str = typer.Option("LATEST", help="Snapshot id or LATEST.")) -> None:
    """Print a saved snapshot."""
    rows = HNDatabase(DB_PATH).get_snapshot(snapshot)
    table = Table(title=f"Snapshot {snapshot}")
    for column in ["rank", "id", "score", "by", "descendants", "title", "url"]:
        table.add_column(column)
    for row in rows:
        table.add_row(
            str(row["rank"]),
            str(row["id"]),
            str(row.get("score") or 0),
            str(row.get("by") or ""),
            str(row.get("descendants") or 0),
            row["title"],
            row.get("url") or "",
        )
    console.print(table)


@app.command()
def diff(
    from_snapshot: int | None = typer.Option(None, "--from", help="Older snapshot id."),
    to_snapshot: int | None = typer.Option(None, "--to", help="Newer snapshot id."),
) -> None:
    """Compare two snapshots."""
    result = HNDatabase(DB_PATH).diff(from_snapshot, to_snapshot)
    if result is None:
        console.print("Need at least two snapshots to diff.")
        return
    console.print(f"Diff {result.from_snapshot} -> {result.to_snapshot}")
    _print_story_table("Entered", result.entered, ["rank", "id", "title"])
    _print_story_table("Left", result.left, ["rank", "id", "title"])
    _print_story_table("Rank changed", result.changed, ["old_rank", "new_rank", "delta", "id", "title"])


@app.command()
def story(id: int) -> None:
    """Fetch and show one story plus its first five top-level comments."""
    item, comments = asyncio.run(api.fetch_story_with_comments(id))
    if not item:
        console.print(f"Story {id} was not found.")
        raise typer.Exit(1)
    meta = Table(title=f"Story {id}")
    meta.add_column("field")
    meta.add_column("value")
    for key in ["title", "url", "score", "by", "time", "descendants", "type"]:
        meta.add_row(key, str(item.get(key, "")))
    console.print(meta)
    for comment in comments:
        text = html.unescape(comment.get("text", ""))
        console.print(Panel(text, title=f"comment {comment.get('id')} by {comment.get('by', '')}"))


@app.command()
def search(query: str) -> None:
    """Search saved story titles."""
    rows = HNDatabase(DB_PATH).search(query)
    _print_story_table(f"Search: {query}", rows, ["id", "score", "by", "title"])


@app.command()
def stats() -> None:
    """Print database statistics."""
    data = HNDatabase(DB_PATH).stats()
    table = Table(title="HN Tracker Stats")
    table.add_column("metric")
    table.add_column("value")
    table.add_row("snapshots", str(data["snapshots"]))
    table.add_row("unique stories", str(data["unique_stories"]))
    table.add_row("oldest fetched_at", str(data["oldest_fetched_at"] or ""))
    table.add_row("newest fetched_at", str(data["newest_fetched_at"] or ""))
    authors = ", ".join(f"{row['author']} ({row['appearances']})" for row in data["top_authors"])
    table.add_row("top authors", authors)
    console.print(table)


@app.command()
def export(format: Literal["json", "csv", "markdown"]) -> None:
    """Export the latest snapshot."""
    sys.stdout.write(HNDatabase(DB_PATH).export_latest(format))


@app.command()
def watch(interval: int = typer.Option(60, min=1, help="Seconds between fetches.")) -> None:
    """Fetch repeatedly until Ctrl-C."""
    database = HNDatabase(DB_PATH)
    previous: int | None = database.resolve_snapshot("LATEST")
    try:
        while True:
            snapshot_id, count = fetch_once(30, database)
            summary = f"snapshot={snapshot_id} stories={count}"
            if previous is not None:
                result = database.diff(previous, snapshot_id)
                if result is not None:
                    summary += (
                        f" entered={len(result.entered)} left={len(result.left)} "
                        f"rank_changed={len(result.changed)}"
                    )
            console.print(summary)
            previous = snapshot_id
            time_module.sleep(interval)
    except KeyboardInterrupt:
        console.print("Stopped.")


def _print_story_table(title: str, rows: list[dict], columns: list[str]) -> None:
    table = Table(title=title)
    for column in columns:
        table.add_column(column)
    for row in rows:
        table.add_row(*[str(row.get(column, "")) for column in columns])
    console.print(table)
