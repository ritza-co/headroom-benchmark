from __future__ import annotations

import csv
import io
import json
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import sqlite_utils

DB_PATH = Path("hn.db")


@dataclass(frozen=True)
class SnapshotDiff:
    from_snapshot: int
    to_snapshot: int
    entered: list[dict[str, Any]]
    left: list[dict[str, Any]]
    changed: list[dict[str, Any]]


def now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class HNDatabase:
    def __init__(self, path: Path | str = DB_PATH):
        self.path = Path(path)
        self.db = sqlite_utils.Database(self.path)
        self.conn: sqlite3.Connection = self.db.conn
        self.conn.row_factory = sqlite3.Row
        self.ensure_schema()

    def ensure_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fetched_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS stories (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                url TEXT,
                score INTEGER,
                by TEXT,
                time INTEGER,
                descendants INTEGER,
                type TEXT,
                fetched_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS snapshot_stories (
                snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
                story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
                rank INTEGER NOT NULL,
                PRIMARY KEY (snapshot_id, story_id)
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS story_titles_fts
            USING fts5(story_id UNINDEXED, title);
            """
        )
        self.conn.commit()

    def save_snapshot(self, stories: list[dict[str, Any]], fetched_at: str | None = None) -> int:
        fetched_at = fetched_at or now_iso()
        cur = self.conn.execute("INSERT INTO snapshots (fetched_at) VALUES (?)", (fetched_at,))
        snapshot_id = int(cur.lastrowid)
        rows = []
        ranks = []
        for rank, story in enumerate(stories, start=1):
            row = {
                "id": story["id"],
                "title": story.get("title") or "",
                "url": story.get("url"),
                "score": story.get("score", 0),
                "by": story.get("by"),
                "time": story.get("time"),
                "descendants": story.get("descendants", 0),
                "type": story.get("type", "story"),
                "fetched_at": fetched_at,
            }
            rows.append(row)
            ranks.append((snapshot_id, story["id"], rank))
        if rows:
            self.conn.executemany(
                """
                INSERT INTO stories (
                    id, title, url, score, by, time, descendants, type, fetched_at
                )
                VALUES (
                    :id, :title, :url, :score, :by, :time, :descendants, :type, :fetched_at
                )
                ON CONFLICT(id) DO UPDATE SET
                    title = excluded.title,
                    url = excluded.url,
                    score = excluded.score,
                    by = excluded.by,
                    time = excluded.time,
                    descendants = excluded.descendants,
                    type = excluded.type,
                    fetched_at = excluded.fetched_at
                """,
                rows,
            )
            self.conn.executemany(
                "INSERT OR REPLACE INTO snapshot_stories (snapshot_id, story_id, rank) VALUES (?, ?, ?)",
                ranks,
            )
            self.conn.executemany("DELETE FROM story_titles_fts WHERE story_id = ?", [(row["id"],) for row in rows])
            self.conn.executemany(
                "INSERT INTO story_titles_fts (story_id, title) VALUES (?, ?)",
                [(row["id"], row["title"]) for row in rows],
            )
        self.conn.commit()
        return snapshot_id

    def snapshot_ids(self) -> list[int]:
        return [row["id"] for row in self.conn.execute("SELECT id FROM snapshots ORDER BY id")]

    def resolve_snapshot(self, value: str | int | None = "LATEST") -> int | None:
        ids = self.snapshot_ids()
        if not ids:
            return None
        if value is None or str(value).upper() == "LATEST":
            return ids[-1]
        return int(value)

    def latest_two_snapshot_ids(self) -> tuple[int, int] | None:
        ids = self.snapshot_ids()
        if len(ids) < 2:
            return None
        return ids[-2], ids[-1]

    def get_snapshot(self, snapshot: str | int | None = "LATEST") -> list[dict[str, Any]]:
        snapshot_id = self.resolve_snapshot(snapshot)
        if snapshot_id is None:
            return []
        rows = self.conn.execute(
            """
            SELECT ss.rank, s.*
            FROM snapshot_stories ss
            JOIN stories s ON s.id = ss.story_id
            WHERE ss.snapshot_id = ?
            ORDER BY ss.rank
            """,
            (snapshot_id,),
        )
        return [dict(row) for row in rows]

    def diff(self, from_snapshot: int | None = None, to_snapshot: int | None = None) -> SnapshotDiff | None:
        if from_snapshot is None or to_snapshot is None:
            latest = self.latest_two_snapshot_ids()
            if latest is None:
                return None
            from_snapshot, to_snapshot = latest
        old = {row["id"]: row for row in self.get_snapshot(from_snapshot)}
        new = {row["id"]: row for row in self.get_snapshot(to_snapshot)}
        entered = [new[item_id] for item_id in new.keys() - old.keys()]
        left = [old[item_id] for item_id in old.keys() - new.keys()]
        changed = []
        for item_id in old.keys() & new.keys():
            old_rank = old[item_id]["rank"]
            new_rank = new[item_id]["rank"]
            if old_rank != new_rank:
                row = dict(new[item_id])
                row["old_rank"] = old_rank
                row["new_rank"] = new_rank
                row["delta"] = old_rank - new_rank
                changed.append(row)
        return SnapshotDiff(
            from_snapshot=from_snapshot,
            to_snapshot=to_snapshot,
            entered=sorted(entered, key=lambda row: row["rank"]),
            left=sorted(left, key=lambda row: row["rank"]),
            changed=sorted(changed, key=lambda row: row["new_rank"]),
        )

    def search(self, query: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT s.*
            FROM story_titles_fts f
            JOIN stories s ON s.id = f.story_id
            WHERE story_titles_fts MATCH ?
            ORDER BY bm25(story_titles_fts)
            """,
            (query,),
        )
        return [dict(row) for row in rows]

    def stats(self) -> dict[str, Any]:
        one = self.conn.execute(
            """
            SELECT
                (SELECT COUNT(*) FROM snapshots) AS snapshots,
                (SELECT COUNT(*) FROM stories) AS unique_stories,
                (SELECT MIN(fetched_at) FROM snapshots) AS oldest_fetched_at,
                (SELECT MAX(fetched_at) FROM snapshots) AS newest_fetched_at
            """
        ).fetchone()
        authors = self.conn.execute(
            """
            SELECT by AS author, COUNT(*) AS appearances
            FROM stories
            WHERE by IS NOT NULL
            GROUP BY by
            ORDER BY appearances DESC, by
            LIMIT 5
            """
        )
        data = dict(one)
        data["top_authors"] = [dict(row) for row in authors]
        return data

    def export_latest(self, fmt: Literal["json", "csv", "markdown"]) -> str:
        rows = self.get_snapshot("LATEST")
        columns = ["rank", "id", "title", "url", "score", "by", "time", "descendants", "type", "fetched_at"]
        if fmt == "json":
            return json.dumps(rows, indent=2)
        if fmt == "csv":
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=columns, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
            return output.getvalue()
        header = "| " + " | ".join(columns) + " |"
        separator = "| " + " | ".join(["---"] * len(columns)) + " |"
        lines = [header, separator]
        for row in rows:
            lines.append("| " + " | ".join(_markdown_cell(row.get(column)) for column in columns) + " |")
        return "\n".join(lines)


def _markdown_cell(value: Any) -> str:
    return str(value if value is not None else "").replace("|", "\\|").replace("\n", " ")
