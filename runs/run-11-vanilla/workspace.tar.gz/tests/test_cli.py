from __future__ import annotations

import asyncio
import csv
import io
import json

from hn_tracker.cli import app
from hn_tracker.db import HNDatabase


def story_item(item_id: int, title: str, by: str = "alice", score: int = 10) -> dict:
    return {
        "id": item_id,
        "title": title,
        "url": f"https://example.com/{item_id}",
        "score": score,
        "by": by,
        "time": 1_700_000_000 + item_id,
        "descendants": item_id % 7,
        "type": "story",
    }


def test_fetch_command_saves_snapshot(runner, isolated, mocker):
    mocker.patch("hn_tracker.api.fetch_top_stories", return_value=[story_item(1, "First"), story_item(2, "Second")])
    result = runner.invoke(app, ["fetch", "--limit", "2"])
    assert result.exit_code == 0
    assert "Saved snapshot 1 with 2 stories" in result.stdout
    assert len(HNDatabase().get_snapshot("LATEST")) == 2


def test_list_command_prints_rich_table(runner, isolated):
    HNDatabase().save_snapshot([story_item(1, "A visible title")])
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "A visible title" in result.stdout
    assert "Snapshot" in result.stdout


def test_diff_command_prints_entered_left_and_rank_changes(runner, isolated):
    db = HNDatabase()
    db.save_snapshot([story_item(1, "One"), story_item(2, "Two"), story_item(3, "Three")])
    db.save_snapshot([story_item(2, "Two"), story_item(4, "Four"), story_item(1, "One")])
    result = runner.invoke(app, ["diff"])
    assert result.exit_code == 0
    assert "Entered" in result.stdout
    assert "Four" in result.stdout
    assert "Left" in result.stdout
    assert "Three" in result.stdout
    assert "Rank changed" in result.stdout


def test_diff_model_identifies_entered_left_rank_changed(isolated):
    db = HNDatabase()
    db.save_snapshot([story_item(1, "One"), story_item(2, "Two"), story_item(3, "Three")])
    db.save_snapshot([story_item(2, "Two"), story_item(4, "Four"), story_item(1, "One")])
    result = db.diff()
    assert [row["id"] for row in result.entered] == [4]
    assert [row["id"] for row in result.left] == [3]
    assert {row["id"]: row["delta"] for row in result.changed} == {2: 1, 1: -2}


def test_story_command_fetches_story_and_comments(runner, isolated, mocker):
    mocker.patch(
        "hn_tracker.api.fetch_story_with_comments",
        return_value=(
            {**story_item(9, "Story details"), "kids": [101]},
            [{"id": 101, "by": "bob", "text": "Useful comment"}],
        ),
    )
    result = runner.invoke(app, ["story", "9"])
    assert result.exit_code == 0
    assert "Story details" in result.stdout
    assert "Useful comment" in result.stdout


def test_search_command_uses_fts(runner, isolated):
    db = HNDatabase()
    db.save_snapshot([story_item(1, "Python type systems"), story_item(2, "Rust memory safety")])
    result = runner.invoke(app, ["search", "rust"])
    assert result.exit_code == 0
    assert "Rust memory safety" in result.stdout
    assert "Python type systems" not in result.stdout


def test_fts_search_across_multiple_snapshots(isolated):
    db = HNDatabase()
    db.save_snapshot([story_item(1, "Python packaging"), story_item(2, "SQLite tricks")])
    db.save_snapshot([story_item(3, "Modern Python CLI"), story_item(4, "Rust services")])
    assert {row["id"] for row in db.search("python")} == {1, 3}


def test_stats_command_prints_database_stats(runner, isolated):
    db = HNDatabase()
    db.save_snapshot([story_item(1, "One", by="alice"), story_item(2, "Two", by="bob")])
    db.save_snapshot([story_item(2, "Two", by="bob"), story_item(3, "Three", by="bob")])
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "snapshots" in result.stdout
    assert "bob" in result.stdout


def test_export_json_and_csv_are_valid(runner, isolated):
    HNDatabase().save_snapshot([story_item(1, "One"), story_item(2, "Two")])
    json_result = runner.invoke(app, ["export", "json"])
    assert json_result.exit_code == 0
    assert [row["title"] for row in json.loads(json_result.stdout)] == ["One", "Two"]
    csv_result = runner.invoke(app, ["export", "csv"])
    assert csv_result.exit_code == 0
    rows = list(csv.DictReader(io.StringIO(csv_result.stdout)))
    assert rows[0]["title"] == "One"


def test_export_markdown_command(runner, isolated):
    HNDatabase().save_snapshot([story_item(1, "One")])
    result = runner.invoke(app, ["export", "markdown"])
    assert result.exit_code == 0
    assert "| rank | id | title |" in result.stdout


def test_watch_command_runs_until_keyboard_interrupt(runner, isolated, mocker):
    calls = [{"id": 1, "title": "One"}, {"id": 2, "title": "Two"}]

    def fake_fetch(limit):
        item = calls.pop(0)
        return [story_item(item["id"], item["title"])]

    def stop(_interval):
        raise KeyboardInterrupt

    mocker.patch("hn_tracker.api.fetch_top_stories", side_effect=fake_fetch)
    mocker.patch("hn_tracker.cli.time_module.sleep", side_effect=stop)
    result = runner.invoke(app, ["watch", "--interval", "1"])
    assert result.exit_code == 0
    assert "snapshot=1 stories=1" in result.stdout
    assert "Stopped." in result.stdout


def test_fetch_uses_concurrent_httpx_requests(mocker):
    import hn_tracker.api as api_module

    state = {"in_flight": 0, "max_in_flight": 0}

    class FakeResponse:
        def __init__(self, payload):
            self.payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self.payload

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def get(self, path):
            if path == "/topstories.json":
                return FakeResponse([1, 2, 3, 4])
            state["in_flight"] += 1
            state["max_in_flight"] = max(state["max_in_flight"], state["in_flight"])
            await asyncio.sleep(0.01)
            item_id = int(path.split("/")[-1].split(".")[0])
            state["in_flight"] -= 1
            return FakeResponse(story_item(item_id, f"Story {item_id}"))

    mocker.patch.object(api_module.httpx, "AsyncClient", FakeAsyncClient)
    stories = asyncio.run(api_module.fetch_top_stories(4))
    assert len(stories) == 4
    assert state["max_in_flight"] > 1
