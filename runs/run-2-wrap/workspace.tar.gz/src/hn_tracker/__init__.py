from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import typer
from sqlite_utils import Database


HN_API = "https://hacker-news.firebaseio.com/v0"
app = typer.Typer(no_args_is_help=True)


def db_path() -> Path:
    return Path(os.environ.get("HN_TRACKER_DB", "hn.db"))


def now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def get_db(path: Path | None = None) -> Database:
    return Database(path or db_path())


def ensure_schema(db: Database) -> None:
    db.conn.execute(
        """
        create table if not exists snapshots (
            fetched_at text primary key
        )
        """
    )
    db.conn.execute(
        """
        create table if not exists stories (
            rowid integer primary key,
            fetched_at text not null,
            rank integer not null,
            id integer not null,
            title text not null,
            url text,
            score integer not null,
            by text not null,
            time integer not null,
            foreign key (fetched_at) references snapshots(fetched_at)
        )
        """
    )
    db.conn.execute(
        "create index if not exists idx_stories_snapshot_rank on stories(fetched_at, rank)"
    )


def fetch_top_stories(client: httpx.Client, fetched_at: str) -> list[dict[str, Any]]:
    top_ids = client.get(f"{HN_API}/topstories.json").raise_for_status().json()[:10]
    stories = []
    for rank, story_id in enumerate(top_ids, start=1):
        item = client.get(f"{HN_API}/item/{story_id}.json").raise_for_status().json()
        stories.append(
            {
                "fetched_at": fetched_at,
                "rank": rank,
                "id": item["id"],
                "title": item.get("title") or "(untitled)",
                "url": item.get("url"),
                "score": item.get("score") or 0,
                "by": item.get("by") or "",
                "time": item.get("time") or 0,
            }
        )
    return stories


def save_snapshot(db: Database, stories: list[dict[str, Any]], fetched_at: str) -> None:
    ensure_schema(db)
    with db.conn:
        db["snapshots"].insert({"fetched_at": fetched_at}, pk="fetched_at", replace=True)
        db["stories"].delete_where("fetched_at = ?", [fetched_at])
        db["stories"].insert_all(stories)


def latest_snapshots(db: Database, limit: int = 1) -> list[str]:
    ensure_schema(db)
    rows = db.query(
        "select fetched_at from snapshots order by fetched_at desc limit ?", [limit]
    )
    return [row["fetched_at"] for row in rows]


def stories_for_snapshot(db: Database, fetched_at: str) -> list[dict[str, Any]]:
    return list(
        db.query(
            """
            select rank, id, title, url, score, by, time, fetched_at
            from stories
            where fetched_at = ?
            order by rank
            """,
            [fetched_at],
        )
    )


def table(headers: list[str], rows: list[list[Any]]) -> str:
    widths = [
        max(len(str(value)) for value in [header, *(row[index] for row in rows)])
        for index, header in enumerate(headers)
    ]
    header_line = "  ".join(
        str(header).ljust(widths[index]) for index, header in enumerate(headers)
    )
    separator = "  ".join("-" * width for width in widths)
    body = [
        "  ".join(str(value).ljust(widths[index]) for index, value in enumerate(row))
        for row in rows
    ]
    return "\n".join([header_line, separator, *body])


def print_snapshot(db: Database) -> None:
    snapshots = latest_snapshots(db)
    if not snapshots:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        raise typer.Exit(1)

    fetched_at = snapshots[0]
    stories = stories_for_snapshot(db, fetched_at)
    typer.echo(f"Snapshot: {fetched_at}")
    typer.echo(
        table(
            ["Rank", "ID", "Score", "By", "Title", "URL"],
            [
                [
                    story["rank"],
                    story["id"],
                    story["score"],
                    story["by"],
                    story["title"],
                    story["url"] or "",
                ]
                for story in stories
            ],
        )
    )


@app.command()
def fetch() -> None:
    """Fetch and store the current Hacker News top 10."""
    fetched_at = now_iso()
    with httpx.Client(timeout=10.0) as client:
        stories = fetch_top_stories(client, fetched_at)
    save_snapshot(get_db(), stories, fetched_at)
    typer.echo(f"Saved {len(stories)} stories at {fetched_at}")


@app.command(name="list")
def list_command() -> None:
    """Print the most recent snapshot."""
    print_snapshot(get_db())


@app.command()
def diff() -> None:
    """Compare the two most recent snapshots."""
    db = get_db()
    snapshots = latest_snapshots(db, limit=2)
    if len(snapshots) < 2:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(1)

    new_at, old_at = snapshots
    new = {story["id"]: story for story in stories_for_snapshot(db, new_at)}
    old = {story["id"]: story for story in stories_for_snapshot(db, old_at)}

    entered = [story for story_id, story in new.items() if story_id not in old]
    left = [story for story_id, story in old.items() if story_id not in new]
    changed = [
        (new[story_id], old[story_id]["rank"] - new[story_id]["rank"])
        for story_id in new.keys() & old.keys()
        if old[story_id]["rank"] != new[story_id]["rank"]
    ]
    changed.sort(key=lambda item: item[0]["rank"])

    typer.echo(f"Comparing {old_at} -> {new_at}")
    typer.echo("\nEntered top 10")
    typer.echo(
        table(
            ["Rank", "ID", "Title"],
            [[story["rank"], story["id"], story["title"]] for story in entered],
        )
        if entered
        else "None"
    )
    typer.echo("\nLeft top 10")
    typer.echo(
        table(
            ["Old Rank", "ID", "Title"],
            [[story["rank"], story["id"], story["title"]] for story in left],
        )
        if left
        else "None"
    )
    typer.echo("\nRank changed")
    typer.echo(
        table(
            ["Rank", "Delta", "ID", "Title"],
            [
                [story["rank"], f"{delta:+d}", story["id"], story["title"]]
                for story, delta in changed
            ],
        )
        if changed
        else "None"
    )


def main() -> None:
    app()
