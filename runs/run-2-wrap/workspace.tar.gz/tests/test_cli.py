from __future__ import annotations

from pathlib import Path

from sqlite_utils import Database
from typer.testing import CliRunner

import hn_tracker


runner = CliRunner()


class FakeResponse:
    def __init__(self, data):
        self.data = data

    def raise_for_status(self):
        return self

    def json(self):
        return self.data


class FakeClient:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return None

    def get(self, url):
        if url.endswith("/topstories.json"):
            return FakeResponse(list(range(100, 110)))

        story_id = int(url.rsplit("/", 1)[1].removesuffix(".json"))
        return FakeResponse(
            {
                "id": story_id,
                "title": f"Story {story_id}",
                "url": None if story_id == 100 else f"https://example.com/{story_id}",
                "score": story_id,
                "by": "alice",
                "time": 1_700_000_000 + story_id,
            }
        )


def seed(db_file: Path, fetched_at: str, ids: list[int]) -> None:
    stories = [
        {
            "fetched_at": fetched_at,
            "rank": rank,
            "id": story_id,
            "title": f"Story {story_id}",
            "url": f"https://example.com/{story_id}",
            "score": 100 - rank,
            "by": "tester",
            "time": 1_700_000_000 + story_id,
        }
        for rank, story_id in enumerate(ids, start=1)
    ]
    hn_tracker.save_snapshot(Database(db_file), stories, fetched_at)


def test_fetch_uses_mocked_hn_api(tmp_path, mocker):
    db_file = tmp_path / "hn.db"
    mocker.patch.object(hn_tracker.httpx, "Client", return_value=FakeClient())
    mocker.patch.object(hn_tracker, "now_iso", return_value="2026-06-04T12:00:00+00:00")

    result = runner.invoke(hn_tracker.app, ["fetch"], env={"HN_TRACKER_DB": str(db_file)})

    assert result.exit_code == 0
    assert "Saved 10 stories" in result.output
    rows = list(Database(db_file).query("select * from stories order by rank"))
    assert len(rows) == 10
    assert rows[0]["id"] == 100
    assert rows[0]["rank"] == 1
    assert rows[0]["url"] is None


def test_list_prints_latest_snapshot(tmp_path):
    db_file = tmp_path / "hn.db"
    seed(db_file, "2026-06-04T10:00:00+00:00", [1, 2, 3])
    seed(db_file, "2026-06-04T11:00:00+00:00", [9, 8, 7])

    result = runner.invoke(hn_tracker.app, ["list"], env={"HN_TRACKER_DB": str(db_file)})

    assert result.exit_code == 0
    assert "Snapshot: 2026-06-04T11:00:00+00:00" in result.output
    assert "Story 9" in result.output
    assert "Story 1" not in result.output


def test_diff_prints_entered_left_and_rank_changed(tmp_path):
    db_file = tmp_path / "hn.db"
    seed(db_file, "2026-06-04T10:00:00+00:00", [1, 2, 3, 4])
    seed(db_file, "2026-06-04T11:00:00+00:00", [2, 5, 1, 4])

    result = runner.invoke(hn_tracker.app, ["diff"], env={"HN_TRACKER_DB": str(db_file)})

    assert result.exit_code == 0
    assert "Entered top 10" in result.output
    assert "Story 5" in result.output
    assert "Left top 10" in result.output
    assert "Story 3" in result.output
    assert "Rank changed" in result.output
    assert "Story 2" in result.output
    assert "+1" in result.output
    assert "Story 1" in result.output
    assert "-2" in result.output
