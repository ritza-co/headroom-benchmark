# hn-tracker

Small CLI for snapshotting the current Hacker News top 10 into local SQLite.

## Install

```bash
uv sync
```

The database is stored at `./hn.db` by default. Set `HN_TRACKER_DB` to use a
different path.

## Commands

Fetch the current top 10 from the Hacker News Firebase API:

```bash
uv run hn-tracker fetch
```

Print the most recent stored snapshot:

```bash
uv run hn-tracker list
```

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```

Run tests:

```bash
uv run pytest -q
```
