# Changelog

## 0.1.0 - 2026-06-04

- Added `fetch` to store concurrent Hacker News top-story snapshots in SQLite.
- Added `list` with Rich table rendering.
- Added `diff` for entered, left, and rank-changed stories.
- Added `story` for live story metadata and first five top-level comments.
- Added SQLite FTS5 title search.
- Added database statistics reporting.
- Added JSON, CSV, and Markdown export for the latest snapshot.
- Added `watch` mode for repeated polling with change summaries.
- Added pytest coverage for each subcommand, FTS, exports, diff behavior, and concurrent HTTP fetching.
- Added Docker and GitHub Actions CI support.
