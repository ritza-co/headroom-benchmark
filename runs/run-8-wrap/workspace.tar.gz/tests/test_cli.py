from __future__ import annotations

import asyncio
import csv
import io
import json

import pytest
from typer.testing import CliRunner

from hn_tracker import db as storage
from hn_tracker.cli import app
from hn_tracker.models import Story


runner = CliRunner()


def make_story(story_id: int, title: str, rank_time: str = "2026-06-04T10:00:00+00:00", by: str = "alice") -> Story:
    return Story(
        id=story_id,
        title=title,
        url=f"https://example.com/{story_id}",
        score=100 - story_id,
        by=by,
        time=1_700_000_000 + story_id,
        descendants=story_id % 10,
        type="story",
        fetched_at=rank_time,
        kids=[],
    )


def seed(db_path, snapshots: list[list[Story]]) -> None:
    database = storage.connect(db_path)
    for stories in snapshots:
        storage.save_snapshot(database, stories)


@pytest.fixture
def isolated_cli(monkeypatch, tmp_path):
    db_path = tmp_path / "hn.db"
    monkeypatch.setattr("hn_tracker.cli.DB_PATH", str(db_path))
    return db_path


def test_fetch_command_saves_snapshot(isolated_cli, monkeypatch):
    async def fake_fetch_top_stories(limit):
        assert limit == 2
        return [make_story(1, "Python wins"), make_story(2, "Rust rises")]

    monkeypatch.setattr("hn_tracker.cli.fetch_top_stories", fake_fetch_top_stories)
    result = runner.invoke(app, ["fetch", "--limit", "2"])
    assert result.exit_code == 0
    assert "Saved snapshot 1 with 2 stories" in result.stdout
    assert len(storage.get_snapshot(storage.connect(isolated_cli), "LATEST")) == 2


def test_list_command_prints_snapshot(isolated_cli):
    seed(isolated_cli, [[make_story(1, "Python wins")]])
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "Python wins" in result.stdout
    assert "alice" in result.stdout


def test_diff_command_prints_entered_left_and_rank_change(isolated_cli):
    seed(
        isolated_cli,
        [
            [make_story(1, "First"), make_story(2, "Second"), make_story(3, "Third")],
            [make_story(2, "Second"), make_story(4, "Fourth"), make_story(1, "First")],
        ],
    )
    result = runner.invoke(app, ["diff"])
    assert result.exit_code == 0
    assert "entered" in result.stdout
    assert "left" in result.stdout
    assert "rank changed" in result.stdout
    assert "Fourth" in result.stdout
    assert "Third" in result.stdout
    assert "1->3" in result.stdout


def test_story_command_fetches_metadata_and_comments(monkeypatch):
    async def fake_story_with_comments(story_id, limit=5):
        assert story_id == 42
        assert limit == 5
        return (
            {"id": 42, "title": "Ask HN", "score": 8, "by": "sally", "type": "story"},
            [{"id": 99, "by": "bob", "text": "Good question"}],
        )

    monkeypatch.setattr("hn_tracker.cli.fetch_story_with_comments", fake_story_with_comments)
    result = runner.invoke(app, ["story", "42"])
    assert result.exit_code == 0
    assert "Ask HN" in result.stdout
    assert "Good question" in result.stdout


def test_search_command_uses_fts(isolated_cli):
    seed(
        isolated_cli,
        [
            [make_story(1, "Python packaging guide")],
            [make_story(2, "SQLite full text search")],
        ],
    )
    result = runner.invoke(app, ["search", "SQLite"])
    assert result.exit_code == 0
    assert "SQLite full text search" in result.stdout
    assert "Python packaging guide" not in result.stdout


def test_fts_search_returns_results_across_multiple_snapshots(isolated_cli):
    seed(
        isolated_cli,
        [
            [make_story(1, "Rust async patterns")],
            [make_story(2, "Rust meets SQLite")],
        ],
    )
    rows = storage.search_titles(storage.connect(isolated_cli), "Rust")
    assert {row["title"] for row in rows} == {"Rust async patterns", "Rust meets SQLite"}


def test_stats_command_prints_database_stats(isolated_cli):
    seed(
        isolated_cli,
        [
            [make_story(1, "One", by="alice"), make_story(2, "Two", by="bob")],
            [make_story(1, "One", by="alice"), make_story(3, "Three", by="alice")],
        ],
    )
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "Snapshots" in result.stdout
    assert "Unique stories" in result.stdout
    assert "alice" in result.stdout


def test_export_json_and_csv_are_valid(isolated_cli):
    seed(isolated_cli, [[make_story(1, "One"), make_story(2, "Two")]])
    json_result = runner.invoke(app, ["export", "json"])
    assert json_result.exit_code == 0
    parsed = json.loads(json_result.stdout)
    assert parsed[0]["title"] == "One"

    csv_result = runner.invoke(app, ["export", "csv"])
    assert csv_result.exit_code == 0
    parsed_csv = list(csv.DictReader(io.StringIO(csv_result.stdout)))
    assert parsed_csv[1]["title"] == "Two"


def test_export_markdown_command(isolated_cli):
    seed(isolated_cli, [[make_story(1, "One")]])
    result = runner.invoke(app, ["export", "markdown"])
    assert result.exit_code == 0
    assert "One" in result.stdout


def test_watch_fetches_until_keyboard_interrupt(isolated_cli, monkeypatch):
    async def fake_fetch_top_stories(limit):
        return [make_story(1, "One")]

    def stop(_interval):
        raise KeyboardInterrupt

    monkeypatch.setattr("hn_tracker.cli.fetch_top_stories", fake_fetch_top_stories)
    monkeypatch.setattr("hn_tracker.cli.time.sleep", stop)
    result = runner.invoke(app, ["watch", "--interval", "1"])
    assert result.exit_code == 0
    assert "snapshot 1: 1 stories" in result.stdout
    assert "Stopped" in result.stdout


def test_help_lists_all_subcommands():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for command in ["fetch", "list", "diff", "story", "search", "stats", "export", "watch"]:
        assert command in result.stdout


def test_storage_diff_identifies_entered_left_and_rank_changed(isolated_cli):
    seed(
        isolated_cli,
        [
            [make_story(1, "One"), make_story(2, "Two"), make_story(3, "Three")],
            [make_story(2, "Two"), make_story(1, "One"), make_story(4, "Four")],
        ],
    )
    diff = storage.diff_snapshots(storage.connect(isolated_cli), 1, 2)
    assert [row["id"] for row in diff.entered] == [4]
    assert [row["id"] for row in diff.left] == [3]
    assert {row["id"]: row["delta"] for row in diff.changed} == {1: -1, 2: 1}


@pytest.mark.asyncio
async def test_fetch_uses_concurrent_httpx_requests(monkeypatch):
    from hn_tracker import hn

    state = {"in_flight": 0, "max_in_flight": 0}

    class FakeResponse:
        def __init__(self, payload):
            self.payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self.payload

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def get(self, url):
            if url.endswith("/topstories.json"):
                return FakeResponse([1, 2, 3])
            state["in_flight"] += 1
            state["max_in_flight"] = max(state["max_in_flight"], state["in_flight"])
            await asyncio.sleep(0.01)
            item_id = int(url.rsplit("/", 1)[1].removesuffix(".json"))
            state["in_flight"] -= 1
            return FakeResponse(
                {
                    "id": item_id,
                    "title": f"Story {item_id}",
                    "score": item_id,
                    "by": "user",
                    "time": item_id,
                    "descendants": 0,
                    "type": "story",
                }
            )

    monkeypatch.setattr(hn.httpx, "AsyncClient", FakeAsyncClient)
    stories = await hn.fetch_top_stories(3)
    assert len(stories) == 3
    assert state["max_in_flight"] > 1
