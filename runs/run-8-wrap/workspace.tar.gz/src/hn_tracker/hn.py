from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

import httpx

from hn_tracker.models import HN_BASE_URL, Story


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


async def fetch_json(client: httpx.AsyncClient, path: str) -> Any:
    response = await client.get(f"{HN_BASE_URL}/{path}.json")
    response.raise_for_status()
    return response.json()


async def fetch_top_stories(limit: int) -> list[Story]:
    fetched_at = utc_now()
    async with httpx.AsyncClient(timeout=15.0) as client:
        ids = await fetch_json(client, "topstories")
        selected = [int(story_id) for story_id in ids[:limit]]
        items = await asyncio.gather(
            *(fetch_json(client, f"item/{story_id}") for story_id in selected)
        )
    return [Story.from_item(item, fetched_at) for item in items if item]


async def fetch_item(item_id: int) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=15.0) as client:
        item = await fetch_json(client, f"item/{item_id}")
    return item or {}


async def fetch_story_with_comments(story_id: int, limit: int = 5) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    async with httpx.AsyncClient(timeout=15.0) as client:
        story = await fetch_json(client, f"item/{story_id}")
        kids = [int(kid) for kid in (story or {}).get("kids", [])[:limit]]
        comments = await asyncio.gather(
            *(fetch_json(client, f"item/{kid}") for kid in kids),
            return_exceptions=False,
        )
    return story or {}, [comment for comment in comments if comment]
