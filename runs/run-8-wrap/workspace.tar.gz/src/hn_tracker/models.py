from __future__ import annotations

from dataclasses import dataclass
from typing import Any


HN_BASE_URL = "https://hacker-news.firebaseio.com/v0"
DB_PATH = "hn.db"


@dataclass(frozen=True)
class Story:
    id: int
    title: str
    url: str | None
    score: int
    by: str
    time: int
    descendants: int
    type: str
    fetched_at: str
    kids: list[int]

    @classmethod
    def from_item(cls, item: dict[str, Any], fetched_at: str) -> "Story":
        return cls(
            id=int(item["id"]),
            title=str(item.get("title") or "(untitled)"),
            url=item.get("url"),
            score=int(item.get("score") or 0),
            by=str(item.get("by") or ""),
            time=int(item.get("time") or 0),
            descendants=int(item.get("descendants") or 0),
            type=str(item.get("type") or ""),
            fetched_at=fetched_at,
            kids=[int(kid) for kid in item.get("kids", [])],
        )


@dataclass(frozen=True)
class SnapshotDiff:
    entered: list[dict[str, Any]]
    left: list[dict[str, Any]]
    changed: list[dict[str, Any]]
