from __future__ import annotations

import asyncio
import csv
import io
import json
import sys
import time
from typing import Annotated

import structlog
import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from hn_tracker import db as storage
from hn_tracker.hn import fetch_story_with_comments, fetch_top_stories
from hn_tracker.logging import configure_logging
from hn_tracker.models import DB_PATH


app = typer.Typer(help="Track Hacker News top stories over time.")
console = Console()
log = structlog.get_logger(__name__)


def main() -> None:
    app()


@app.callback()
def callback() -> None:
    configure_logging()


def _db():
    return storage.connect(DB_PATH)


@app.command()
def fetch(limit: Annotated[int, typer.Option("--limit", min=1, max=500)] = 30) -> None:
    """Fetch the current top Hacker News stories into ./hn.db."""
    stories = asyncio.run(fetch_top_stories(limit))
    database = _db()
    snapshot_id = storage.save_snapshot(database, stories)
    log.info("fetch_completed", snapshot_id=snapshot_id, stories=len(stories))
    console.print(f"Saved snapshot {snapshot_id} with {len(stories)} stories.")


@app.command("list")
def list_cmd(snapshot: Annotated[str, typer.Option("--snapshot")] = "LATEST") -> None:
    """Print a saved snapshot as a table."""
    rows = storage.get_snapshot(_db(), snapshot)
    table = Table(title=f"Hacker News Snapshot {snapshot}")
    for column in ["Rank", "ID", "Score", "Comments", "Author", "Title"]:
        table.add_column(column)
    for row in rows:
        table.add_row(
            str(row["rank"]),
            str(row["id"]),
            str(row["score"]),
            str(row["descendants"]),
            row["by"] or "",
            row["title"],
        )
    console.print(table)


@app.command()
def diff(
    from_: Annotated[int | None, typer.Option("--from")] = None,
    to: Annotated[int | None, typer.Option("--to")] = None,
) -> None:
    """Compare two snapshots."""
    snapshot_diff = storage.diff_snapshots(_db(), from_, to)
    table = Table(title="Snapshot Diff")
    for column in ["Type", "Rank", "Delta", "ID", "Title"]:
        table.add_column(column)
    for row in snapshot_diff.entered:
        table.add_row("entered", str(row["rank"]), "", str(row["id"]), row["title"])
    for row in snapshot_diff.left:
        table.add_row("left", str(row["rank"]), "", str(row["id"]), row["title"])
    for row in snapshot_diff.changed:
        table.add_row(
            "rank changed",
            f'{row["old_rank"]}->{row["new_rank"]}',
            f'{row["delta"]:+d}',
            str(row["id"]),
            row["title"],
        )
    console.print(table)


@app.command()
def story(id: Annotated[int, typer.Argument()]) -> None:
    """Fetch and print one story plus its first five top-level comments."""
    story_item, comments = asyncio.run(fetch_story_with_comments(id, limit=5))
    if not story_item:
        raise typer.BadParameter(f"Story {id} not found")
    metadata = Table(title=f"Story {id}")
    metadata.add_column("Field")
    metadata.add_column("Value")
    for key in ["title", "url", "score", "by", "time", "descendants", "type"]:
        metadata.add_row(key, str(story_item.get(key, "")))
    console.print(metadata)
    for index, comment in enumerate(comments, start=1):
        text = str(comment.get("text") or "").replace("<p>", "\n").replace("&#x27;", "'")
        console.print(Panel(text, title=f"Comment {index} by {comment.get('by', '')}"))


@app.command()
def search(query: Annotated[str, typer.Argument()]) -> None:
    """Search saved story titles with SQLite FTS5."""
    rows = storage.search_titles(_db(), query)
    table = Table(title=f"Search: {query}")
    for column in ["ID", "Score", "Author", "Title"]:
        table.add_column(column)
    for row in rows:
        table.add_row(str(row["id"]), str(row["score"]), row["by"], row["title"])
    console.print(table)


@app.command()
def stats() -> None:
    """Print database statistics."""
    data = storage.stats(_db())
    table = Table(title="HN Tracker Stats")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Snapshots", str(data["snapshots"]))
    table.add_row("Unique stories", str(data["unique_stories"]))
    table.add_row("Oldest fetched_at", str(data["oldest_fetched_at"] or ""))
    table.add_row("Newest fetched_at", str(data["newest_fetched_at"] or ""))
    authors = ", ".join(f"{author} ({count})" for author, count in data["top_authors"])
    table.add_row("Top authors", authors)
    console.print(table)


@app.command()
def export(format: Annotated[str, typer.Argument(help="json, csv, or markdown")]) -> None:
    """Export the latest snapshot."""
    rows = storage.get_snapshot(_db(), "LATEST")
    if format == "json":
        typer.echo(json.dumps(rows, indent=2))
    elif format == "csv":
        output = io.StringIO()
        fieldnames = ["rank", "id", "title", "url", "score", "by", "time", "descendants", "type", "fetched_at"]
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
        typer.echo(output.getvalue(), nl=False)
    elif format == "markdown":
        headers = ["rank", "id", "score", "by", "title"]
        lines = [
            "| " + " | ".join(headers) + " |",
            "| " + " | ".join("---" for _ in headers) + " |",
        ]
        lines.extend(
            "| "
            + " | ".join(str(row[column]).replace("|", "\\|") for column in headers)
            + " |"
            for row in rows
        )
        console.print(Markdown("\n".join(lines)))
    else:
        raise typer.BadParameter("format must be one of: json, csv, markdown")


@app.command()
def watch(interval: Annotated[int, typer.Option("--interval", min=1)] = 60) -> None:
    """Fetch repeatedly until Ctrl-C."""
    database = _db()
    try:
        while True:
            stories = asyncio.run(fetch_top_stories(30))
            before_latest = storage.resolve_snapshot(database)
            snapshot_id = storage.save_snapshot(database, stories)
            summary = f"snapshot {snapshot_id}: {len(stories)} stories"
            if before_latest is not None:
                snapshot_diff = storage.diff_snapshots(database, before_latest, snapshot_id)
                summary += (
                    f", entered={len(snapshot_diff.entered)}, left={len(snapshot_diff.left)}, "
                    f"rank_changed={len(snapshot_diff.changed)}"
                )
            console.print(summary)
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("Stopped.")
        sys.exit(0)
