from __future__ import annotations

import sqlite3
from collections import Counter
from pathlib import Path
from typing import Any

from sqlite_utils import Database

from hn_tracker.models import SnapshotDiff, Story


STORY_COLUMNS = {
    "id": int,
    "title": str,
    "url": str,
    "score": int,
    "by": str,
    "time": int,
    "descendants": int,
    "type": str,
    "fetched_at": str,
}


def connect(path: str | Path = "hn.db") -> Database:
    db = Database(str(path))
    ensure_schema(db)
    return db


def ensure_schema(db: Database) -> None:
    db["stories"].create(STORY_COLUMNS, pk="id", if_not_exists=True)
    db["snapshots"].create({"id": int, "fetched_at": str}, pk="id", if_not_exists=True)
    db["snapshot_items"].create(
        {
            "snapshot_id": int,
            "story_id": int,
            "rank": int,
            "fetched_at": str,
        },
        pk=("snapshot_id", "story_id"),
        if_not_exists=True,
    )
    conn = db.conn
    conn.execute(
        "CREATE VIRTUAL TABLE IF NOT EXISTS story_titles_fts "
        "USING fts5(story_id UNINDEXED, title)"
    )
    conn.commit()


def save_snapshot(db: Database, stories: list[Story]) -> int:
    if not stories:
        raise ValueError("Cannot save an empty snapshot")
    fetched_at = stories[0].fetched_at
    db["snapshots"].insert({"fetched_at": fetched_at}, pk="id")
    snapshot_id = int(db.conn.execute("SELECT last_insert_rowid()").fetchone()[0])
    db["stories"].upsert_all(
        [
            {
                "id": story.id,
                "title": story.title,
                "url": story.url,
                "score": story.score,
                "by": story.by,
                "time": story.time,
                "descendants": story.descendants,
                "type": story.type,
                "fetched_at": story.fetched_at,
            }
            for story in stories
        ],
        pk="id",
    )
    db["snapshot_items"].insert_all(
        [
            {
                "snapshot_id": snapshot_id,
                "story_id": story.id,
                "rank": rank,
                "fetched_at": story.fetched_at,
            }
            for rank, story in enumerate(stories, start=1)
        ],
        pk=("snapshot_id", "story_id"),
    )
    refresh_fts(db)
    return snapshot_id


def refresh_fts(db: Database) -> None:
    conn = db.conn
    conn.execute("DELETE FROM story_titles_fts")
    conn.execute(
        "INSERT INTO story_titles_fts(story_id, title) SELECT id, title FROM stories"
    )
    conn.commit()


def snapshot_ids(db: Database) -> list[int]:
    return [
        int(row["id"])
        for row in db.query("SELECT id FROM snapshots ORDER BY id")
    ]


def resolve_snapshot(db: Database, selector: str | int | None = None) -> int | None:
    ids = snapshot_ids(db)
    if not ids:
        return None
    if selector is None or str(selector).upper() == "LATEST":
        return ids[-1]
    snapshot_id = int(selector)
    if snapshot_id not in ids:
        raise ValueError(f"Snapshot {snapshot_id} does not exist")
    return snapshot_id


def get_snapshot(db: Database, selector: str | int | None = None) -> list[dict[str, Any]]:
    snapshot_id = resolve_snapshot(db, selector)
    if snapshot_id is None:
        return []
    return list(
        db.query(
            """
            SELECT si.rank, s.id, s.title, s.url, s.score, s.by, s.time,
                   s.descendants, s.type, si.fetched_at
            FROM snapshot_items si
            JOIN stories s ON s.id = si.story_id
            WHERE si.snapshot_id = ?
            ORDER BY si.rank
            """,
            [snapshot_id],
        )
    )


def get_story(db: Database, story_id: int) -> dict[str, Any] | None:
    rows = list(db.query("SELECT * FROM stories WHERE id = ?", [story_id]))
    return rows[0] if rows else None


def diff_snapshots(db: Database, from_id: int | None = None, to_id: int | None = None) -> SnapshotDiff:
    ids = snapshot_ids(db)
    if len(ids) < 2 and (from_id is None or to_id is None):
        raise ValueError("Need at least two snapshots to diff")
    if from_id is None:
        from_id = ids[-2]
    if to_id is None:
        to_id = ids[-1]
    before = {row["id"]: row for row in get_snapshot(db, from_id)}
    after = {row["id"]: row for row in get_snapshot(db, to_id)}
    entered = [after[story_id] for story_id in after.keys() - before.keys()]
    left = [before[story_id] for story_id in before.keys() - after.keys()]
    changed = []
    for story_id in before.keys() & after.keys():
        old_rank = int(before[story_id]["rank"])
        new_rank = int(after[story_id]["rank"])
        if old_rank != new_rank:
            row = dict(after[story_id])
            row["old_rank"] = old_rank
            row["new_rank"] = new_rank
            row["delta"] = old_rank - new_rank
            changed.append(row)
    entered.sort(key=lambda row: int(row["rank"]))
    left.sort(key=lambda row: int(row["rank"]))
    changed.sort(key=lambda row: abs(int(row["delta"])), reverse=True)
    return SnapshotDiff(entered=entered, left=left, changed=changed)


def search_titles(db: Database, query: str) -> list[dict[str, Any]]:
    try:
        return list(
            db.query(
                """
                SELECT s.id, s.title, s.url, s.score, s.by, s.fetched_at
                FROM story_titles_fts f
                JOIN stories s ON s.id = f.story_id
                WHERE story_titles_fts MATCH ?
                ORDER BY bm25(story_titles_fts), s.score DESC
                """,
                [query],
            )
        )
    except sqlite3.OperationalError:
        return []


def stats(db: Database) -> dict[str, Any]:
    snapshot_count = db.conn.execute("SELECT COUNT(*) FROM snapshots").fetchone()[0]
    unique_stories = db.conn.execute("SELECT COUNT(*) FROM stories").fetchone()[0]
    authors = Counter(
        row["by"]
        for row in db.query("SELECT s.by FROM snapshot_items si JOIN stories s ON s.id = si.story_id")
        if row["by"]
    )
    fetched = db.conn.execute(
        "SELECT MIN(fetched_at), MAX(fetched_at) FROM snapshot_items"
    ).fetchone()
    return {
        "snapshots": snapshot_count,
        "unique_stories": unique_stories,
        "top_authors": authors.most_common(5),
        "oldest_fetched_at": fetched[0],
        "newest_fetched_at": fetched[1],
    }
