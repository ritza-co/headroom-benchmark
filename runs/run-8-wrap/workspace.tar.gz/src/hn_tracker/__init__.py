from hn_tracker.cli import main

__all__ = ["main"]
