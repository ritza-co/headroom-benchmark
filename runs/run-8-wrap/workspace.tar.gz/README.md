# hn-tracker

`hn-tracker` is a Python CLI for tracking Hacker News top stories over time.

It fetches snapshots from the public Hacker News Firebase API.

It stores story metadata in a local SQLite database at `./hn.db`.

It can list snapshots, compare them, search saved titles, export data, and watch HN repeatedly.

The project is built with `uv`, `typer`, `httpx`, `sqlite-utils`, `rich`, and `structlog`.

## Install

Install `uv` from the official Astral documentation.

Clone or enter this repository.

Run:

```bash
uv sync
```

Run the CLI:

```bash
uv run hn-tracker --help
```

Install the package into the active uv environment:

```bash
uv pip install -e .
```

## Database

The default database path is:

```text
./hn.db
```

Delete `hn.db` to start over.

Snapshots are append-only.

Story rows are upserted by Hacker News item id.

Snapshot membership is stored separately with ranks.

Title search uses SQLite FTS5.

## Subcommands

### fetch

Fetch the current top Hacker News stories.

Default limit is 30.

Requests for story items are concurrent through `httpx.AsyncClient`.

Example:

```bash
uv run hn-tracker fetch --limit 30
```

Example output:

```text
Saved snapshot 1 with 30 stories.
```

### list

Print a saved snapshot as a Rich table.

By default, it prints the latest snapshot.

Example:

```bash
uv run hn-tracker list
```

Example output:

```text
          Hacker News Snapshot LATEST
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━┳━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Rank ┃ ID       ┃ Score ┃ Comments ┃ Author ┃ Title        ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━╇━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━┩
│ 1    │ 12345678 │ 512   │ 120      │ user   │ Example post │
└──────┴──────────┴───────┴──────────┴────────┴──────────────┘
```

Select a snapshot:

```bash
uv run hn-tracker list --snapshot 2
```

Use `LATEST` explicitly:

```bash
uv run hn-tracker list --snapshot LATEST
```

### diff

Compare two snapshots.

Without arguments, it compares the two most recent snapshots.

Example:

```bash
uv run hn-tracker diff
```

Example output:

```text
                  Snapshot Diff
┏━━━━━━━━━━━━━━┳━━━━━━┳━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Type         ┃ Rank ┃ Delta ┃ ID       ┃ Title        ┃
┡━━━━━━━━━━━━━━╇━━━━━━╇━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│ entered      │ 3    │       │ 22222222 │ New story    │
│ left         │ 8    │       │ 11111111 │ Old story    │
│ rank changed │ 5->2 │ +3    │ 33333333 │ Moving story │
└──────────────┴──────┴───────┴──────────┴──────────────┘
```

Compare explicit snapshots:

```bash
uv run hn-tracker diff --from 1 --to 3
```

Delta is old rank minus new rank.

A positive delta means the story moved up.

### story

Fetch a single live HN item and its first five top-level comments.

Example:

```bash
uv run hn-tracker story 8863
```

Example output:

```text
             Story 8863
┏━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ Field       ┃ Value              ┃
┡━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ title       │ My YC app          │
│ score       │ 57                 │
│ by          │ pg                 │
│ descendants │ 15                 │
└─────────────┴────────────────────┘
╭──────── Comment 1 by user ───────╮
│ This is an example comment.      │
╰──────────────────────────────────╯
```

### search

Search saved story titles.

The search reads from SQLite FTS5.

Example:

```bash
uv run hn-tracker search rust
```

Example output:

```text
             Search: rust
┏━━━━━━━━━━┳━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃ ID       ┃ Score ┃ Author ┃ Title              ┃
┡━━━━━━━━━━╇━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ 12345678 │ 220   │ user   │ Rust in production │
└──────────┴───────┴────────┴────────────────────┘
```

Zero results is valid.

### stats

Print database statistics.

Example:

```bash
uv run hn-tracker stats
```

Example output:

```text
              HN Tracker Stats
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric            ┃ Value                     ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Snapshots         │ 4                         │
│ Unique stories    │ 82                        │
│ Oldest fetched_at │ 2026-06-04T10:00:00+00:00 │
│ Newest fetched_at │ 2026-06-04T12:00:00+00:00 │
│ Top authors       │ alice (3), bob (2)        │
└───────────────────┴───────────────────────────┘
```

### export

Export the latest snapshot to stdout.

Formats are `json`, `csv`, and `markdown`.

JSON example:

```bash
uv run hn-tracker export json
```

CSV example:

```bash
uv run hn-tracker export csv
```

Markdown example:

```bash
uv run hn-tracker export markdown
```

Example JSON output:

```json
[
  {
    "rank": 1,
    "id": 12345678,
    "title": "Example story",
    "url": "https://example.com",
    "score": 120,
    "by": "alice",
    "time": 1700000000,
    "descendants": 42,
    "type": "story",
    "fetched_at": "2026-06-04T10:00:00+00:00"
  }
]
```

### watch

Fetch repeatedly until Ctrl-C.

Default interval is 60 seconds.

Example:

```bash
uv run hn-tracker watch --interval 300
```

Example output:

```text
snapshot 5: 30 stories, entered=3, left=3, rank_changed=22
```

## Architecture

The CLI entrypoint lives in `hn_tracker.cli`.

The Hacker News HTTP client lives in `hn_tracker.hn`.

The SQLite persistence layer lives in `hn_tracker.db`.

Data structures live in `hn_tracker.models`.

Structured logging setup lives in `hn_tracker.logging`.

`fetch_top_stories()` first requests `topstories.json`.

It then concurrently fetches selected `item/<id>.json` documents.

`save_snapshot()` inserts a snapshot row.

It upserts story metadata.

It records story ranks in `snapshot_items`.

It refreshes the title FTS table.

`diff_snapshots()` compares rank maps for two snapshots.

`search_titles()` uses `MATCH` against the FTS5 table.

Rich is used only for human-facing terminal output.

Machine-facing export formats write plain stdout.

Structlog writes INFO events to stderr.

## Development

Sync dependencies:

```bash
uv sync
```

Run tests:

```bash
uv run pytest -v
```

Run a command:

```bash
uv run hn-tracker fetch --limit 10
```

Inspect the database with sqlite-utils:

```bash
uv run sqlite-utils tables hn.db
```

Inspect rows:

```bash
uv run sqlite-utils rows hn.db snapshots
```

Run the smoke test:

```bash
uv run hn-tracker --help
```

Build a wheel:

```bash
uv build
```

Run in Docker:

```bash
docker build -t hn-tracker .
docker run --rm hn-tracker --help
```

Persist Docker database output:

```bash
docker run --rm -v "$PWD:/app" hn-tracker fetch --limit 30
```

## Testing Notes

The test suite uses `typer.testing.CliRunner`.

Tests isolate `hn.db` in temporary directories.

Network calls are mocked in command tests.

The concurrency test mocks `httpx.AsyncClient`.

It tracks simultaneous in-flight item requests.

It asserts more than one item request overlaps.

The export tests parse JSON and CSV instead of checking strings only.

The diff tests verify entered, left, and rank movement behavior.

The FTS test verifies results can be found across multiple snapshots.

## Operational Notes

The Hacker News Firebase API does not require an API key.

The CLI stores the API response fields required by this project.

Story URLs can be null for Ask HN and similar posts.

Comments can contain HTML from Hacker News.

The current renderer does light comment text cleanup.

Repeated snapshots can include the same story id many times.

Stats count unique stories separately from snapshot appearances.

Author frequency is counted across snapshot appearances.

## Roadmap

Add configurable database paths.

Add snapshot pruning.

Add comment storage for historical comment tracking.

Add rank trend charts.

Add author trend reports.

Add domain frequency reports.

Add Algolia integration as an optional search source.

Add configurable story filters.

Add shell completion documentation.

Add a terminal dashboard mode.

Add `watch --limit`.

Add `export --snapshot`.

Add better HTML-to-text rendering for comments.

Add typed result objects for all database queries.

Add migration tests for future schema changes.
