# Changelog

## 0.1.0 - 2026-06-04

- Added `hn-tracker fetch` to collect concurrent Hacker News top-story snapshots into SQLite.
- Added `hn-tracker list` with Rich table output for saved snapshots.
- Added `hn-tracker diff` for entered, left, and rank-changed stories.
- Added `hn-tracker story` to display live story metadata and top-level comments.
- Added `hn-tracker search` backed by SQLite FTS5 title indexing.
- Added `hn-tracker stats` for snapshot, story, author, and timestamp statistics.
- Added `hn-tracker export` for JSON, CSV, and Markdown output.
- Added `hn-tracker watch` for repeated polling and one-line change summaries.
- Added pytest coverage for every subcommand, FTS, exports, diff behavior, and concurrent fetching.
- Added Dockerfile and GitHub Actions CI workflow.
