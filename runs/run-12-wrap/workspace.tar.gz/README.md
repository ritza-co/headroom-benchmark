# hn-tracker

`hn-tracker` is a Python CLI for watching Hacker News top stories over time.

It fetches the current top stories from the public Hacker News Firebase API.

It stores each fetch as a timestamped SQLite snapshot in `./hn.db`.

It can list snapshots, diff rankings, search saved titles, export data, and run continuously.

The project is packaged with uv and exposes a `hn-tracker` command.

## Install

Clone the repository.

Install uv if it is not already installed.

The current recommended uv project workflow is:

```bash
uv sync
```

Run the CLI:

```bash
uv run hn-tracker --help
```

Install the package in editable-style development mode through uv:

```bash
uv sync
```

The local database is created at:

```text
./hn.db
```

## Dependencies

Runtime dependencies are pinned in `pyproject.toml`.

The CLI uses `typer`.

HTTP requests use `httpx`.

Output tables use `rich`.

The database layer uses `sqlite-utils` with direct SQLite statements.

Logs use `structlog` and write INFO-style structured lines to stderr.

Tests use `pytest`, `pytest-mock`, and `pytest-asyncio`.

## Command: fetch

Fetch the current top stories and store a new snapshot.

```bash
uv run hn-tracker fetch
```

Fetch fewer stories:

```bash
uv run hn-tracker fetch --limit 10
```

Example output:

```text
Fetched snapshot 1 with 10 stories.
```

If there is a previous snapshot, the output also includes a compact change count.

```text
Fetched snapshot 2 with 10 stories. entered=2 left=2 rank_changed=7
```

The fetch implementation requests story item metadata concurrently.

It does not fetch the story items one at a time.

## Command: list

Print the latest snapshot as a Rich table.

```bash
uv run hn-tracker list
```

Print a specific snapshot:

```bash
uv run hn-tracker list --snapshot 3
```

Example output:

```text
                 Snapshot 3 (2026-06-04T15:15:20+00:00)
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ Rank ┃       ID ┃ Score ┃ By     ┃ Title                ┃ URL          ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━┩
│    1 │ 12345678 │   431 │ alice  │ Example HN story     │ https://...  │
└──────┴──────────┴───────┴────────┴──────────────────────┴──────────────┘
```

The default `--snapshot LATEST` selector chooses the newest stored snapshot.

## Command: diff

Compare two snapshots.

```bash
uv run hn-tracker diff --from 1 --to 2
```

If `--from` and `--to` are omitted, the two most recent snapshots are compared.

```bash
uv run hn-tracker diff
```

Example output:

```text
Snapshot 1 -> 2

Entered
Rank  ID        Title
2     45678901  New story

Left
Rank  ID        Title
9     12345678  Older story

Rank Changed
ID        Title          From  To  Delta
22222222  Moving story   5     1   +4
```

Positive delta means the story moved up.

Negative delta means the story moved down.

## Command: story

Fetch one live HN item and show its metadata.

It also fetches the first five top-level comments from the story's `kids` list.

```bash
uv run hn-tracker story 8863
```

Example output:

```text
╭──────────── Story ────────────╮
│ id           8863             │
│ type         story            │
│ title        My YC app        │
│ score        57               │
│ by           pg               │
╰───────────────────────────────╯

First 5 Top-Level Comments
ID     By       Text
123    user     Interesting point...
```

This command uses the live HN item API.

It does not require the story to already exist in `hn.db`.

## Command: search

Search saved story titles with SQLite FTS5.

```bash
uv run hn-tracker search rust
```

Example output:

```text
Search: rust
ID        Title
12345678  Rust reaches orbit
23456789  Async Rust notes
```

Search covers unique saved story titles across all snapshots.

If a story appears in several snapshots, it appears once in search results.

## Command: stats

Print database statistics.

```bash
uv run hn-tracker stats
```

Example output:

```text
HN Tracker Stats
Metric              Value
Snapshots           4
Unique stories      94
Oldest fetched_at   2026-06-04T12:00:00+00:00
Newest fetched_at   2026-06-04T15:00:00+00:00
Top authors         alice (5), bob (4), carol (4)
```

Stats include snapshot count and unique story count.

Stats also include the top five most frequent authors by saved rows.

## Command: export

Export the latest snapshot to stdout.

JSON:

```bash
uv run hn-tracker export json
```

CSV:

```bash
uv run hn-tracker export csv
```

Markdown:

```bash
uv run hn-tracker export markdown
```

Example JSON output:

```json
[
  {
    "rank": 1,
    "id": 12345678,
    "title": "Example HN story",
    "url": "https://example.com",
    "score": 431,
    "by": "alice"
  }
]
```

Example CSV output:

```text
rank,id,title,url,score,by,time,descendants,type,fetched_at
1,12345678,Example HN story,https://example.com,431,alice,1700000000,22,story,2026-06-04T15:00:00+00:00
```

Example Markdown output:

```text
| Rank | ID | Title | Score | By | URL |
| ---: | ---: | --- | ---: | --- | --- |
| 1 | 12345678 | Example HN story | 431 | alice | https://example.com |
```

## Command: watch

Fetch on a loop until Ctrl-C.

```bash
uv run hn-tracker watch
```

Use a shorter interval:

```bash
uv run hn-tracker watch --interval 15
```

Example output:

```text
Watching Hacker News every 15s. Press Ctrl-C to stop.
snapshot=1 stories=30 initial=true
snapshot=2 stories=30 entered=3 left=3 rank_changed=22
```

The command sleeps between fetches.

Press Ctrl-C to stop cleanly.

## Architecture

The package lives under `src/hn_tracker`.

`hn_tracker.cli` defines the Typer application and presentation code.

`hn_tracker.hn` contains async Hacker News API fetchers.

`hn_tracker.db` owns SQLite schema creation, snapshot persistence, diffing, search, stats, and export logic.

The database has a `snapshots` table.

The database has a `story_snapshots` table.

Each row in `story_snapshots` stores id, title, url, score, by, time, descendants, type, and fetched_at.

The database has a `story_search` table for unique searchable stories.

The database has a `story_search_fts` FTS5 virtual table.

Fetches store a new snapshot every time.

Diffs compare rank maps between two saved snapshots.

Exports always use the latest snapshot.

## Development

Install dependencies:

```bash
uv sync
```

Run tests:

```bash
uv run pytest -v
```

Run a live fetch:

```bash
uv run hn-tracker fetch --limit 30
```

Inspect help:

```bash
uv run hn-tracker --help
```

Use sqlite-utils for manual database inspection:

```bash
uv run sqlite-utils tables hn.db
```

Show rows:

```bash
uv run sqlite-utils rows hn.db story_snapshots --limit 5
```

The test suite creates isolated temporary working directories.

Tests do not depend on a pre-existing `hn.db`.

Network-facing behavior is mocked except for manual verification commands.

## Docker

Build the image:

```bash
docker build -t hn-tracker .
```

Run help:

```bash
docker run --rm hn-tracker --help
```

Run a fetch with a bind mount for persistent data:

```bash
docker run --rm -v "$PWD:/data" -w /data hn-tracker fetch --limit 30
```

The Docker entrypoint is `hn-tracker`.

## Continuous Integration

GitHub Actions is configured in `.github/workflows/ci.yml`.

The workflow installs uv.

It sets up Python 3.12.

It runs `uv sync --frozen`.

It runs `uv run pytest -v`.

It runs `uv run hn-tracker --help` as a smoke test.

## Roadmap

Add snapshot pruning controls.

Add configurable database paths.

Add comment search.

Add story URL domain statistics.

Add JSON Lines export.

Add terminal watch rendering with live Rich refresh.

Add saved query aliases.

Add API retry/backoff controls.

Add optional Algolia enrichment.

Add trend scoring across many snapshots.
