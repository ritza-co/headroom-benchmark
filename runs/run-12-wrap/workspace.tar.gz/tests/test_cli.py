from __future__ import annotations

import asyncio
import csv
import io
import json
from pathlib import Path
from typing import Any

import httpx
import pytest
from typer.testing import CliRunner

from hn_tracker.cli import app
from hn_tracker.db import HNDatabase

runner = CliRunner()


def make_story(story_id: int, rank: int, title: str, by: str = "alice") -> dict[str, Any]:
    return {
        "id": story_id,
        "rank": rank,
        "title": title,
        "url": f"https://example.com/{story_id}",
        "score": 100 - rank,
        "by": by,
        "time": 1_700_000_000 + story_id,
        "descendants": rank,
        "type": "story",
    }


@pytest.fixture(autouse=True)
def isolated_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)


def seed_snapshots() -> HNDatabase:
    db = HNDatabase()
    db.create_snapshot(
        [
            make_story(1, 1, "Rust reaches orbit", "alice"),
            make_story(2, 2, "Python testing guide", "bob"),
            make_story(3, 3, "SQLite tips", "alice"),
        ],
        fetched_at="2026-01-01T00:00:00+00:00",
    )
    db.create_snapshot(
        [
            make_story(2, 1, "Python testing guide", "bob"),
            make_story(4, 2, "Rust async news", "carol"),
            make_story(1, 3, "Rust reaches orbit", "alice"),
        ],
        fetched_at="2026-01-01T01:00:00+00:00",
    )
    return db


def test_fetch_command_stores_snapshot(mocker: pytest.MockFixture) -> None:
    mocker.patch(
        "hn_tracker.cli.fetch_top_stories",
        return_value=[make_story(10, 1, "A"), make_story(11, 2, "B")],
    )
    result = runner.invoke(app, ["fetch", "--limit", "2"])
    assert result.exit_code == 0
    assert "Fetched snapshot 1 with 2 stories" in result.stdout
    assert len(HNDatabase().stories_for_snapshot(1)) == 2


def test_list_command_prints_latest_snapshot() -> None:
    seed_snapshots()
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "Snapshot 2" in result.stdout
    assert "Rust async news" in result.stdout


def test_diff_command_identifies_entered_left_and_rank_changed() -> None:
    seed_snapshots()
    result = runner.invoke(app, ["diff", "--from", "1", "--to", "2"])
    assert result.exit_code == 0
    assert "Rust async news" in result.stdout
    assert "SQLite tips" in result.stdout
    assert "+1" in result.stdout
    assert "-2" in result.stdout


def test_story_command_prints_metadata_and_comments(mocker: pytest.MockFixture) -> None:
    mocker.patch(
        "hn_tracker.cli.fetch_story_with_comments",
        return_value=(
            {"id": 42, "type": "story", "title": "Answer", "url": "https://example.com", "score": 5, "by": "dan", "time": 1, "descendants": 1},
            [{"id": 43, "by": "eve", "text": "nice post"}],
        ),
    )
    result = runner.invoke(app, ["story", "42"])
    assert result.exit_code == 0
    assert "Answer" in result.stdout
    assert "nice post" in result.stdout


def test_search_command_uses_fts() -> None:
    seed_snapshots()
    result = runner.invoke(app, ["search", "Rust"])
    assert result.exit_code == 0
    assert "Rust reaches orbit" in result.stdout
    assert "Rust async news" in result.stdout
    assert "Python testing guide" not in result.stdout


def test_fts_search_returns_correct_results_across_multiple_snapshots() -> None:
    seed_snapshots()
    results = HNDatabase().search("Rust")
    assert {row["id"] for row in results} == {1, 4}


def test_stats_command_prints_database_stats() -> None:
    seed_snapshots()
    result = runner.invoke(app, ["stats"])
    assert result.exit_code == 0
    assert "Snapshots" in result.stdout
    assert "2" in result.stdout
    assert "alice" in result.stdout


def test_export_json_and_csv_are_valid() -> None:
    seed_snapshots()
    json_result = runner.invoke(app, ["export", "json"])
    assert json_result.exit_code == 0
    parsed = json.loads(json_result.stdout)
    assert parsed[0]["id"] == 2

    csv_result = runner.invoke(app, ["export", "csv"])
    assert csv_result.exit_code == 0
    rows = list(csv.DictReader(io.StringIO(csv_result.stdout)))
    assert rows[0]["title"] == "Python testing guide"


def test_export_markdown_command() -> None:
    seed_snapshots()
    result = runner.invoke(app, ["export", "markdown"])
    assert result.exit_code == 0
    assert "| Rank | ID | Title | Score | By | URL |" in result.stdout


def test_watch_command_runs_until_keyboard_interrupt(mocker: pytest.MockFixture) -> None:
    mocker.patch("hn_tracker.cli.fetch_top_stories", return_value=[make_story(20, 1, "Watch story")])
    mocker.patch("hn_tracker.cli.time.sleep", side_effect=KeyboardInterrupt)
    result = runner.invoke(app, ["watch", "--interval", "1"])
    assert result.exit_code == 0
    assert "snapshot=1" in result.stdout
    assert "Stopped" in result.stdout


def test_help_lists_every_subcommand() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for command in ["fetch", "list", "diff", "story", "search", "stats", "export", "watch"]:
        assert command in result.stdout


@pytest.mark.asyncio
async def test_fetch_uses_concurrent_item_requests(monkeypatch: pytest.MonkeyPatch) -> None:
    from hn_tracker import hn

    in_flight = 0
    max_in_flight = 0

    class FakeResponse:
        def __init__(self, payload: Any) -> None:
            self.payload = payload

        def raise_for_status(self) -> None:
            return None

        def json(self) -> Any:
            return self.payload

    class FakeClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            return None

        async def __aenter__(self) -> "FakeClient":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def get(self, url: str) -> FakeResponse:
            nonlocal in_flight, max_in_flight
            if url.endswith("topstories.json"):
                return FakeResponse([101, 102, 103, 104])
            item_id = int(url.rsplit("/", 1)[1].split(".")[0])
            in_flight += 1
            max_in_flight = max(max_in_flight, in_flight)
            await asyncio.sleep(0.01)
            in_flight -= 1
            return FakeResponse(
                {
                    "id": item_id,
                    "title": f"Story {item_id}",
                    "score": 1,
                    "by": "author",
                    "time": 1,
                    "descendants": 0,
                    "type": "story",
                }
            )

    monkeypatch.setattr(httpx, "AsyncClient", FakeClient)
    stories = await hn.fetch_top_stories(limit=4)
    assert len(stories) == 4
    assert max_in_flight > 1
