from __future__ import annotations

import asyncio
from typing import Any

import httpx

BASE_URL = "https://hacker-news.firebaseio.com/v0"


async def fetch_top_stories(limit: int = 30) -> list[dict[str, Any]]:
    """Fetch top story metadata concurrently from the HN Firebase API."""
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(f"{BASE_URL}/topstories.json")
        response.raise_for_status()
        ids = response.json()[:limit]

        async def fetch_item(rank: int, item_id: int) -> dict[str, Any] | None:
            item_response = await client.get(f"{BASE_URL}/item/{item_id}.json")
            item_response.raise_for_status()
            item = item_response.json()
            if not item:
                return None
            item["rank"] = rank
            return item

        tasks = [fetch_item(rank, item_id) for rank, item_id in enumerate(ids, start=1)]
        results = await asyncio.gather(*tasks)
        return [item for item in results if item is not None]


async def fetch_item(item_id: int) -> dict[str, Any] | None:
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(f"{BASE_URL}/item/{item_id}.json")
        response.raise_for_status()
        return response.json()


async def fetch_story_with_comments(item_id: int, comment_limit: int = 5) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        story_response = await client.get(f"{BASE_URL}/item/{item_id}.json")
        story_response.raise_for_status()
        story = story_response.json()
        if not story:
            return None, []

        comment_ids = story.get("kids", [])[:comment_limit]

        async def fetch_comment(comment_id: int) -> dict[str, Any] | None:
            comment_response = await client.get(f"{BASE_URL}/item/{comment_id}.json")
            comment_response.raise_for_status()
            comment = comment_response.json()
            if not comment or comment.get("deleted") or comment.get("dead"):
                return None
            return comment

        comments = await asyncio.gather(*(fetch_comment(comment_id) for comment_id in comment_ids))
        return story, [comment for comment in comments if comment is not None]
