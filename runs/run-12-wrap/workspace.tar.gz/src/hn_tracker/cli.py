from __future__ import annotations

import asyncio
import html
import sys
import time
from typing import Literal

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hn_tracker.db import HNDatabase
from hn_tracker.hn import fetch_story_with_comments, fetch_top_stories

app = typer.Typer(help="Track Hacker News top stories over time.")
console = Console()
err_console = Console(stderr=True)


def configure_logging() -> None:
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.KeyValueRenderer(),
        ],
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
    )


logger = structlog.get_logger("hn_tracker")


def main() -> None:
    configure_logging()
    app()


@app.command()
def fetch(limit: int = typer.Option(30, "--limit", min=1, help="Number of top stories to fetch.")) -> None:
    """Fetch the current top stories and store a snapshot in ./hn.db."""
    stories = asyncio.run(fetch_top_stories(limit))
    db = HNDatabase()
    previous = db.latest_snapshot()
    snapshot = db.create_snapshot(stories)
    logger.info("snapshot_fetched", snapshot_id=snapshot.id, story_count=len(stories), fetched_at=snapshot.fetched_at)
    summary = ""
    if previous:
        diff_result = db.diff(previous.id, snapshot.id)
        summary = (
            f" entered={len(diff_result['entered'])}"
            f" left={len(diff_result['left'])}"
            f" rank_changed={len(diff_result['rank_changed'])}"
        )
    console.print(f"Fetched snapshot {snapshot.id} with {len(stories)} stories.{summary}")


@app.command("list")
def list_snapshot(snapshot: str = typer.Option("LATEST", "--snapshot", help="Snapshot id or LATEST.")) -> None:
    """Print a saved snapshot as a Rich table."""
    db = HNDatabase()
    selected = db.snapshot_by_selector(snapshot)
    if not selected:
        raise typer.BadParameter(f"Snapshot {snapshot} was not found")
    stories = db.stories_for_snapshot(selected.id)
    table = story_table(f"Snapshot {selected.id} ({selected.fetched_at})")
    for story in stories:
        add_story_row(table, story)
    console.print(table)


@app.command()
def diff(
    from_snapshot: int | None = typer.Option(None, "--from", help="Older snapshot id."),
    to_snapshot: int | None = typer.Option(None, "--to", help="Newer snapshot id."),
) -> None:
    """Compare two snapshots."""
    db = HNDatabase()
    if from_snapshot is None or to_snapshot is None:
        recent = db.two_most_recent_snapshot_ids()
        if not recent:
            raise typer.BadParameter("Need at least two snapshots to diff")
        from_snapshot, to_snapshot = recent
    result = db.diff(from_snapshot, to_snapshot)
    console.print(f"[bold]Snapshot {from_snapshot} -> {to_snapshot}[/bold]")
    print_diff_section("Entered", result["entered"], "rank")
    print_diff_section("Left", result["left"], "rank")

    changed = Table(title="Rank Changed")
    changed.add_column("ID", justify="right")
    changed.add_column("Title")
    changed.add_column("From", justify="right")
    changed.add_column("To", justify="right")
    changed.add_column("Delta", justify="right")
    for story in result["rank_changed"]:
        changed.add_row(
            str(story["id"]),
            story["title"],
            str(story["from_rank"]),
            str(story["to_rank"]),
            f"{story['delta']:+d}",
        )
    console.print(changed)


@app.command()
def story(id: int = typer.Argument(..., help="HN item id.")) -> None:
    """Fetch one story and its first five top-level comments."""
    item, comments = asyncio.run(fetch_story_with_comments(id))
    if not item:
        raise typer.BadParameter(f"Story {id} was not found")
    meta = Table.grid(padding=(0, 2))
    meta.add_column(style="bold")
    meta.add_column()
    for key in ["id", "type", "title", "url", "score", "by", "time", "descendants"]:
        meta.add_row(key, str(item.get(key, "")))
    console.print(Panel(meta, title="Story"))
    comment_table = Table(title="First 5 Top-Level Comments")
    comment_table.add_column("ID", justify="right")
    comment_table.add_column("By")
    comment_table.add_column("Text")
    for comment in comments:
        text = html.unescape(comment.get("text", "")).replace("<p>", "\n").replace("<br>", "\n")
        comment_table.add_row(str(comment.get("id", "")), str(comment.get("by", "")), text)
    console.print(comment_table)


@app.command()
def search(query: str = typer.Argument(..., help="SQLite FTS5 query.")) -> None:
    """Search saved story titles."""
    db = HNDatabase()
    results = db.search(query)
    table = Table(title=f"Search: {query}")
    table.add_column("ID", justify="right")
    table.add_column("Title")
    for result in results:
        table.add_row(str(result["id"]), result["title"])
    console.print(table)


@app.command()
def stats() -> None:
    """Print database statistics."""
    db = HNDatabase()
    data = db.stats()
    table = Table(title="HN Tracker Stats")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Snapshots", str(data["snapshots"]))
    table.add_row("Unique stories", str(data["unique_stories"]))
    table.add_row("Oldest fetched_at", str(data["oldest_fetched_at"] or ""))
    table.add_row("Newest fetched_at", str(data["newest_fetched_at"] or ""))
    authors = ", ".join(f"{author} ({count})" for author, count in data["top_authors"])
    table.add_row("Top authors", authors)
    console.print(table)


@app.command()
def export(format: Literal["json", "csv", "markdown"] = typer.Argument(..., help="json, csv, or markdown.")) -> None:
    """Export the latest snapshot to stdout."""
    db = HNDatabase()
    sys.stdout.write(db.export_latest(format))
    if format != "csv":
        sys.stdout.write("\n")


@app.command()
def watch(interval: int = typer.Option(60, "--interval", min=1, help="Seconds between fetches.")) -> None:
    """Fetch repeatedly until Ctrl-C."""
    db = HNDatabase()
    console.print(f"Watching Hacker News every {interval}s. Press Ctrl-C to stop.")
    try:
        while True:
            previous = db.latest_snapshot()
            stories = asyncio.run(fetch_top_stories(30))
            snapshot = db.create_snapshot(stories)
            if previous:
                result = db.diff(previous.id, snapshot.id)
                console.print(
                    f"snapshot={snapshot.id} stories={len(stories)} entered={len(result['entered'])} "
                    f"left={len(result['left'])} rank_changed={len(result['rank_changed'])}"
                )
            else:
                console.print(f"snapshot={snapshot.id} stories={len(stories)} initial=true")
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("Stopped.")


def story_table(title: str) -> Table:
    table = Table(title=title)
    table.add_column("Rank", justify="right")
    table.add_column("ID", justify="right")
    table.add_column("Score", justify="right")
    table.add_column("By")
    table.add_column("Title")
    table.add_column("URL")
    return table


def add_story_row(table: Table, story: dict[str, object]) -> None:
    table.add_row(
        str(story["rank"]),
        str(story["id"]),
        str(story.get("score") or ""),
        str(story.get("by") or ""),
        str(story["title"]),
        str(story.get("url") or ""),
    )


def print_diff_section(title: str, stories: list[dict[str, object]], rank_key: str) -> None:
    table = Table(title=title)
    table.add_column("Rank", justify="right")
    table.add_column("ID", justify="right")
    table.add_column("Title")
    for story in stories:
        table.add_row(str(story[rank_key]), str(story["id"]), str(story["title"]))
    console.print(table)
