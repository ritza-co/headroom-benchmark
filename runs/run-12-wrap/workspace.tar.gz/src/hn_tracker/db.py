from __future__ import annotations

import csv
import io
import json
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from sqlite_utils import Database
import sqlite3

DB_PATH = Path("hn.db")


@dataclass(frozen=True)
class Snapshot:
    id: int
    fetched_at: str


def now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


class HNDatabase:
    def __init__(self, path: Path | str = DB_PATH) -> None:
        self.path = Path(path)
        self.db = Database(self.path)
        self.conn = self.db.conn
        self.conn.row_factory = sqlite3.Row
        self.ensure_schema()

    def ensure_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fetched_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS story_snapshots (
                snapshot_id INTEGER NOT NULL,
                rank INTEGER NOT NULL,
                id INTEGER NOT NULL,
                title TEXT NOT NULL,
                url TEXT,
                score INTEGER,
                by TEXT,
                time INTEGER,
                descendants INTEGER,
                type TEXT,
                fetched_at TEXT NOT NULL,
                PRIMARY KEY (snapshot_id, id),
                FOREIGN KEY (snapshot_id) REFERENCES snapshots(id)
            );
            CREATE TABLE IF NOT EXISTS story_search (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS story_search_fts
            USING fts5(title, content='story_search', content_rowid='id');
            """
        )
        self.conn.commit()

    def create_snapshot(self, stories: list[dict[str, Any]], fetched_at: str | None = None) -> Snapshot:
        timestamp = fetched_at or now_iso()
        cursor = self.conn.execute("INSERT INTO snapshots (fetched_at) VALUES (?)", (timestamp,))
        snapshot_id = int(cursor.lastrowid)
        rows = [
            (
                snapshot_id,
                story["rank"],
                story["id"],
                story.get("title") or "(untitled)",
                story.get("url"),
                story.get("score"),
                story.get("by"),
                story.get("time"),
                story.get("descendants"),
                story.get("type"),
                timestamp,
            )
            for story in stories
        ]
        self.conn.executemany(
            """
            INSERT INTO story_snapshots
            (snapshot_id, rank, id, title, url, score, by, time, descendants, type, fetched_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        for story in stories:
            title = story.get("title") or "(untitled)"
            self.conn.execute(
                """
                INSERT INTO story_search (id, title) VALUES (?, ?)
                ON CONFLICT(id) DO UPDATE SET title = excluded.title
                """,
                (story["id"], title),
            )
            self.conn.execute("INSERT OR REPLACE INTO story_search_fts(rowid, title) VALUES (?, ?)", (story["id"], title))
        self.conn.commit()
        return Snapshot(snapshot_id, timestamp)

    def snapshots(self) -> list[Snapshot]:
        rows = self.conn.execute("SELECT id, fetched_at FROM snapshots ORDER BY id").fetchall()
        return [Snapshot(id=row["id"], fetched_at=row["fetched_at"]) for row in rows]

    def latest_snapshot(self) -> Snapshot | None:
        row = self.conn.execute("SELECT id, fetched_at FROM snapshots ORDER BY id DESC LIMIT 1").fetchone()
        return Snapshot(id=row["id"], fetched_at=row["fetched_at"]) if row else None

    def snapshot_by_selector(self, selector: str | int | None) -> Snapshot | None:
        if selector is None or str(selector).upper() == "LATEST":
            return self.latest_snapshot()
        row = self.conn.execute("SELECT id, fetched_at FROM snapshots WHERE id = ?", (int(selector),)).fetchone()
        return Snapshot(id=row["id"], fetched_at=row["fetched_at"]) if row else None

    def stories_for_snapshot(self, snapshot_id: int) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT rank, id, title, url, score, by, time, descendants, type, fetched_at
            FROM story_snapshots
            WHERE snapshot_id = ?
            ORDER BY rank
            """,
            (snapshot_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def two_most_recent_snapshot_ids(self) -> tuple[int, int] | None:
        rows = self.conn.execute("SELECT id FROM snapshots ORDER BY id DESC LIMIT 2").fetchall()
        if len(rows) < 2:
            return None
        return int(rows[1]["id"]), int(rows[0]["id"])

    def diff(self, from_snapshot: int, to_snapshot: int) -> dict[str, list[dict[str, Any]]]:
        old = {story["id"]: story for story in self.stories_for_snapshot(from_snapshot)}
        new = {story["id"]: story for story in self.stories_for_snapshot(to_snapshot)}
        entered = [new[story_id] for story_id in new.keys() - old.keys()]
        left = [old[story_id] for story_id in old.keys() - new.keys()]
        changed = []
        for story_id in old.keys() & new.keys():
            old_rank = old[story_id]["rank"]
            new_rank = new[story_id]["rank"]
            if old_rank != new_rank:
                changed.append(
                    {
                        "id": story_id,
                        "title": new[story_id]["title"],
                        "from_rank": old_rank,
                        "to_rank": new_rank,
                        "delta": old_rank - new_rank,
                    }
                )
        return {
            "entered": sorted(entered, key=lambda item: item["rank"]),
            "left": sorted(left, key=lambda item: item["rank"]),
            "rank_changed": sorted(changed, key=lambda item: item["to_rank"]),
        }

    def search(self, query: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT story_search.id, story_search.title
            FROM story_search_fts
            JOIN story_search ON story_search_fts.rowid = story_search.id
            WHERE story_search_fts MATCH ?
            ORDER BY bm25(story_search_fts)
            """,
            (query,),
        ).fetchall()
        return [dict(row) for row in rows]

    def stats(self) -> dict[str, Any]:
        snapshot_count = self.conn.execute("SELECT COUNT(*) AS count FROM snapshots").fetchone()["count"]
        unique_count = self.conn.execute("SELECT COUNT(DISTINCT id) AS count FROM story_snapshots").fetchone()["count"]
        author_rows = self.conn.execute(
            """
            SELECT by, COUNT(*) AS count
            FROM story_snapshots
            WHERE by IS NOT NULL
            GROUP BY by
            ORDER BY count DESC, by ASC
            LIMIT 5
            """
        ).fetchall()
        bounds = self.conn.execute("SELECT MIN(fetched_at) AS oldest, MAX(fetched_at) AS newest FROM story_snapshots").fetchone()
        return {
            "snapshots": snapshot_count,
            "unique_stories": unique_count,
            "top_authors": [(row["by"], row["count"]) for row in author_rows],
            "oldest_fetched_at": bounds["oldest"],
            "newest_fetched_at": bounds["newest"],
        }

    def export_latest(self, fmt: Literal["json", "csv", "markdown"]) -> str:
        snapshot = self.latest_snapshot()
        stories = self.stories_for_snapshot(snapshot.id) if snapshot else []
        if fmt == "json":
            return json.dumps(stories, indent=2)
        if fmt == "csv":
            output = io.StringIO()
            fieldnames = ["rank", "id", "title", "url", "score", "by", "time", "descendants", "type", "fetched_at"]
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(stories)
            return output.getvalue()
        if fmt == "markdown":
            header = "| Rank | ID | Title | Score | By | URL |"
            divider = "| ---: | ---: | --- | ---: | --- | --- |"
            rows = [header, divider]
            for story in stories:
                rows.append(
                    f"| {story['rank']} | {story['id']} | {escape_md(story['title'])} | "
                    f"{story.get('score') or 0} | {escape_md(story.get('by') or '')} | {escape_md(story.get('url') or '')} |"
                )
            return "\n".join(rows)
        raise ValueError(f"Unsupported format: {fmt}")


def escape_md(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")
