# hn-tracker

Small Python CLI for tracking Hacker News top stories in a local SQLite database.

## Install

```bash
uv sync
```

## Commands

Fetch the current top 10 stories from the Hacker News Firebase API into `./hn.db`:

```bash
uv run hn-tracker fetch
```

Print the most recent stored snapshot:

```bash
uv run hn-tracker list
```

Compare the two most recent snapshots:

```bash
uv run hn-tracker diff
```

Tests:

```bash
uv run pytest -q
```
