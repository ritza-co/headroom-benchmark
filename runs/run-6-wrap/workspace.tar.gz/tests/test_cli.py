from __future__ import annotations

from typer.testing import CliRunner

from hn_tracker import app
from sqlite_utils import Database

runner = CliRunner()


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return self

    def json(self):
        return self.payload


class FakeClient:
    def __init__(self, *args, **kwargs):
        self.items = {
            story_id: {
                "id": story_id,
                "title": f"Story {story_id}",
                "url": f"https://example.com/{story_id}",
                "score": 100 - index,
                "by": f"user{index}",
                "time": 1_700_000_000 + index,
            }
            for index, story_id in enumerate(range(101, 111), start=1)
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def get(self, path):
        if path == "/topstories.json":
            return FakeResponse(list(range(101, 111)))
        story_id = int(path.removeprefix("/item/").removesuffix(".json"))
        return FakeResponse(self.items[story_id])


def seed(rows):
    db = Database("hn.db")
    db["stories"].insert_all(rows, pk=("fetched_at", "id"), replace=True)


def story(fetched_at, rank, story_id, title):
    return {
        "fetched_at": fetched_at,
        "rank": rank,
        "id": story_id,
        "title": title,
        "url": f"https://example.com/{story_id}",
        "score": 100 - rank,
        "by": "alice",
        "time": 1_700_000_000,
    }


def test_fetch_stores_mocked_top_ten(mocker, tmp_path, monkeypatch):
    mocker.patch("hn_tracker.httpx.Client", FakeClient)
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app, ["fetch"])

    assert result.exit_code == 0
    assert "Stored 10 stories" in result.output
    rows = list(Database("hn.db").query("select * from stories order by rank"))
    assert len(rows) == 10
    assert rows[0]["id"] == 101
    assert rows[0]["rank"] == 1
    assert rows[0]["title"] == "Story 101"


def test_list_prints_most_recent_seeded_snapshot(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    seed(
        [
            story("2026-06-04T10:00:00+00:00", 1, 1, "Old top"),
            story("2026-06-04T11:00:00+00:00", 1, 2, "New top"),
            story("2026-06-04T11:00:00+00:00", 2, 3, "New second"),
        ]
    )

    result = runner.invoke(app, ["list"])

    assert result.exit_code == 0
    assert "Snapshot: 2026-06-04T11:00:00+00:00" in result.output
    assert "New top" in result.output
    assert "New second" in result.output
    assert "Old top" not in result.output


def test_diff_prints_entered_left_and_rank_changed(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    seed(
        [
            story("2026-06-04T10:00:00+00:00", 1, 1, "Moved down"),
            story("2026-06-04T10:00:00+00:00", 2, 2, "Moved up"),
            story("2026-06-04T10:00:00+00:00", 3, 3, "Left story"),
            story("2026-06-04T11:00:00+00:00", 1, 2, "Moved up"),
            story("2026-06-04T11:00:00+00:00", 2, 1, "Moved down"),
            story("2026-06-04T11:00:00+00:00", 3, 4, "Entered story"),
        ]
    )

    result = runner.invoke(app, ["diff"])

    assert result.exit_code == 0
    assert "+ #3 Entered story (4)" in result.output
    assert "- was #3 Left story (3)" in result.output
    assert "Moved up (2): now #1 (up 1)" in result.output
    assert "Moved down (1): now #2 (down 1)" in result.output
