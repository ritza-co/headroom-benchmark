from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import typer
from sqlite_utils import Database

HN_API = "https://hacker-news.firebaseio.com/v0"
DB_PATH = Path("hn.db")

app = typer.Typer(no_args_is_help=True)


def _db() -> Database:
    return Database(DB_PATH)


def _ensure_schema(db: Database) -> None:
    table = db["stories"]
    if not table.exists():
        table.create(
            {
                "fetched_at": str,
                "rank": int,
                "id": int,
                "title": str,
                "url": str,
                "score": int,
                "by": str,
                "time": int,
            },
            pk=("fetched_at", "id"),
        )


def _latest_snapshots(db: Database, limit: int = 2) -> list[str]:
    return [
        row["fetched_at"]
        for row in db.query(
            "select distinct fetched_at from stories order by fetched_at desc limit ?",
            [limit],
        )
    ]


def _snapshot(db: Database, fetched_at: str) -> list[dict[str, Any]]:
    return list(
        db.query(
            """
            select rank, id, title, url, score, "by", time, fetched_at
            from stories
            where fetched_at = ?
            order by rank asc
            """,
            [fetched_at],
        )
    )


def _print_table(rows: list[dict[str, Any]]) -> None:
    headers = ["Rank", "ID", "Score", "By", "Title", "URL"]
    body = [
        [
            str(row["rank"]),
            str(row["id"]),
            str(row["score"]),
            row["by"] or "",
            row["title"] or "",
            row["url"] or "",
        ]
        for row in rows
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in body))
        for index in range(len(headers))
    ]
    typer.echo("  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)))
    typer.echo("  ".join("-" * width for width in widths))
    for row in body:
        typer.echo("  ".join(value.ljust(widths[index]) for index, value in enumerate(row)))


def _fetch_top_stories() -> list[dict[str, Any]]:
    with httpx.Client(base_url=HN_API, timeout=15.0) as client:
        top_ids = client.get("/topstories.json").raise_for_status().json()[:10]
        stories = []
        for rank, story_id in enumerate(top_ids, start=1):
            item = client.get(f"/item/{story_id}.json").raise_for_status().json()
            stories.append(
                {
                    "rank": rank,
                    "id": item["id"],
                    "title": item.get("title", ""),
                    "url": item.get("url"),
                    "score": item.get("score", 0),
                    "by": item.get("by", ""),
                    "time": item.get("time", 0),
                }
            )
        return stories


@app.command()
def fetch() -> None:
    """Fetch and store the current top 10 Hacker News stories."""
    db = _db()
    _ensure_schema(db)
    fetched_at = datetime.now(UTC).isoformat(timespec="seconds")
    rows = [{**story, "fetched_at": fetched_at} for story in _fetch_top_stories()]
    db["stories"].insert_all(rows, pk=("fetched_at", "id"), replace=True)
    typer.echo(f"Stored {len(rows)} stories fetched at {fetched_at}")


@app.command("list")
def list_stories() -> None:
    """Print the most recent stored top 10 snapshot."""
    db = _db()
    if "stories" not in db.table_names():
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        raise typer.Exit(code=1)
    snapshots = _latest_snapshots(db, 1)
    if not snapshots:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        raise typer.Exit(code=1)
    typer.echo(f"Snapshot: {snapshots[0]}")
    _print_table(_snapshot(db, snapshots[0]))


@app.command()
def diff() -> None:
    """Compare the two most recent top 10 snapshots."""
    db = _db()
    if "stories" not in db.table_names():
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(code=1)
    snapshots = _latest_snapshots(db, 2)
    if len(snapshots) < 2:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(code=1)

    latest, previous = snapshots[0], snapshots[1]
    latest_by_id = {row["id"]: row for row in _snapshot(db, latest)}
    previous_by_id = {row["id"]: row for row in _snapshot(db, previous)}

    entered = [row for story_id, row in latest_by_id.items() if story_id not in previous_by_id]
    left = [row for story_id, row in previous_by_id.items() if story_id not in latest_by_id]
    changed = [
        (latest_by_id[story_id], previous_by_id[story_id]["rank"] - latest_by_id[story_id]["rank"])
        for story_id in latest_by_id.keys() & previous_by_id.keys()
        if latest_by_id[story_id]["rank"] != previous_by_id[story_id]["rank"]
    ]

    typer.echo(f"Previous: {previous}")
    typer.echo(f"Latest:   {latest}")
    typer.echo()
    typer.echo("Entered:")
    for row in entered:
        typer.echo(f"  + #{row['rank']} {row['title']} ({row['id']})")
    if not entered:
        typer.echo("  none")

    typer.echo("Left:")
    for row in left:
        typer.echo(f"  - was #{row['rank']} {row['title']} ({row['id']})")
    if not left:
        typer.echo("  none")

    typer.echo("Rank changed:")
    for row, delta in changed:
        direction = "up" if delta > 0 else "down"
        typer.echo(f"  * {row['title']} ({row['id']}): now #{row['rank']} ({direction} {abs(delta)})")
    if not changed:
        typer.echo("  none")


def main() -> None:
    app()
