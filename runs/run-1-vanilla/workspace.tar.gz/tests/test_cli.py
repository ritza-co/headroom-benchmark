from __future__ import annotations

from pathlib import Path

import sqlite_utils
from typer.testing import CliRunner

import hn_tracker


runner = CliRunner()


def story(story_id: int, rank: int, title: str) -> dict[str, object]:
    return {
        "rank": rank,
        "id": story_id,
        "title": title,
        "url": f"https://example.com/{story_id}",
        "score": 100 - rank,
        "by": "alice",
        "time": 1_700_000_000 + story_id,
    }


def seed(db_path: Path, fetched_at: str, stories: list[dict[str, object]]) -> None:
    rows = [{**row, "fetched_at": fetched_at} for row in stories]
    sqlite_utils.Database(db_path)["stories"].insert_all(rows, alter=True)


def test_fetch_stores_mocked_top_stories(tmp_path: Path, mocker) -> None:
    db_path = tmp_path / "hn.db"
    stories = [story(story_id, rank, f"Story {story_id}") for rank, story_id in enumerate(range(1, 11), start=1)]
    mocker.patch("hn_tracker.fetch_top_stories", return_value=stories)
    mocker.patch("hn_tracker.utc_now", return_value="2026-06-04T12:00:00+00:00")

    result = runner.invoke(hn_tracker.app, ["fetch", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Stored 10 stories" in result.output
    rows = list(sqlite_utils.Database(db_path).query("select * from stories order by rank"))
    assert len(rows) == 10
    assert rows[0]["id"] == 1
    assert rows[0]["title"] == "Story 1"
    assert rows[0]["fetched_at"] == "2026-06-04T12:00:00+00:00"


def test_list_prints_most_recent_snapshot(tmp_path: Path) -> None:
    db_path = tmp_path / "hn.db"
    seed(db_path, "2026-06-04T11:00:00+00:00", [story(1, 1, "Old top story")])
    seed(db_path, "2026-06-04T12:00:00+00:00", [story(2, 1, "New top story"), story(3, 2, "Second story")])

    result = runner.invoke(hn_tracker.app, ["list", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Snapshot: 2026-06-04T12:00:00+00:00" in result.output
    assert "New top story" in result.output
    assert "Second story" in result.output
    assert "Old top story" not in result.output


def test_diff_prints_entered_left_and_rank_changed(tmp_path: Path) -> None:
    db_path = tmp_path / "hn.db"
    seed(
        db_path,
        "2026-06-04T11:00:00+00:00",
        [
            story(1, 1, "Moved down"),
            story(2, 2, "Left story"),
            story(3, 3, "Moved up"),
        ],
    )
    seed(
        db_path,
        "2026-06-04T12:00:00+00:00",
        [
            story(3, 1, "Moved up"),
            story(1, 2, "Moved down"),
            story(4, 3, "Entered story"),
        ],
    )

    result = runner.invoke(hn_tracker.app, ["diff", "--db", str(db_path)])

    assert result.exit_code == 0
    assert "Entered:" in result.output
    assert "Entered story (4)" in result.output
    assert "Left:" in result.output
    assert "Left story (2)" in result.output
    assert "Rank changed:" in result.output
    assert "Moved up (3): #3 -> #1 (+2)" in result.output
    assert "Moved down (1): #1 -> #2 (-1)" in result.output
