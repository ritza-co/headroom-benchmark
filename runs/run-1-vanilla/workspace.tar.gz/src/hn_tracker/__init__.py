from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import sqlite_utils
import typer

app = typer.Typer(help="Track Hacker News top 10 story snapshots.")

DEFAULT_DB = Path("hn.db")
HN_BASE_URL = "https://hacker-news.firebaseio.com/v0"


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def database(path: Path) -> sqlite_utils.Database:
    return sqlite_utils.Database(path)


def fetch_top_stories() -> list[dict[str, Any]]:
    with httpx.Client(base_url=HN_BASE_URL, timeout=10.0) as client:
        response = client.get("/topstories.json")
        response.raise_for_status()
        story_ids = response.json()[:10]

        stories = []
        for rank, story_id in enumerate(story_ids, start=1):
            item_response = client.get(f"/item/{story_id}.json")
            item_response.raise_for_status()
            item = item_response.json()
            stories.append(
                {
                    "rank": rank,
                    "id": item["id"],
                    "title": item.get("title", ""),
                    "url": item.get("url"),
                    "score": item.get("score", 0),
                    "by": item.get("by", ""),
                    "time": item.get("time", 0),
                }
            )
    return stories


def store_snapshot(db_path: Path, stories: list[dict[str, Any]], fetched_at: str | None = None) -> str:
    fetched_at = fetched_at or utc_now()
    rows = [{**story, "fetched_at": fetched_at} for story in stories]
    if not rows:
        return fetched_at

    db = database(db_path)
    db["stories"].insert_all(rows, alter=True)
    db["stories"].create_index(["fetched_at"], if_not_exists=True)
    db["stories"].create_index(["id"], if_not_exists=True)
    return fetched_at


def snapshot_times(db_path: Path) -> list[str]:
    db = database(db_path)
    if "stories" not in db.table_names():
        return []
    return [
        row["fetched_at"]
        for row in db.query(
            "select distinct fetched_at from stories order by fetched_at desc"
        )
    ]


def load_snapshot(db_path: Path, fetched_at: str) -> list[dict[str, Any]]:
    db = database(db_path)
    return list(
        db.query(
            """
            select rank, id, title, url, score, by, time, fetched_at
            from stories
            where fetched_at = ?
            order by rank
            """,
            [fetched_at],
        )
    )


def print_table(rows: list[dict[str, Any]]) -> None:
    if not rows:
        typer.echo("No stories found.")
        return

    headers = ["Rank", "ID", "Score", "By", "Title"]
    table_rows = [
        [str(row["rank"]), str(row["id"]), str(row["score"]), row["by"], row["title"]]
        for row in rows
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in table_rows))
        for index in range(len(headers))
    ]

    typer.echo("  ".join(header.ljust(widths[index]) for index, header in enumerate(headers)))
    typer.echo("  ".join("-" * width for width in widths))
    for row in table_rows:
        typer.echo("  ".join(value.ljust(widths[index]) for index, value in enumerate(row)))


@app.command()
def fetch(
    db_path: Path = typer.Option(DEFAULT_DB, "--db", help="SQLite database path."),
) -> None:
    """Fetch and store the current Hacker News top 10."""
    stories = fetch_top_stories()
    fetched_at = store_snapshot(db_path, stories)
    typer.echo(f"Stored {len(stories)} stories fetched at {fetched_at}.")


@app.command("list")
def list_command(
    db_path: Path = typer.Option(DEFAULT_DB, "--db", help="SQLite database path."),
) -> None:
    """Print the most recent top 10 snapshot."""
    times = snapshot_times(db_path)
    if not times:
        typer.echo("No snapshots found. Run `hn-tracker fetch` first.")
        raise typer.Exit(1)

    typer.echo(f"Snapshot: {times[0]}")
    print_table(load_snapshot(db_path, times[0]))


@app.command()
def diff(
    db_path: Path = typer.Option(DEFAULT_DB, "--db", help="SQLite database path."),
) -> None:
    """Compare the two most recent top 10 snapshots."""
    times = snapshot_times(db_path)
    if len(times) < 2:
        typer.echo("Need at least two snapshots. Run `hn-tracker fetch` twice.")
        raise typer.Exit(1)

    current = load_snapshot(db_path, times[0])
    previous = load_snapshot(db_path, times[1])
    current_by_id = {row["id"]: row for row in current}
    previous_by_id = {row["id"]: row for row in previous}

    entered = [row for row in current if row["id"] not in previous_by_id]
    left = [row for row in previous if row["id"] not in current_by_id]
    changed = []
    for story_id, current_row in current_by_id.items():
        previous_row = previous_by_id.get(story_id)
        if previous_row and previous_row["rank"] != current_row["rank"]:
            changed.append((current_row, previous_row["rank"] - current_row["rank"]))

    typer.echo(f"Current: {times[0]}")
    typer.echo(f"Previous: {times[1]}")
    typer.echo("")
    typer.echo("Entered:")
    for row in entered:
        typer.echo(f"  #{row['rank']} {row['title']} ({row['id']})")
    if not entered:
        typer.echo("  None")

    typer.echo("Left:")
    for row in left:
        typer.echo(f"  #{row['rank']} {row['title']} ({row['id']})")
    if not left:
        typer.echo("  None")

    typer.echo("Rank changed:")
    for row, delta in sorted(changed, key=lambda item: item[0]["rank"]):
        sign = "+" if delta > 0 else ""
        typer.echo(f"  {row['title']} ({row['id']}): #{previous_by_id[row['id']]['rank']} -> #{row['rank']} ({sign}{delta})")
    if not changed:
        typer.echo("  None")


def main() -> None:
    app()
