# hn-tracker

Small CLI for saving Hacker News top 10 snapshots to `./hn.db`.

## Install

Install dependencies with uv:

```bash
uv sync
```

Run commands through uv:

```bash
uv run hn-tracker fetch
uv run hn-tracker list
uv run hn-tracker diff
```

## Commands

`hn-tracker fetch` fetches the current top 10 stories from the Hacker News Firebase API and stores a timestamped snapshot in SQLite.

`hn-tracker list` prints the most recent stored snapshot as a table.

`hn-tracker diff` compares the two most recent snapshots, showing stories that entered, stories that left, and stories whose rank changed.
