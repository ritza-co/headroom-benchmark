# hn-tracker

`hn-tracker` is a Python CLI for tracking Hacker News top stories over time.

It fetches the current HN top-story list, stores every snapshot in SQLite, and
lets you list, diff, search, inspect, export, and watch those snapshots.

The database lives at `./hn.db` in the directory where you run the command.

## Highlights

- Concurrent HTTP fetching with `httpx`.
- Local SQLite history with one row per story per snapshot.
- SQLite FTS5 search over saved story titles.
- Rich terminal tables for human-readable output.
- JSON, CSV, and Markdown export for scripting.
- Structured INFO logs to stderr with `structlog`.
- Tests for every CLI command.
- Dockerfile and GitHub Actions workflow included.

## Requirements

- Python 3.12 or newer.
- `uv` for dependency management and command execution.
- Network access for live Hacker News API calls.
- SQLite with FTS5 support.

## Install

Clone the repository and install dependencies:

```bash
uv sync
```

Run the CLI through `uv`:

```bash
uv run hn-tracker --help
```

Install the package into the current uv environment:

```bash
uv run hn-tracker fetch --limit 30
```

## Command Overview

There are eight subcommands:

```text
fetch
list
diff
story
search
stats
export
watch
```

Each command reads from or writes to `./hn.db`.

## fetch

Fetch the current top N stories from Hacker News.

```bash
uv run hn-tracker fetch --limit 30
```

Example output:

```text
Fetched 30 stories into snapshot 1 at 2026-06-04T15:20:00+00:00
```

The default limit is 30.

The command first reads `topstories.json`, then fetches item metadata
concurrently.

Rows include `id`, `title`, `url`, `score`, `by`, `time`, `descendants`,
`type`, and `fetched_at`.

## list

Show a saved snapshot as a Rich table.

```bash
uv run hn-tracker list
```

Example output:

```text
                  Snapshot 1
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━┳━━━━━━━┳━━━━━━━┳━━━━━━━━━━┓
┃ Rank ┃       ID ┃ Title            ┃ Score ┃ By    ┃ Comments ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━╇━━━━━━━╇━━━━━━━╇━━━━━━━━━━┩
│    1 │ 12345678 │ Example story    │   500 │ alice │      120 │
└──────┴──────────┴──────────────────┴───────┴───────┴──────────┘
```

Choose a specific snapshot:

```bash
uv run hn-tracker list --snapshot 3
```

Use the latest snapshot explicitly:

```bash
uv run hn-tracker list --snapshot LATEST
```

## diff

Compare two snapshots.

```bash
uv run hn-tracker diff
```

With no options, the command compares the two most recent snapshots.

Choose snapshots manually:

```bash
uv run hn-tracker diff --from 1 --to 2
```

Example output:

```text
Diff snapshot 1 -> 2
Entered: stories now present
Left: stories no longer present
Rank Changed: stories with a new rank and signed delta
```

A positive rank delta means the story moved up.

A negative rank delta means the story moved down.

## story

Fetch one live story and its first five top-level comments.

```bash
uv run hn-tracker story 12345678
```

Example output:

```text
Story 12345678
title    Example story
url      https://example.com
score    500
by       alice
```

Comments are fetched from the HN item API and displayed as Rich panels.

Deleted and dead comments are skipped.

## search

Search saved story titles with SQLite FTS5.

```bash
uv run hn-tracker search rust
```

Example output:

```text
                  Search: rust
┏━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━┳━━━━━━━┳━━━━━━━━━━┓
┃ Rank ┃       ID ┃ Title                ┃ Score ┃ By    ┃ Comments ┃
┡━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━╇━━━━━━━╇━━━━━━━━━━┩
│    4 │ 12345678 │ Rust async patterns  │   300 │ alice │       80 │
└──────┴──────────┴──────────────────────┴───────┴───────┴──────────┘
```

Search covers all saved snapshots, not just the latest one.

Results are ordered newest snapshot first, then rank.

## stats

Print database statistics.

```bash
uv run hn-tracker stats
```

Example output:

```text
HN Tracker Stats
snapshots          4
unique_stories     91
oldest_fetched_at  2026-06-04T10:00:00+00:00
newest_fetched_at  2026-06-04T13:00:00+00:00
top_authors        alice (5), bob (3)
```

The author list counts story rows across snapshots.

That means an author can be counted multiple times if their stories remain in
multiple snapshots.

## export

Export the latest snapshot to stdout.

Supported formats are `json`, `csv`, and `markdown`.

```bash
uv run hn-tracker export json
```

```bash
uv run hn-tracker export csv
```

```bash
uv run hn-tracker export markdown
```

Example JSON output:

```json
[
  {
    "snapshot_id": 1,
    "rank": 1,
    "id": 12345678,
    "title": "Example story"
  }
]
```

Example CSV output:

```csv
rowid,snapshot_id,rank,id,title,url,score,by,time,descendants,type,fetched_at
1,1,1,12345678,Example story,https://example.com,500,alice,1700000000,120,story,2026-06-04T15:20:00+00:00
```

Example Markdown output:

```markdown
| rank | id | title | score | by | url |
| --- | --- | --- | --- | --- | --- |
| 1 | 12345678 | Example story | 500 | alice | https://example.com |
```

## watch

Fetch repeatedly until Ctrl-C.

```bash
uv run hn-tracker watch --interval 60
```

Example output:

```text
snapshot=2 fetched=30 at=2026-06-04T15:21:00+00:00 entered=3 left=3 rank_changed=20
```

The first watch iteration fetches immediately.

Subsequent iterations sleep for the configured interval.

The default interval is 60 seconds.

## Architecture

The package is split into small modules.

`hn_tracker.api` contains the Hacker News Firebase API client.

`hn_tracker.db` contains schema creation, snapshot inserts, diffs, search, and
stats queries.

`hn_tracker.render` contains Rich table construction and export format helpers.

`hn_tracker.cli` wires the Typer commands to the API, database, and render
modules.

The SQLite schema has a `snapshots` table and a `story_snapshots` table.

The `story_snapshots` table stores one row per story per fetch.

The FTS5 table indexes saved titles and references `story_snapshots.rowid`.

Snapshot diffs are computed by comparing story IDs between two snapshots.

Rank deltas use `old_rank - new_rank`, so positive numbers mean upward movement.

## Development

Install dependencies:

```bash
uv sync
```

Run tests:

```bash
uv run pytest -v
```

Run the CLI smoke test:

```bash
uv run hn-tracker --help
```

Run a live fetch:

```bash
uv run hn-tracker fetch --limit 30
```

Inspect the database with sqlite-utils:

```bash
uv run sqlite-utils tables hn.db
```

Query snapshots:

```bash
uv run sqlite-utils rows hn.db snapshots
```

Query latest story rows:

```bash
uv run sqlite-utils hn.db "select rank, title from story_snapshots order by snapshot_id desc, rank limit 10"
```

## Testing Notes

Tests use temporary working directories so each test gets a clean `hn.db`.

The fetch command test mocks the API layer.

The concurrency test mocks `httpx.AsyncClient` and asserts multiple item
requests are in flight.

The export tests parse JSON and CSV output instead of checking only text.

The search test checks FTS5 results across multiple snapshots.

The diff test checks entered, left, and rank-changed stories.

## Docker

Build the image:

```bash
docker build -t hn-tracker .
```

Run a command:

```bash
docker run --rm -v "$PWD:/data" -w /data hn-tracker fetch --limit 30
```

The container entrypoint is `hn-tracker`.

Mount a host directory if you want to keep `hn.db`.

## CI

The GitHub Actions workflow installs `uv`, installs Python 3.12, syncs locked
dependencies, runs `pytest -v`, and runs `hn-tracker --help`.

The workflow file is `.github/workflows/ci.yml`.

## Data Source

`hn-tracker` uses the public Hacker News Firebase API.

Top stories come from:

```text
https://hacker-news.firebaseio.com/v0/topstories.json
```

Items come from:

```text
https://hacker-news.firebaseio.com/v0/item/<id>.json
```

## Roadmap

- Add configurable database path.
- Add snapshot pruning.
- Add author-specific filters.
- Add score-change tracking.
- Add comment-count-change tracking.
- Add terminal sparklines for rank movement.
- Add scheduled export recipes.
- Add richer Markdown reports.
- Add shell completion documentation.
- Add packaging release automation.
