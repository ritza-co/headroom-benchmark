from __future__ import annotations

import asyncio

import pytest

from hn_tracker import api


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


@pytest.mark.asyncio
async def test_fetch_top_stories_uses_concurrent_item_requests(monkeypatch):
    state = {"in_flight": 0, "max_in_flight": 0}

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return None

        async def get(self, url):
            if url.endswith("/topstories.json"):
                return FakeResponse([1, 2, 3, 4])

            state["in_flight"] += 1
            state["max_in_flight"] = max(state["max_in_flight"], state["in_flight"])
            await asyncio.sleep(0.01)
            item_id = int(url.rsplit("/", 1)[-1].split(".")[0])
            state["in_flight"] -= 1
            return FakeResponse(
                {
                    "id": item_id,
                    "title": f"Story {item_id}",
                    "type": "story",
                }
            )

    monkeypatch.setattr(api.httpx, "AsyncClient", FakeAsyncClient)

    stories = await api.fetch_top_stories(4)

    assert [story["id"] for story in stories] == [1, 2, 3, 4]
    assert state["max_in_flight"] > 1
