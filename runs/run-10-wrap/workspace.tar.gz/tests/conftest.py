from __future__ import annotations

import pytest
from typer.testing import CliRunner


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture(autouse=True)
def isolated_cwd(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)


def story_item(item_id: int, title: str, rank_score: int = 100, by: str = "alice") -> dict:
    return {
        "id": item_id,
        "title": title,
        "url": f"https://example.com/{item_id}",
        "score": rank_score,
        "by": by,
        "time": 1_700_000_000 + item_id,
        "descendants": item_id % 10,
        "type": "story",
    }
