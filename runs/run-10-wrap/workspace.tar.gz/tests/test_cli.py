from __future__ import annotations

import csv
import io
import json

from hn_tracker import api, db
from hn_tracker.cli import app


def story_item(item_id: int, title: str, rank_score: int = 100, by: str = "alice") -> dict:
    return {
        "id": item_id,
        "title": title,
        "url": f"https://example.com/{item_id}",
        "score": rank_score,
        "by": by,
        "time": 1_700_000_000 + item_id,
        "descendants": item_id % 10,
        "type": "story",
    }


def test_fetch_command_stores_snapshot(runner, mocker):
    async def fake_fetch(limit):
        return [story_item(1, "Python release", 10), story_item(2, "Rust news", 9)][:limit]

    mocker.patch.object(api, "fetch_top_stories", side_effect=fake_fetch)
    result = runner.invoke(app, ["fetch", "--limit", "2"])

    assert result.exit_code == 0
    assert "Fetched 2 stories into snapshot 1" in result.output
    assert len(db.get_snapshot(1)) == 2


def test_list_command_prints_latest_snapshot(runner):
    db.create_snapshot([story_item(1, "First story"), story_item(2, "Second story")])

    result = runner.invoke(app, ["list"])

    assert result.exit_code == 0
    assert "Snapshot 1" in result.output
    assert "First story" in result.output


def test_diff_command_identifies_entered_left_and_rank_changed(runner):
    db.create_snapshot([story_item(1, "One"), story_item(2, "Two"), story_item(3, "Three")])
    db.create_snapshot([story_item(2, "Two"), story_item(4, "Four"), story_item(1, "One")])

    changes = db.diff_snapshots(1, 2)
    result = runner.invoke(app, ["diff", "--from", "1", "--to", "2"])

    assert result.exit_code == 0
    assert [row["id"] for row in changes["entered"]] == [4]
    assert [row["id"] for row in changes["left"]] == [3]
    assert {row["id"]: row["delta"] for row in changes["changed"]} == {1: -2, 2: 1}
    assert "Four" in result.output
    assert "Three" in result.output
    assert "Rank Changed" in result.output


def test_story_command_prints_metadata_and_comments(runner, mocker):
    async def fake_story_with_comments(item_id):
        return (
            {"id": item_id, "title": "Story title", "url": "https://example.com", "score": 5, "by": "alice", "time": 1, "descendants": 2, "type": "story"},
            [{"id": 10, "by": "bob", "text": "Nice post"}, {"id": 11, "by": "carol", "text": "Thanks"}],
        )

    mocker.patch.object(api, "fetch_story_with_comments", side_effect=fake_story_with_comments)
    result = runner.invoke(app, ["story", "123"])

    assert result.exit_code == 0
    assert "Story title" in result.output
    assert "Nice post" in result.output


def test_search_command_returns_matching_titles_across_multiple_snapshots(runner):
    db.create_snapshot([story_item(1, "Rust async patterns"), story_item(2, "Python packaging")])
    db.create_snapshot([story_item(3, "Rust for databases"), story_item(4, "SQLite tips")])

    rows = db.search_titles("Rust")
    result = runner.invoke(app, ["search", "Rust"])

    assert result.exit_code == 0
    assert [row["id"] for row in rows] == [3, 1]
    assert "Rust async patterns" in result.output
    assert "Rust for databases" in result.output


def test_stats_command_prints_database_stats(runner):
    db.create_snapshot([story_item(1, "One", by="alice"), story_item(2, "Two", by="bob")])
    db.create_snapshot([story_item(1, "One", by="alice"), story_item(3, "Three", by="alice")])

    result = runner.invoke(app, ["stats"])

    assert result.exit_code == 0
    assert "snapshots" in result.output
    assert "unique_stories" in result.output
    assert "alice (3)" in result.output


def test_export_json_and_csv_are_valid(runner):
    db.create_snapshot([story_item(1, "One"), story_item(2, "Two")])

    json_result = runner.invoke(app, ["export", "json"])
    csv_result = runner.invoke(app, ["export", "csv"])

    assert json_result.exit_code == 0
    assert json.loads(json_result.output)[0]["title"] == "One"
    assert csv_result.exit_code == 0
    parsed = list(csv.DictReader(io.StringIO(csv_result.output)))
    assert parsed[1]["title"] == "Two"


def test_export_markdown_command(runner):
    db.create_snapshot([story_item(1, "One")])

    result = runner.invoke(app, ["export", "markdown"])

    assert result.exit_code == 0
    assert "| rank | id | title | score | by | url |" in result.output
    assert "| 1 | 1 | One |" in result.output


def test_watch_command_fetches_until_keyboard_interrupt(runner, mocker):
    async def fake_fetch(limit):
        return [story_item(1, "Watch story")]

    def stop(_interval):
        raise KeyboardInterrupt

    mocker.patch.object(api, "fetch_top_stories", side_effect=fake_fetch)
    mocker.patch("hn_tracker.cli.time.sleep", side_effect=stop)

    result = runner.invoke(app, ["watch", "--interval", "1"])

    assert result.exit_code == 0
    assert "snapshot=1 fetched=1" in result.output
    assert "Stopped." in result.output
