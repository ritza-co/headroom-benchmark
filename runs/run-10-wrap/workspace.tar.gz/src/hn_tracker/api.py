from __future__ import annotations

import asyncio
from typing import Any

import httpx

BASE_URL = "https://hacker-news.firebaseio.com/v0"


async def fetch_top_stories(limit: int = 30) -> list[dict[str, Any]]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        top_response = await client.get(f"{BASE_URL}/topstories.json")
        top_response.raise_for_status()
        top_ids = top_response.json()
        ids = top_ids[: min(len(top_ids), max(limit * 2, limit + 10))]

        async def fetch_item(item_id: int) -> dict[str, Any]:
            response = await client.get(f"{BASE_URL}/item/{item_id}.json")
            response.raise_for_status()
            item = response.json()
            return item or {}

        items = await asyncio.gather(*(fetch_item(item_id) for item_id in ids))
        stories = [item for item in items if item and item.get("type") == "story" and item.get("title")]
        return stories[:limit]


async def fetch_item(item_id: int) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(f"{BASE_URL}/item/{item_id}.json")
        response.raise_for_status()
        return response.json() or {}


async def fetch_story_with_comments(item_id: int, comments_limit: int = 5) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    story = await fetch_item(item_id)
    kid_ids = story.get("kids") or []

    async with httpx.AsyncClient(timeout=20.0) as client:
        async def fetch_comment(comment_id: int) -> dict[str, Any]:
            response = await client.get(f"{BASE_URL}/item/{comment_id}.json")
            response.raise_for_status()
            return response.json() or {}

        comments = await asyncio.gather(*(fetch_comment(comment_id) for comment_id in kid_ids[:comments_limit]))

    return story, [comment for comment in comments if comment and not comment.get("deleted") and not comment.get("dead")]
