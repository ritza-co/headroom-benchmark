from __future__ import annotations

import csv
import io
import json
from typing import Any

from rich.console import Console
from rich.table import Table


def stories_table(rows: list[dict[str, Any]], title: str) -> Table:
    table = Table(title=title)
    table.add_column("Rank", justify="right")
    table.add_column("ID", justify="right")
    table.add_column("Title")
    table.add_column("Score", justify="right")
    table.add_column("By")
    table.add_column("Comments", justify="right")
    for row in rows:
        table.add_row(
            str(row.get("rank", "")),
            str(row.get("id", "")),
            row.get("title") or "",
            str(row.get("score") or 0),
            row.get("by") or "",
            str(row.get("descendants") or 0),
        )
    return table


def export_json(rows: list[dict[str, Any]]) -> str:
    return json.dumps(rows, indent=2, default=str)


def export_csv(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def export_markdown(rows: list[dict[str, Any]]) -> str:
    headers = ["rank", "id", "title", "score", "by", "url"]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        values = [str(row.get(header) or "").replace("|", "\\|") for header in headers]
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def print_kv(console: Console, title: str, values: dict[str, Any]) -> None:
    table = Table(title=title, show_header=False)
    table.add_column("Metric")
    table.add_column("Value")
    for key, value in values.items():
        table.add_row(key, str(value))
    console.print(table)
