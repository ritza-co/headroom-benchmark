from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from typing import Optional

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hn_tracker import api, db
from hn_tracker.render import export_csv, export_json, export_markdown, print_kv, stories_table

app = typer.Typer(help="Track Hacker News top stories over time.")
console = Console()


def configure_logging() -> None:
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.KeyValueRenderer(key_order=["timestamp", "level", "event"]),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(20),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


log = structlog.get_logger()


def run(coro):
    return asyncio.run(coro)


@app.callback()
def callback() -> None:
    configure_logging()


@app.command()
def fetch(limit: int = typer.Option(30, "--limit", min=1, help="Number of current top stories to fetch.")) -> None:
    """Fetch the current top stories into ./hn.db."""
    stories = run(api.fetch_top_stories(limit))
    snapshot_id, fetched_at, count = db.create_snapshot(stories)
    log.info("fetch_complete", snapshot_id=snapshot_id, count=count, fetched_at=fetched_at)
    console.print(f"Fetched {count} stories into snapshot {snapshot_id} at {fetched_at}")


@app.command("list")
def list_stories(snapshot: str = typer.Option("LATEST", "--snapshot", help="Snapshot id or LATEST.")) -> None:
    """Print a saved snapshot."""
    snapshot_id = db.resolve_snapshot(snapshot)
    if snapshot_id is None:
        console.print("No snapshots found.")
        raise typer.Exit(1)
    rows = db.get_snapshot(snapshot_id)
    console.print(stories_table(rows, f"Snapshot {snapshot_id}"))


@app.command()
def diff(
    from_snapshot: Optional[int] = typer.Option(None, "--from", help="Older snapshot id."),
    to_snapshot: Optional[int] = typer.Option(None, "--to", help="Newer snapshot id."),
) -> None:
    """Compare two snapshots."""
    try:
        if from_snapshot is None or to_snapshot is None:
            from_snapshot, to_snapshot = db.default_diff_ids()
        changes = db.diff_snapshots(from_snapshot, to_snapshot)
    except ValueError as exc:
        console.print(str(exc))
        raise typer.Exit(1) from exc

    console.print(f"Diff snapshot {from_snapshot} -> {to_snapshot}")
    for label, rows in [("Entered", changes["entered"]), ("Left", changes["left"])]:
        table = Table(title=label)
        table.add_column("Rank", justify="right")
        table.add_column("ID", justify="right")
        table.add_column("Title")
        for row in rows:
            table.add_row(str(row["rank"]), str(row["id"]), row["title"])
        console.print(table)

    table = Table(title="Rank Changed")
    table.add_column("ID", justify="right")
    table.add_column("Title")
    table.add_column("From", justify="right")
    table.add_column("To", justify="right")
    table.add_column("Delta", justify="right")
    for row in changes["changed"]:
        table.add_row(str(row["id"]), row["title"], str(row["from_rank"]), str(row["to_rank"]), f"{row['delta']:+d}")
    console.print(table)


@app.command()
def story(id: int) -> None:
    """Fetch and show a single live story with its first five comments."""
    item, comments = run(api.fetch_story_with_comments(id))
    if not item:
        console.print(f"Story {id} not found.")
        raise typer.Exit(1)

    print_kv(
        console,
        f"Story {id}",
        {
            "title": item.get("title"),
            "url": item.get("url"),
            "score": item.get("score"),
            "by": item.get("by"),
            "time": item.get("time"),
            "descendants": item.get("descendants"),
            "type": item.get("type"),
        },
    )
    for comment in comments[:5]:
        console.print(Panel(comment.get("text") or "", title=f"{comment.get('by') or 'unknown'} #{comment.get('id')}"))


@app.command()
def search(query: str) -> None:
    """Search saved story titles."""
    rows = db.search_titles(query)
    console.print(stories_table(rows, f"Search: {query}"))


@app.command()
def stats() -> None:
    """Print database statistics."""
    values = db.stats()
    author_text = ", ".join(f"{author} ({count})" for author, count in values.pop("top_authors"))
    values["top_authors"] = author_text
    print_kv(console, "HN Tracker Stats", values)


@app.command()
def export(format: str = typer.Argument(..., help="json, csv, or markdown")) -> None:
    """Export the latest snapshot."""
    snapshot_id = db.resolve_snapshot("LATEST")
    if snapshot_id is None:
        raise typer.Exit(1)
    rows = db.get_snapshot(snapshot_id)
    if format == "json":
        typer.echo(export_json(rows))
    elif format == "csv":
        typer.echo(export_csv(rows), nl=False)
    elif format == "markdown":
        typer.echo(export_markdown(rows))
    else:
        console.print("Format must be json, csv, or markdown.")
        raise typer.Exit(1)


@app.command()
def watch(interval: int = typer.Option(60, "--interval", min=1, help="Seconds between fetches.")) -> None:
    """Fetch repeatedly until Ctrl-C."""
    previous_snapshot = db.resolve_snapshot("LATEST")
    try:
        while True:
            stories = run(api.fetch_top_stories(30))
            snapshot_id, fetched_at, count = db.create_snapshot(stories)
            summary = f"snapshot={snapshot_id} fetched={count} at={fetched_at}"
            if previous_snapshot is not None:
                changes = db.diff_snapshots(previous_snapshot, snapshot_id)
                summary += (
                    f" entered={len(changes['entered'])}"
                    f" left={len(changes['left'])}"
                    f" rank_changed={len(changes['changed'])}"
                )
            console.print(summary)
            previous_snapshot = snapshot_id
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("Stopped.")


def main() -> None:
    app()
