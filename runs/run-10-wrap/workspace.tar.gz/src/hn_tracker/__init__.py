"""Hacker News snapshot tracker."""

from hn_tracker.cli import app, main

__all__ = ["app", "main"]
