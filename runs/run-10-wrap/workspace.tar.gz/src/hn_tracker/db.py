from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlite_utils import Database

DB_PATH = Path("hn.db")


def utc_now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def connect(path: Path = DB_PATH) -> Database:
    db = Database(path)
    ensure_schema(db)
    return db


def ensure_schema(db: Database) -> None:
    db.execute(
        """
        create table if not exists snapshots (
            id integer primary key autoincrement,
            fetched_at text not null
        )
        """
    )
    db.execute(
        """
        create table if not exists story_snapshots (
            rowid integer primary key autoincrement,
            snapshot_id integer not null references snapshots(id),
            rank integer not null,
            id integer not null,
            title text not null,
            url text,
            score integer,
            by text,
            time integer,
            descendants integer,
            type text,
            fetched_at text not null,
            unique(snapshot_id, id)
        )
        """
    )
    db.execute("create index if not exists idx_story_snapshots_snapshot_rank on story_snapshots(snapshot_id, rank)")
    db.execute("create index if not exists idx_story_snapshots_id on story_snapshots(id)")
    db.execute(
        """
        create virtual table if not exists story_snapshots_fts
        using fts5(title, content='story_snapshots', content_rowid='rowid')
        """
    )


def create_snapshot(stories: list[dict[str, Any]], path: Path = DB_PATH) -> tuple[int, str, int]:
    db = connect(path)
    fetched_at = utc_now_iso()
    cursor = db.execute("insert into snapshots (fetched_at) values (?)", [fetched_at])
    snapshot_id = int(cursor.lastrowid)
    rows = []
    for rank, story in enumerate(stories, start=1):
        if not story or story.get("type") != "story" or not story.get("id") or not story.get("title"):
            continue
        rows.append(
            {
                "snapshot_id": snapshot_id,
                "rank": rank,
                "id": int(story["id"]),
                "title": story["title"],
                "url": story.get("url"),
                "score": story.get("score"),
                "by": story.get("by"),
                "time": story.get("time"),
                "descendants": story.get("descendants"),
                "type": story.get("type"),
                "fetched_at": fetched_at,
            }
        )

    if rows:
        db["story_snapshots"].insert_all(rows)
        inserted = list(db.query("select rowid, title from story_snapshots where snapshot_id = ?", [snapshot_id]))
        with db.conn:
            db.conn.executemany(
                "insert or replace into story_snapshots_fts(rowid, title) values (?, ?)",
                [(row["rowid"], row["title"]) for row in inserted],
            )
    return snapshot_id, fetched_at, len(rows)


def snapshot_ids(path: Path = DB_PATH) -> list[int]:
    db = connect(path)
    return [row["id"] for row in db.query("select id from snapshots order by id")]


def resolve_snapshot(value: str | int | None = "LATEST", path: Path = DB_PATH) -> int | None:
    ids = snapshot_ids(path)
    if not ids:
        return None
    if value is None or str(value).upper() == "LATEST":
        return ids[-1]
    snapshot_id = int(value)
    if snapshot_id not in ids:
        raise ValueError(f"Snapshot {snapshot_id} does not exist")
    return snapshot_id


def get_snapshot(snapshot_id: int, path: Path = DB_PATH) -> list[dict[str, Any]]:
    db = connect(path)
    return list(db.query("select * from story_snapshots where snapshot_id = ? order by rank", [snapshot_id]))


def default_diff_ids(path: Path = DB_PATH) -> tuple[int, int]:
    ids = snapshot_ids(path)
    if len(ids) < 2:
        raise ValueError("At least two snapshots are required")
    return ids[-2], ids[-1]


def diff_snapshots(from_id: int, to_id: int, path: Path = DB_PATH) -> dict[str, list[dict[str, Any]]]:
    old = {row["id"]: row for row in get_snapshot(from_id, path)}
    new = {row["id"]: row for row in get_snapshot(to_id, path)}
    entered = [new[item_id] for item_id in new.keys() - old.keys()]
    left = [old[item_id] for item_id in old.keys() - new.keys()]
    changed = []
    for item_id in old.keys() & new.keys():
        old_rank = int(old[item_id]["rank"])
        new_rank = int(new[item_id]["rank"])
        if old_rank != new_rank:
            changed.append(
                {
                    "id": item_id,
                    "title": new[item_id]["title"],
                    "from_rank": old_rank,
                    "to_rank": new_rank,
                    "delta": old_rank - new_rank,
                }
            )
    return {
        "entered": sorted(entered, key=lambda row: row["rank"]),
        "left": sorted(left, key=lambda row: row["rank"]),
        "changed": sorted(changed, key=lambda row: row["to_rank"]),
    }


def search_titles(query: str, path: Path = DB_PATH) -> list[dict[str, Any]]:
    db = connect(path)
    sql = """
        select s.id, s.title, s.url, s.by, s.score, s.snapshot_id, s.rank, s.fetched_at
        from story_snapshots_fts f
        join story_snapshots s on s.rowid = f.rowid
        where story_snapshots_fts match ?
        order by s.snapshot_id desc, s.rank
    """
    return list(db.query(sql, [query]))


def stats(path: Path = DB_PATH) -> dict[str, Any]:
    db = connect(path)
    snapshot_count = db.conn.execute("select count(*) from snapshots").fetchone()[0]
    unique_stories = db.conn.execute("select count(distinct id) from story_snapshots").fetchone()[0]
    bounds = db.conn.execute("select min(fetched_at), max(fetched_at) from story_snapshots").fetchone()
    authors = Counter(
        row["by"] for row in db.query("select by from story_snapshots where by is not null")
    ).most_common(5)
    return {
        "snapshots": snapshot_count,
        "unique_stories": unique_stories,
        "top_authors": authors,
        "oldest_fetched_at": bounds[0],
        "newest_fetched_at": bounds[1],
    }
