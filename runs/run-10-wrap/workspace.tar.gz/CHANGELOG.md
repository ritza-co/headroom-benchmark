# Changelog

## 0.1.0 - 2026-06-04

- Added `fetch` to collect Hacker News top stories with concurrent `httpx` requests.
- Added SQLite snapshot storage at `./hn.db`.
- Added Rich table rendering for saved snapshots.
- Added snapshot diffs for entered, left, and rank-changed stories.
- Added live story lookup with first five top-level comments.
- Added SQLite FTS5 title search across saved snapshots.
- Added database statistics.
- Added JSON, CSV, and Markdown export formats.
- Added watch mode for repeated fetches and one-line change summaries.
- Added pytest coverage for every command and core behavior.
- Added Docker and GitHub Actions CI support.
